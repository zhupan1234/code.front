<template>
  <div id="backgroudImg">
    <div class="title">
      <img class="titleIocn" src="../../assets/compony.png" />
      <div class="titleText" v-text="'后台管理系统'"></div>
    </div>
    <div class="box">
      <div class="innerBox">
        <div>
          <img src="../../assets/avatar.png" alt="" class="userPic" />
        </div>
        <el-row style="height: 25%">
          <el-col :span="24">
            <div class="rowName">
              <span class="titleSpace">用户名</span>
              <input
                @keyup.enter="login"
                class="loginText"
                type="text"
                v-model="account"
                placeholder="请输入用户名"
              />
            </div>
          </el-col>
        </el-row>
        <el-row style="height: 15%">
          <el-col :span="24">
            <div>
              <span class="titleSpace">密码</span>
              <input
                @keyup.enter="login"
                class="loginText1"
                type="password"
                v-model="password"
                placeholder="请输入密码"
              />
            </div>
          </el-col>
        </el-row>
        <!-- <el-checkbox v-model="checked">记住我</el-checkbox> -->
        <div class="loginBtn" @click="login()">
          <span class="loginTitle">登&nbsp;&nbsp;&nbsp;&nbsp;录</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
// 这里可以导入其他文件(比如：组件，工具js，第三方插件js，json文件，图片文件等等)
// 例如：import 《组件名称》 from '《组件路径》';
import { accountLogin } from "../../api/template.js";

export default {
  // import引入的组件需要注入到对象中才能使用
  components: {},
  props: {},
  data() {
    // 这里存放数据
    return {
      account: "",
      password: null,
      checked: false,
    };
  },
  // 计算属性 类似于data概念
  computed: {},
  // 监控data中的数据变化
  watch: {},
  // 方法集合
  methods: {
    login() {
      let res = accountLogin(this, {
        account: this.account,
        password: this.password,
      });
      res.then((res) => {
        if (res.flag == "right") {
          this.$store.commit("setLogin", true);
          this.$store.commit("setUserName", res.account);
          this.$router.push({
            path: "/manage",
          });
        } else {
          this.$message.warning("用户名或密码错误！");
        }
      });
    },
  },
  // 生命周期 - 创建完成（可以访问当前this实例）
  created() {},
  // 生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  // 生命周期 - 创建之前
  beforeCreate() {},
  // 生命周期 - 挂载之前
  beforeMount() {},
  // 生命周期 - 更新之前
  beforeUpdate() {},
  // 生命周期 - 更新之后
  updated() {},
  // 生命周期 - 销毁之前
  beforeUnmount() {},
  // 生命周期 - 销毁完成
  unmount() {},
  // 如果页面有keep-alive缓存功能，这个函数会触发
  activated() {},
};
</script>
<style lang='scss' scoped>
#backgroudImg {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin: 0 auto;
  width: 100%;
  height: 100%;
  background-image: url(../../assets/sky.png);
  background-size: 100%;
  background-color: rgba(56, 149, 232, 1);
  background-position-x: center;
  background-position-y: center;
  background-repeat: no-repeat;
}
.title {
  padding-top: 10%;
  justify-content: center;
  display: flex;
}
.titleIocn {
  width: 65px;
  height: 65px;
  margin-left: -1%;
}
.titleText {
  width: 300px;
  height: 49px;
  padding-left: 40px;
  font-size: 43px;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: rgba(255, 255, 255, 1);
  text-shadow: 0px 5px 8px rgba(0, 0, 0, 0.35);
}
.box {
  margin: 20px;
  width: 480px;
  height: 400px;
  background: rgba(255, 255, 255, 0.25);
  border: 1px solid #ffffff;
}
.innerBox {
  margin-left: 10px;
  margin-top: 16px;
  width: 460px;
  height: 364px;
  background: rgba(255, 255, 255, 0.25);
  border: 1px solid #ffffff;
  border-radius: 2px;
}
.userPic {
  margin-top: 45px;
  margin-left: 203px;
  width: 70px;
  height: 70px;
  background: rgba(255, 255, 255, 0.15);
  border: 1px solid #ffffff;
  border-radius: 50%;
}

.titleSpace {
  margin-left: 18px;
  width: 52px;
  height: 18px;
  font-size: 18px;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #ffffff;
}
.rowName {
  margin-top: 26px;
}
.loginText {
  margin-left: 20px;
  width: 345px;
  height: 36px;
  padding-left: 10px;
  background: rgba(193, 224, 247, 0.3);
  border: 1px solid #ffffff;
  opacity: 0.5;
}
.loginText1 {
  margin-left: 36px;
  width: 345px;
  height: 36px;
  padding-left: 10px;
  background: rgba(193, 224, 247, 0.3);
  border: 1px solid #ffffff;
  opacity: 0.5;
}
/deep/.el-checkbox__inner {
  margin-left: 20px;
  background: rgba(255, 255, 255, 0.25);
  border: 1px solid #ffffff;
  border-radius: 2px;
  height: 16px;
  width: 16px;
}
/deep/.el-checkbox__label {
  font-size: 14px;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #ffffff;
}
.loginBtn {
  cursor: pointer;
  margin-left: 18px;
  margin-top: 20px;
  padding-top: 4px;
  width: 432px;
  height: 40px;
  background: #ffffff;
  opacity: 0.65;
}
.loginTitle {
  margin-left: 42%;
  width: 59px;
  height: 20px;
  font-size: 20px;
  font-family: Microsoft YaHei;
  font-weight: 400;
  color: #0a56bd;
}
</style>