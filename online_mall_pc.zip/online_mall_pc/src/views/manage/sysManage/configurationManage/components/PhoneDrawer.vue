<template>
  <el-drawer
    style="margin-top: 80px; margin-bottom: 20px"
    size="60%"
    :visible.sync="drawer"
    :direction="direction"
    @open="open"
    :with-header="false"
  >
    <div class="top">
      <img src="@/assets/订单信息.png" class="pgtianjia" />
      <div class="add-party">客服电话信息</div>
      <div class="close-border" @click="closeDrawer()">
        <img src="@/assets/选项卡关闭按钮.png" class="close-top-header" />
      </div>
    </div>
    <div class="drawercenter">
      <div class="inpuittitle">
        <img src="@/assets/257用户资料 (1).png" class="leftimg2" />
        <span>商店名称</span>
      </div>
      <div style="text-align: left">
        <el-input
          clearable
          v-model="input"
          placeholder="请输入轮播名称"
          :disabled="disabled"
        ></el-input>
      </div>

      <div class="inpuittitle">
        <img src="@/assets/订单.png" class="leftimg2" /> 客服电话
      </div>
      <el-input clearable placeholder="请输入内容" v-model="textarea">
      </el-input>

      <div class="blank_div"></div>
    </div>
    <hr class="transferhr" style="background-color: #144274" />
    <div class="btnManage">
      <el-button class="cancelBtn" @click="closeDrawer2()">取消</el-button>
      <el-button class="confirmBtn" @click="save()">确认</el-button>
    </div>
  </el-drawer>
</template>
<script>
import {} from "@/api/template.js";

export default {
  data() {
    //这里存放数据
    return {
      //分页
      direction: "rtl",
      input: "",
      textarea: "",
      drawer: false,
      id: null,
      disabled: false,
      tableData: [],
    };
  },
  //计算属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {
    //右上角关闭按钮关闭卡片
    closeCard() {
      this.isShow = false;
    },
    open() {
      // if (this.id != null) {
      //   this.getdetail(this, {
      //     id: this.id,
      //   }).then((res) => {
      //     this.input = res.name;
      //     this.textarea = res.introduction;
      //   });
      // } else {
      //   this.input = "";
      //   this.textarea = "";
      // }
    },
    //关闭抽屉

    async closeDrawer() {
      const confirmResult = await this.$confirm("确定关闭？", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
      }).catch((err) => err);
      if (confirmResult !== "confirm") {
        this.drawer = true;
      } else {
        this.drawer = false;
      }
    },
    handleRemove(file, fileList) {
      console.log(file, fileList);
    },

    handlePictureCardPreview(file) {
      this.dialogImageUrl = file.url;
      this.dialogVisible = true;
    },
    //获取列表
    getList() {
      // this.getformtable(this, { name: "", page: 1, pageSize: 5 }).then(
      //   (res) => {
      //     this.$parent.tableData = res.partyVOList;
      //     this.$parent.total = res.totalNum;
      //   }
      // );
    },
    //抽屉里确认按钮
    save() {
      const todoObj = {
        id: 1,
        name: this.input,
        phoneNumber: this.textarea,
        state: 0,
        time: "qweqwe",
      };
      //通知App组件去添加一个todo对象
      this.$emit("addTodo", todoObj);
      this.drawer = false;
    },
    closeDrawer2() {
      this.drawer = false;
    },
  },

  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
};
</script>

<style lang="scss" scoped>
.el-drawer__header {
  background-color: #f9f3f1 !important;
  justify-content: space-around !important;
  font-size: 1.2rem;
  color: #c77f75;
  text-align: left;
  padding: 1rem !important;
  margin-bottom: 0rem !important;
}
.el-upload--picture-card {
  width: 18.86667rem !important;
}
.drawercenter {
  margin-left: 10px;
}
.uploadbox {
  margin-right: 765px;
}
.transferhr {
  border: none;
  height: 2px;
  background-color: #cfe4f8;
  opacity: 0.2;
  margin-top: 20px;
}
.leftimg2 {
  height: 30px;
  width: 10px;
  margin-right: 14px;
}
.inpuittitle {
  margin: 1rem 0 0.5rem 0;
  text-align: left;
  display: flex;
  align-items: center;
  img {
    width: 2%;
  }
}

.cfmbtn {
  background: #ed742a;
  border-radius: 20px;
  width: 120px;
  height: 40px;
  color: #ffffff;
  border: none;
}
.qtbtn {
  color: #ffffff;
  background: #cccccc;
  border-radius: 20px;
  width: 120px;
  height: 40px;
  border: none;
}

.iconplus {
  margin-right: 900px;
}

.el-input {
  width: 20%;
}
.el-input__inner {
  margin: 11px 17px;
  width: 180px;
  height: 20px;
  border: 1px solid #e5e5e5;
}
.clearfix:before,
.clearfix:after {
  display: table;
  content: "";
}
.clearfix:after {
  clear: both;
}

.top {
  background: #d5e8fa;
  display: flex;
  padding-top: 12px;
  text-align: center;
  word-break: keep-all;
  height: 50px;
  margin-top: 10px;
  width: 100%;
  font-size: 20px;
}
.pgtianjia {
  margin-left: 10px;
  vertical-align: middle;
  width: 25px;
  height: 25px;
  margin-right: 10px;
}
.close-border {
  position: absolute;
  cursor: pointer;
  top: -50px;
  right: -50px;
  width: 110px;
  height: 110px;
  background: #d5e8fa;
  border-radius: 50%;
}
.close-top-header {
  position: absolute;
  top: 60px;
  left: 20px;
  width: 30px;
  height: 30px;
}
.blank_div {
  height: 500px;
}
.btnManage {
  margin: 0 auto;
  width: 20%;
}
.cancelBtn {
  background-color: white;
  border-radius: 20px;
}
.confirmBtn {
  background-color: #d5e8fa;
  border-radius: 20px;
}
.shifouqiyong {
  display: flex;
}
.status {
  height: 25px;
  width: 25px;
  margin-right: 15px;
}
.qiyong {
  margin-top: 20px;
}
.switch {
  margin-top: 30px;
}
</style>