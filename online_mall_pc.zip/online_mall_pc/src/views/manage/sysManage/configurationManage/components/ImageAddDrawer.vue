<template>
  <el-drawer
    style="margin-top: 80px; margin-bottom: 20px"
    size="60%"
    :visible.sync="drawer"
    :direction="direction"
    @open="open"
    :with-header="false"
  >
    <div class="top">
      <img src="@/assets/订单信息.png" class="pgtianjia" />
      <div class="add-party">订单信息</div>
      <div class="close-border" @click="closeDrawer()">
        <img src="@/assets/选项卡关闭按钮.png" class="close-top-header" />
      </div>
    </div>
    <div class="drawercenter">
      <div class="inpuittitle">
        <img src="@/assets/257用户资料 (1).png" class="leftimg2" />
        <span>图片名称</span>
      </div>
      <div style="text-align: left">
        <el-input
          clearable
          v-model="pictureName"
          placeholder="请输入轮播名称"
          :disabled="disabled"
        ></el-input>
      </div>

      <div class="inpuittitle">
        <img src="@/assets/订单.png" class="leftimg2" /> 图片介绍
      </div>
      <el-input
        clearable
        type="textarea"
        :rows="2"
        placeholder="请输入内容"
        v-model="pictureIntroduction"
      >
      </el-input>
      <div class="Enable">
        <div class="initiateMode">
          <img src="@/assets/启用.png" alt="" class="status" /> 是否启用
        </div>
        <div class="switch">
          <el-switch
            v-model="switchOpen"
            active-color="#13ce66"
            inactive-color="#ff4949"
          >
          </el-switch>
        </div>
      </div>
      <div class="imgWrapper">
        <div class="inpuittitle">
          <img src="@/assets/订单.png" class="leftimg2" /> 图片上传
        </div>
        <el-upload
          action="#"
          multiple
          :limit="1"
          accept=".jpg,.jpeg,.png"
          list-type="picture-card"
          :auto-upload="true"
          ref="pictureUpload"
          :http-request="httpRequest"
          :on-change="handleChange"
        >
          <i slot="default" class="el-icon-plus"></i>
          <div slot="file" slot-scope="{ file }">
            <img
              class="el-upload-list__item-thumbnail"
              :src="file.url"
              alt=""
            />
            <span class="el-upload-list__item-actions">
              <span
                class="el-upload-list__item-preview"
                @click="handlePictureCardPreview(file)"
              >
                <i class="el-icon-zoom-in"></i>
              </span>
              <span
                v-if="!disabled"
                class="el-upload-list__item-delete"
                @click="handleRemove(file)"
              >
                <i class="el-icon-delete"></i>
              </span>
            </span>
          </div>
        </el-upload>
        <el-dialog :visible.sync="dialogVisible" append-to-body>
          <div style="width: 100%; padding: 30px">
            <img width="100%" :src="dialogImageUrl" alt="" />
          </div>
        </el-dialog>
      </div>
    </div>
    <div class="btnManage">
      <el-button class="cancelBtn" @click="closeDrawer2()">取消</el-button>
      <el-button class="confirmBtn" @click="save()">确认</el-button>
    </div>
  </el-drawer>
</template>
<script>
import { addRotationChart } from "@/api/template.js";

export default {
  data() {
    //这里存放数据
    return {
      dialogImageUrl: "",
      dialogVisible: false,
      status: 1,
      totalNum: 0,
      totalPages: 3,
      // 分页
      pagenum: 1,
      direction: "rtl",
      pictureName: "",
      pictureIntroduction: "",
      drawer: false,
      id: null,
      disabled: false,
      tableData: [],
      switchOpen: true,
      fileList: [],
      dialogImageUrl: "",
      attachmentUrl: "",
    };
  },
  //计算属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {
    addRotationChart,
    //右上角关闭按钮关闭卡片
    open() {
      this.pictureName = "";
      this.pictureIntroduction = "";
    },
    closeCard() {
      this.isShow = false;
    },
    //关闭抽屉
    async closeDrawer() {
      const confirmResult = await this.$confirm("确定关闭？", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
      }).catch((err) => err);
      if (confirmResult !== "confirm") {
        this.drawer = true;
      } else {
        this.drawer = false;
      }
    },
    //上传图片
    httpRequest(param) {
      // console.log(param);
      const formData = new FormData(); // FormData对象
      formData.append("file", this.upFile); // file封装到FormData里
      //请求后台上传数据的接口
      this.$http
        .post(
          "http://localhost:8080/onlinemall/pc/RotationChart/addRotationChartPicture",
          formData,
          {
            headers: { "Content-Type": "multipart/form-data" },
          }
        )
        .then((res) => {
          this.attachmentUrl = res.data;
        });
    },
    handleRemove(file, fileList) {
      console.log(file, fileList);
    },
    handlePictureCardPreview(file) {
      this.dialogImageUrl = file.url;
      this.dialogVisible = true;
    },
    //抽屉里确认按钮
    save() {
      if (this.pictureName == "" || this.pictureIntroduction == "") {
        this.$message.warning("请补全图片名称和图片介绍");
      } else {
        if (this.switchOpen == true) {
          this.status = 1;
        } else {
          this.status = 0;
        }
        let param = {
          pictureName: this.pictureName,
          pictureIntroduction: this.pictureIntroduction,
          status: this.status,
          attachmentUrl: this.attachmentUrl,
        };
        addRotationChart(this, param).then((res) => {
          this.$emit("update");
          this.drawer = false;
        });
      }
    },
    closeDrawer2() {
      this.drawer = false;
    },
    handleRemove(file, fileList) {
      console.log(file, fileList);
    },
    handlePictureCardPreview(file) {
      this.dialogImageUrl = file.url;
      this.dialogVisible = true;
    },
    handleChange(file, fileList) {
      this.upFile = file.raw;
    },
  },

  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
};
</script>

<style lang="scss" scoped>
.drawercenter {
  margin-left: 10px;
}

.leftimg2 {
  height: 30px;
  width: 10px;
  margin-right: 14px;
}
.inpuittitle {
  margin: 1rem 0 0.5rem 0;
  text-align: left;
  display: flex;
  align-items: center;
  img {
    width: 2%;
  }
}
.el-input {
  width: 20%;
}
.el-input__inner {
  margin: 11px 17px;
  width: 180px;
  height: 20px;
  border: 1px solid #e5e5e5;
}
.top {
  background: #ebf4fc;
  display: flex;
  padding-top: 12px;
  text-align: center;
  word-break: keep-all;
  height: 50px;
  margin-top: 10px;
  width: 100%;
  font-size: 20px;
}
.pgtianjia {
  margin-left: 10px;
  vertical-align: middle;
  width: 25px;
  height: 25px;
  margin-right: 10px;
}
.close-border {
  position: absolute;
  cursor: pointer;
  top: -50px;
  right: -50px;
  width: 110px;
  height: 110px;
  background: #d5e8fa;
  border-radius: 50%;
}
.close-top-header {
  position: absolute;
  top: 60px;
  left: 20px;
  width: 30px;
  height: 30px;
}
.btnManage {
  position: absolute;
  bottom: 0;
  width: 100%;
  height: 80px;
  background: #ffffff;
  box-shadow: 0px -2px 4px 0px rgba(161, 158, 155, 0.25);
}
.cancelBtn {
  width: 120px;
  height: 40px;
  background: rgba($color: #000000, $alpha: 0.25);
  border-radius: 20px;
  margin-left: 36%;
  margin-top: 18px;
  cursor: pointer;

  font-size: 16px;
  font-family: DengXian;
  font-weight: 400;
  color: #ffffff;
}
.confirmBtn {
  width: 120px;
  height: 40px;
  background: #2a92ed;
  border-radius: 20px;
  margin-left: 28px;
  cursor: pointer;

  font-size: 16px;
  font-family: DengXian;
  font-weight: 400;
  color: #ffffff;
}
.initiateMode {
  display: flex;
}
.status {
  height: 25px;
  width: 25px;
  margin-right: 15px;
}
.Enable {
  margin-top: 20px;
}
.switch {
  margin-top: 30px;
}
.upload {
  margin-top: 20px;
}
</style>