<template>
  <div id="addRecommendCommodity">
    <div class="header">
      <div class="headerContainer">
        <img class="detailIcon" src="@/assets/添加.png" />
        <span class="headTitle">{{ headTitle }}</span>
      </div>
      <button class="crossBtn" @click="close()">
        <img class="crossIcon" src="@/assets/关闭.png" />
      </button>
    </div>

    <div class="typeName">
      <img class="fileImg1" src="@/assets/小房子.png" />
      <span class="fileText1">商品名称</span>
    </div>
    <el-input
      class="typeNameInput"
      v-model="commodityName"
      placeholder="商品名称"
    ></el-input>

    <div class="footer">
      <button class="cancel" @click="closeDrawer()">取消</button>
      <button class="confirm" @click="confirm()">确定</button>
    </div>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import { addRecommendCommodity } from "@/api/template.js";
export default {
  //import引入的组件需要注入到对象中才能使用
  components: {},
  props: ["flag"],
  data() {
    //这里存放数据
    return {
      commodityTypeName: "",
      commodityName: "",
      headTitle: "新增推荐商品",
    };
  },
  //计算属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {
    confirm() {
      if (this.flag == 0) {
        let param = {
            commodityTypeName: this.commodityTypeName,
            commodityName: this.commodityName
        };
        addRecommendCommodity(this, param).then((res) => {
          this.closeDrawer();
          this.$emit("update");
        });
      } 
    },
    // 点击按钮关闭抽屉
    close() {
      this.$confirm("确认关闭?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      }).then(() => {
        this.$parent.$parent.addEditDrawer = false;
      });
    },
    // 关闭抽屉
    closeDrawer() {
      this.$parent.$parent.addEditDrawer = false;
    },
  },
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {
    
  },
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  beforeCreate() {}, //生命周期 - 创建之前
  beforeMount() {}, //生命周期 - 挂载之前
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="scss" scoped>
#addRecommendCommodity {
  height: 100%;
  background: #ffffff;
  box-shadow: -1px 2px 4px 0px rgba(0, 0, 0, 0.15);

  > .header {
    height: 49px;
    display: flex;
    justify-content: space-between;
    margin-top: 7px;
    padding-top: 8px;
    background: rgba($color: #2a92ed, $alpha: 0.05);

    > .headerContainer {
      > .detailIcon {
        width: 28px;
        height: 28px;
        margin-left: 27px;
        vertical-align: middle;
      }

      > .headTitle {
        font-size: 18px;
        font-family: DengXian;
        // font-weight: 400;
        color: #2a92ed;
        margin-left: 11px;
        vertical-align: middle;
      }
    }

    > .crossBtn {
      width: 65px;
      height: 65px;
      background: rgba($color: #2a92ed, $alpha: 0.25);
      border-radius: 0 0 0 65px;
      transform: translate(0, -15px);
      cursor: pointer;

      > .crossIcon {
        width: 22px;
        height: 22px;
        transform: translate(4px, -4px);
      }
    }
  }

  > .typeName {
    margin-top: 30px;
    margin-left: 27px;

    > .fileImg1 {
      width: 16px;
      height: 16px;
      vertical-align: middle;
    }

    > .fileText1 {
      width: 95px;
      height: 15px;
      font-size: 16px;
      font-family: DengXian;
      font-weight: 400;
      color: #323232;
      vertical-align: middle;
      margin-left: 17px;
    }
  }

  > .typeNameInput {
    width: 93%;
    margin-left: 57px;
    margin-top: 10px;

    /deep/ .el-input__inner {
      height: 30px;
    }
  }

  > .typeParentName {
    margin-top: 30px;
    margin-left: 27px;

    > .fileImg1 {
      width: 16px;
      height: 16px;
      vertical-align: middle;
    }

    > .fileText1 {
      width: 95px;
      height: 15px;
      font-size: 16px;
      font-family: DengXian;
      font-weight: 400;
      color: #323232;
      vertical-align: middle;
      margin-left: 17px;
    }
  }

  > .typeParentNameInput {
    width: 93%;
    margin-left: 57px;
    margin-top: 10px;

    /deep/ .el-input__inner {
      height: 30px;
    }
  }

  > .footer {
    position: absolute;
    bottom: 0;
    width: 100%;
    height: 80px;
    background: #ffffff;
    box-shadow: 0px -2px 4px 0px rgba(161, 158, 155, 0.25);

    > .cancel {
      width: 120px;
      height: 40px;
      background: rgba($color: #000000, $alpha: 0.25);
      border-radius: 20px;
      margin-left: 36%;
      margin-top: 18px;
      cursor: pointer;

      font-size: 16px;
      font-family: DengXian;
      font-weight: 400;
      color: #ffffff;
    }

    > .confirm {
      width: 120px;
      height: 40px;
      background: #2a92ed;
      border-radius: 20px;
      margin-left: 28px;
      cursor: pointer;

      font-size: 16px;
      font-family: DengXian;
      font-weight: 400;
      color: #ffffff;
    }
  }
}
/deep/ .el-textarea__inner {
  resize: none;
}
</style>