<template>
  <div id="addCommodityType">
    <div class="header">
      <div class="headerContainer">
        <img class="detailIcon" src="@/assets/添加.png" />
        <span class="headTitle">{{ headTitle }}</span>
      </div>
      <button class="crossBtn" @click="close()">
        <img class="crossIcon" src="@/assets/关闭.png" />
      </button>
    </div>

    <div class="typeParentName">
      <img class="fileImg1" src="@/assets/小房子.png" />
      <span class="fileText1">一级类别</span>
    </div>
    <el-input
      class="typeParentNameInput"
      v-model="parentName"
      placeholder="请输入一级类别名称"
    ></el-input>

    <div class="typeName">
      <img class="fileImg1" src="@/assets/小房子.png" />
      <span class="fileText1">二级类别</span>
    </div>
    <el-input
      class="typeNameInput"
      v-model="name"
      placeholder="请输入二级类别名称"
    ></el-input>

    <div class="status">
      <img class="fileImg1" src="@/assets/小房子.png" />
      <span class="fileText1">状态</span>
    </div>
    <el-input
      class="statusInput"
      v-model="status"
      placeholder="是否为首页推荐商品(否填0，是填1)"
    ></el-input>

    <div class="image">
      <img class="fileImg1" src="@/assets/小房子.png" />
      <span class="fileText1">添加图片</span>
    </div>
    <div class="imgWrapper">
      <el-upload
        action="#"
        multiple
        :limit="1"
        accept=".jpg,.jpeg,.png"
        list-type="picture-card"
        :auto-upload="false"
        ref="pictureUpload"
        :on-change="handleChange"
      >
        <i slot="default" class="el-icon-plus"></i>
        <div slot="file" slot-scope="{ file }">
          <img class="el-upload-list__item-thumbnail" :src="file.url" alt="" />
          <span class="el-upload-list__item-actions">
            <span
              class="el-upload-list__item-preview"
              @click="handlePictureCardPreview(file)"
            >
              <i class="el-icon-zoom-in"></i>
            </span>
            <span
              v-if="!disabled"
              class="el-upload-list__item-delete"
              @click="handleRemove(file)"
            >
              <i class="el-icon-delete"></i>
            </span>
          </span>
        </div>
      </el-upload>
      <el-dialog :visible.sync="dialogVisible" append-to-body>
        <div style="width: 100%; padding: 30px">
          <img width="100%" :src="dialogImageUrl" alt="" />
        </div>
      </el-dialog>
    </div>

    <div class="footer">
      <button class="cancel" @click="closeDrawer()">取消</button>
      <button class="confirm" @click="confirm()">确定</button>
    </div>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import { addCommodityType, updateCommodityType } from "@/api/template.js";
export default {
  //import引入的组件需要注入到对象中才能使用
  components: {},
  props: ["info", "flag"],
  data() {
    //这里存放数据
    return {
      id: 1,
      name: "",
      parentName: "",
      attachmentUrl: "",
      status: null,
      headTitle: "",
      fileList: [],
      dialogVisible: false,
      dialogImageUrl: "",
      disabled: false,
    };
  },
  //计算属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {
    confirm() {
      if (this.flag == 0) {
        let formData = new FormData();
        formData.append("file", this.upFile);
        formData.append("name", this.name);
        formData.append("parentName", this.parentName);
        formData.append("status", this.status);
        this.$http.post("http://localhost:8080/onlinemall/pc/commodityType/addCommodityType", formData, {
          headers: {
            "Content-Type": "multipart/form-data"
          }
        })
      } else if (this.flag == 1) {
        let param = {
          id: this.id,
          name: this.name,
          parentName: this.parentName,
          attachmentUrl: this.attachmentUrl,
          status: this.status,
        };
        updateCommodityType(this, param).then((res) => {
          this.closeDrawer();
          this.$emit("update");
        });
      }
    },
    // 点击按钮关闭抽屉
    close() {
      this.$confirm("确认关闭?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      }).then(() => {
        this.$parent.$parent.addEditDrawer = false;
      });
    },
    // 关闭抽屉
    closeDrawer() {
      this.$parent.$parent.addEditDrawer = false;
    },
    handleRemove(file) {
      this.$refs.pictureUpload.handleRemove(file);
    },
    handlePictureCardPreview(file) {
      this.dialogImageUrl = file.url;
      this.dialogVisible = true;
    },
    handleChange(file, fileList) {
      console.log(fileList);
      this.upFile = file.raw;
    },
  },
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {
    if (this.flag == 1) {
      this.headTitle = "修改类别";
      setTimeout(() => {
        this.id = this.info.id;
        this.name = this.info.name;
        this.parentName = this.info.parentName;
        this.status = this.info.status;
      }, 100);
    } else {
      this.headTitle = "新增类别";
    }
  },
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  beforeCreate() {}, //生命周期 - 创建之前
  beforeMount() {}, //生命周期 - 挂载之前
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>
<style lang="scss" scoped>
#addCommodityType {
  height: 100%;
  background: #ffffff;
  box-shadow: -1px 2px 4px 0px rgba(0, 0, 0, 0.15);

  > .header {
    height: 49px;
    display: flex;
    justify-content: space-between;
    margin-top: 7px;
    padding-top: 8px;
    background: rgba($color: #2a92ed, $alpha: 0.05);

    > .headerContainer {
      > .detailIcon {
        width: 28px;
        height: 28px;
        margin-left: 27px;
        vertical-align: middle;
      }

      > .headTitle {
        font-size: 18px;
        font-family: DengXian;
        // font-weight: 400;
        color: #2a92ed;
        margin-left: 11px;
        vertical-align: middle;
      }
    }

    > .crossBtn {
      width: 65px;
      height: 65px;
      background: rgba($color: #2a92ed, $alpha: 0.25);
      border-radius: 0 0 0 65px;
      transform: translate(0, -15px);
      cursor: pointer;

      > .crossIcon {
        width: 22px;
        height: 22px;
        transform: translate(4px, -4px);
      }
    }
  }

  > .typeName {
    margin-top: 30px;
    margin-left: 27px;

    > .fileImg1 {
      width: 16px;
      height: 16px;
      vertical-align: middle;
    }

    > .fileText1 {
      width: 95px;
      height: 15px;
      font-size: 16px;
      font-family: DengXian;
      font-weight: 400;
      color: #323232;
      vertical-align: middle;
      margin-left: 17px;
    }
  }

  > .typeNameInput {
    width: 93%;
    margin-left: 57px;
    margin-top: 10px;

    /deep/ .el-input__inner {
      height: 30px;
    }
  }

  > .typeParentName {
    margin-top: 30px;
    margin-left: 27px;

    > .fileImg1 {
      width: 16px;
      height: 16px;
      vertical-align: middle;
    }

    > .fileText1 {
      width: 95px;
      height: 15px;
      font-size: 16px;
      font-family: DengXian;
      font-weight: 400;
      color: #323232;
      vertical-align: middle;
      margin-left: 17px;
    }
  }

  > .typeParentNameInput {
    width: 93%;
    margin-left: 57px;
    margin-top: 10px;

    /deep/ .el-input__inner {
      height: 30px;
    }
  }

  > .status {
    margin-top: 30px;
    margin-left: 27px;

    > .fileImg1 {
      width: 16px;
      height: 16px;
      vertical-align: middle;
    }

    > .fileText1 {
      width: 95px;
      height: 15px;
      font-size: 16px;
      font-family: DengXian;
      font-weight: 400;
      color: #323232;
      vertical-align: middle;
      margin-left: 17px;
    }
  }

  > .statusInput {
    width: 93%;
    margin-left: 57px;
    margin-top: 10px;

    /deep/ .el-input__inner {
      height: 30px;
    }
  }

  > .image {
    margin-top: 30px;
    margin-left: 27px;

    > .fileImg1 {
      width: 16px;
      height: 16px;
      vertical-align: middle;
    }

    > .fileText1 {
      width: 95px;
      height: 15px;
      font-size: 16px;
      font-family: DengXian;
      font-weight: 400;
      color: #323232;
      vertical-align: middle;
      margin-left: 17px;
    }
  }

  > .imgWrapper {
    margin-left: 57px;
    margin-top: 10px;
  }

  > .footer {
    position: absolute;
    bottom: 0;
    width: 100%;
    height: 80px;
    background: #ffffff;
    box-shadow: 0px -2px 4px 0px rgba(161, 158, 155, 0.25);

    > .cancel {
      width: 120px;
      height: 40px;
      background: rgba($color: #000000, $alpha: 0.25);
      border-radius: 20px;
      margin-left: 36%;
      margin-top: 18px;
      cursor: pointer;

      font-size: 16px;
      font-family: DengXian;
      font-weight: 400;
      color: #ffffff;
    }

    > .confirm {
      width: 120px;
      height: 40px;
      background: #2a92ed;
      border-radius: 20px;
      margin-left: 28px;
      cursor: pointer;

      font-size: 16px;
      font-family: DengXian;
      font-weight: 400;
      color: #ffffff;
    }
  }
}
/deep/ .el-textarea__inner {
  resize: none;
}
</style>