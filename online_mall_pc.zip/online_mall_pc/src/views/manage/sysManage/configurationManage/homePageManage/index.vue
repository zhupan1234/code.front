<template>
  <div id="HomePageImage">
    <div class="home">
      <div style="display: flex">
        <div class="topbtngroup">
          <button class="addbtn" @click="add()">
            <img src="@/assets/plus.png" alt="" class="icon_plus" />
            <span class="add_span">新增轮播图</span>
          </button>
          <button class="deletebtn" @click="alldelete()" ref="deleteFiles">
            <img src="@/assets/delete.png" alt="" class="icon_delete" />
            <span class="delSpan">删除</span>
          </button>
        </div>
      </div>
      <div>
        <el-table
          ref="multipleTable"
          :data="tableData"
          tooltip-effect="dark"
          style="width: 100%"
          @selection-change="handleSelectionChange"
          :header-cell-style="{ background: '#daecfb', color: '#697077' }"
        >
          <el-table-column
            type="selection"
            width="55"
            align="center"
            class="table_column"
          >
          </el-table-column>
          <el-table-column prop="pictureName" label="图片名称" align="left">
          </el-table-column>
          <el-table-column prop="pictureIntroduction" label="图片介绍">
          </el-table-column>
          <el-table-column label="启用状态" align="left">
            <template slot-scope="scope">
              <button :class="scope.row.status == 1 ? 'right' : 'wrong'">
                {{ scope.row.status == 1 ? "已启用" : "未启用" }}
              </button>
            </template>
          </el-table-column>

          <el-table-column label="相关操作" align="left" width="400">
            <template slot-scope="scope">
              <el-button
                size="medium"
                type="text"
                class="delete_btn"
                @click="handleDelete(scope.$index, scope.row)"
              >
                删除
              </el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
      <div class="block">
        <span class="page_datanum"
          >共{{ this.totalPages }}页，{{ this.totalNum }}条数据</span
        >
        <div class="page_box">
          <div class="page_box1" @click="firstPage()">
            <img src="@/assets/greyNext1.png" alt="" />
          </div>
          <div class="page_box2" @click="previousPage()">
            <img src="@/assets/greyNext.png" alt="" />
          </div>
          <div class="page_box3">
            <span class="page_box3_word">{{ pagenum }}/{{ totalPages }}</span>
          </div>
          <div class="page_box4" @click="nextPage()">
            <img src="@/assets/blueNext.png" alt="" />
          </div>
          <div class="page_box5" @click="lastPage()">
            <img src="@/assets/blueNext1.png" alt="" />
          </div>
        </div>
      </div>
    </div>
    <image-add-drawer
      ref="ImageAddDrawer"
      @update="getRotationChart"
    ></image-add-drawer>
  </div>
</template>

<script>
import ImageAddDrawer from "../../configurationManage/components/ImageAddDrawer.vue";
import { getRotationChartPageVO, delRotationChart } from "@/api/template.js";
export default {
  components: { ImageAddDrawer },
  created() {
    this.getRotationChart();
  },
  data() {
    return {
      tableData: [],
      totalNum: 1,
      totalPages: 1,
      //分页
      pagenum: 1,
      pageSize: 5,
      multipleSelection: [],
    };
  },
  watch: {
    multipleSelection(val) {
      if (val.length != 0) {
        this.$refs.deleteFiles.style.background = "#e16966";
      } else {
        this.$refs.deleteFiles.style.background = "#bfbfbf";
      }
    },
  },
  methods: {
    delRotationChart,
    getRotationChartPageVO,
    getRotationChart() {
      let param = {
        page: this.pagenum,
        pageSize: this.pageSize,
      };
      getRotationChartPageVO(this, param).then((res) => {
        this.tableData = res.rotationChartList;
        this.totalNum = res.totalNum;
        this.totalPages = res.totalPages;
      });
    },
    toggleSelection(rows) {
      if (rows) {
        rows.forEach((row) => {
          this.$refs.multipleTable.toggleRowSelection(row);
        });
      } else {
        this.$refs.multipleTable.clearSelection();
      }
    },
    handleDelete(index, row) {
      this.$confirm("此操作将永久删除轮播图, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      }).then(() => {
        this.delRotationChart(this, {
          id: row.id,
        }).then((res) => {
          this.getRotationChart();
        });
      });
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
    //新增
    add() {
      this.$refs.ImageAddDrawer.drawer = true;
      this.$refs.ImageAddDrawer.id = null;
    },
    //实现多选删除
    async alldelete() {
      const confirmResult = await this.$confirm("确认删除？", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
      }).catch((err) => err);
      if (confirmResult !== "confirm") {
      } else {
        for (let i = 0; i < this.multipleSelection.length; i++) {
          let res = delRotationChart(this, {
            id: this.multipleSelection[i].id,
          });
          res.then(() => {
            this.getRotationChart(); //重新加载页面
          });
        }
      }
    },
    //回首页
    firstPage() {
      this.pagenum = 1;
      this.getRotationChart();
    },
    //上一页
    previousPage() {
      const a = this.pagenum;
      if (a <= 1) {
        this.pagenum = 1;
      } else {
        this.pagenum -= 1;
      }
      this.getRotationChart();
    },
    //下一页
    nextPage() {
      const a = this.pagenum;
      const b = this.totalPages;
      if (a >= b) {
        this.pagenum = b;
      } else {
        this.pagenum += 1;
      }
      this.getRotationChart();
    },
    //跳到末页
    lastPage() {
      if (this.pagenum != this.totalPages) {
        this.pagenum = this.totalPages;
      }
      this.getRotationChart();
    },

    handleEdit(index, row) {
      this.$refs.ImageEditDrawer.drawer = true;
      this.$refs.ImageEditDrawer.state = 1;
      this.$refs.ImageEditDrawer.id = row.id;
      this.$refs.ImageEditDrawer.disabled = false;
    },
  },
};
</script>

<style lang="scss"  scoped>
.topbtngroup {
  margin-bottom: 5px;
  display: flex;
  width: 100%;
  padding: 1vh 0;
}
.delete_btn {
  font-size: 14px;
  font-family: DengXian;
  font-weight: 400;
  color: #2a92ed;
  border: none;
}
.addbtn {
  width: 120px;
  height: 30px;
  background: #2d9dff;
  border-radius: 8px;
}
.button-new-tag {
  margin-left: 10px;
  height: 32px;
  line-height: 30px;
  padding-top: 0;
  padding-bottom: 0;
}
.block {
  text-align: right;
}
.button-new-tag {
  border: 1px solid #ed742a;
  opacity: 0.8;
  border-radius: 15px;
  background: #ffffff;
  box-shadow: -1px 2px 4px 0px rgba(0, 0, 0, 0.15);
  width: 80px;
}
.iconplus {
  margin-right: 900px;
}
.icon_delete {
  width: 18px;
  height: 18px;
  vertical-align: middle;
}

.block {
  position: relative;
  height: 47px;
  margin-top: 14px;
}
.page_datanum {
  position: absolute;
  top: 16px;
  left: 16px;
  width: 113px;
  height: 15px;
  font-size: 14px;
  font-family: DengXian;
  font-weight: 400;
  color: black;
}
.page_box {
  position: absolute;
  right: 15px;
  height: 47px;
}
.page_box1,
.page_box2,
.page_box3,
.page_box4,
.page_box5 {
  cursor: pointer;
  float: left;
  width: 40px;
  height: 40px;
  margin: 3px;
  border: #b9b9b9 solid 1px;
  border-radius: 4px;
  text-align: center;
}
.page_box1,
.page_box2,
.page_box4,
.page_box5 {
  background-color: #f7f7f7;
}

.page_box3 {
  cursor: text;
  width: 50px;
}
.page_box1 img,
.page_box2 img {
  margin-top: 9px;
  margin-left: 0px;
  width: 25px;
  height: 25px;
}
.page_box5 img {
  margin-top: 7px;
  margin-left: 0px;
  width: 25px;
  height: 25px;
}
.page_box4 img {
  margin-top: 5px;
  margin-left: 0px;
  width: 30px;
  height: 30px;
}
.page_box3_word {
  position: absolute;
  top: 15px;
  left: 110px;
  width: 19px;
  height: 11px;
  font-size: 14px;
  font-family: DengXian;
  font-weight: 400;
  color: #000000;
  opacity: 0.8;
}
.deletebtn {
  width: 79px;
  height: 30px;
  background: #bfbfbf;
  border-radius: 8px;
  cursor: pointer;
  margin-left: 15px;
}
.icon_plus {
  width: 20px;
  height: 20px;
  vertical-align: middle;
}
.add_span {
  vertical-align: middle;
  font-size: 14px;
  font-family: DengXian;
  font-weight: 400;
  color: #ffffff;
}

.delSpan {
  margin-left: 6px;
  vertical-align: middle;
  font-size: 14px;
  font-family: DengXian;
  font-weight: 400;
  color: #ffffff;
}
.right {
  height: 30px;
  width: 50px;
  border-radius: 10px;
  background-color: rgb(0, 248, 0);
  color: #ffffff;
  border: 0px;
}
.wrong {
  height: 30px;
  width: 50px;
  border-radius: 10px;
  background-color: rgb(236, 9, 9);
  color: #ffffff;
  border: 0px;
}
</style>