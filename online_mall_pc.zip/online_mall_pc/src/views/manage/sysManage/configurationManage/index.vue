<template>
  <div id="branchManage">
    <div class="tabs">
      <el-tabs v-model="activeName" @tab-click="handleClick2()">
        <el-tab-pane label="首页轮播图管理" name="third">
          <home-page-image></home-page-image>
        </el-tab-pane>
        <el-tab-pane label="精品推荐管理" name="forth">
          <recom-manage></recom-manage>
        </el-tab-pane>
        <el-tab-pane label="商品类别管理" name="fifth">
          <com-category-manage></com-category-manage>
        </el-tab-pane>
      </el-tabs>
    </div>
    <check-drawer ref="checkDrawer"></check-drawer>
  </div>
</template>
<script>
import checkDrawer from "../configurationManage/components/checkDrawer.vue";
import HomePageImage from "../configurationManage/homePageManage";
import RecomManage from "../configurationManage/recommendManage";
import ComCategoryManage from "../configurationManage/commodityTypeManage";
import { getUserPageVO, getUserOrder } from "@/api/template.js";
export default {
  components: {
    checkDrawer,
    HomePageImage,
    RecomManage,
    ComCategoryManage,
  },
  props: {},
  data() {
    //这里存放数据
    return {
      totalNum: 5,
      totalPages: 1,
      //分页
      pagenum: 1,
      userName: "",
      myname: "",
      activeName: "third", //默认绑定用户管理
      tableData: [], //表单数据
      multipleSelection: [], //放选中数据
    };
  },
  created() {
    this.getUserList();
  },
  methods: {
    getUserOrder,
    getUserPageVO,
    //回首页
    firstPage() {
      this.pagenum = 1;
      this.getUserList();
    },
    //上一页
    previousPage() {
      const a = this.pagenum;
      if (a <= 1) {
        this.pagenum = 1;
      } else {
        this.pagenum -= 1;
      }
      this.getUserList();
    },
    //下一页
    nextPage() {
      const a = this.pagenum;
      const b = this.totalPages;
      if (a >= b) {
        this.pagenum = b;
      } else {
        this.pagenum += 1;
      }
      this.getUserList();
    },
    //跳到末页
    lastPage() {
      if (this.pagenum != this.totalPages) {
        this.pagenum = this.totalPages;
      }
      this.getUserList();
    },
    handleClick(index, row) {
      this.$refs.checkDrawer.drawer = true;
      this.$refs.checkDrawer.disabled = false;
      this.$refs.checkDrawer.userId = row.id;
      this.$refs.checkDrawer.userName = row.userName;
    },
    getUserList() {
      let param = {
        page: this.pagenum,
        pageSize: this.totalNum,
      };
      getUserPageVO(this, param).then((res) => {
        this.tableData = res.userList;
        this.totalNum = res.totalNum;
        this.totalPages = res.totalPages;
        console.log(res);
      });
    },
    // 搜索政策文件
    searchUser() {
      let param = {
        page: this.pagenum,
        pageSize: this.totalNum,
        userName: this.userName == "" ? null : this.userName,
      };
      getUserPageVO(this, param).then((res) => {
        console.log(res);
        this.tableData = res.userList;
        this.totalNum = res.totalNum;
        this.totalPages = res.totalPages;
        console.log(res);
      });
    },
    //把选中行的数据传递给数组multipleSelection
    selectionChange(val) {
      //console.log(val);
      this.multipleSelection = val;
    },
    handleClick2() {},
  },
};
</script>
<style lang="scss" scoped>
.tabs {
  margin-left: 30px;
}
.top_input {
  display: flex;
  float: right;
  .el-input--mini {
    width: 300px;
  }
  /deep/.el-input__inner {
    width: 300px;
    height: 30px;
    background: #ffffff;
    border: 1px solid #b5b5b5;
    border-radius: 6px;
  }
  .top_src_pic {
    width: 26px;
    height: 27px;
    margin-left: 15px;
    margin-right: 30px;
  }
}
/**表格样式 */
.table {
  margin-top: 13px;
  margin-left: 0px;
}
/**页码样式 */
.page {
  display: flex;
  justify-content: space-between;
  height: 47px;
  margin-top: 14px;
  .page_datanum {
    margin-top: 16px;
    margin-left: 16px;
    height: 15px;
    font-size: 14px;
    font-family: DengXian;
    font-weight: 400;
    color: #8d8d8d;
  }
  .page_box {
    margin-right: 40px;
    height: 47px;
    display: flex;
    .page_box1,
    .page_box2,
    .page_box3,
    .page_box4,
    .page_box5 {
      cursor: pointer;
      width: 40px;
      height: 40px;
      margin: 3px;
      border: #ece3e1 solid 1px;
    }
    .page_box3 {
      cursor: text;
      width: 50px;
      .page_box3_word {
        margin-top: 10px;
        margin-left: 15px;
        font-size: 14px;
        font-family: DengXian;
        font-weight: 400;
        color: #000000;
        opacity: 0.8;
      }
    }
  }
}
.page_box1 img {
  margin-top: 10px;
  margin-left: 10px;
  width: 20px;
  height: 20px;
}
.page_box2 img {
  margin-top: 10px;
  margin-left: 5px;
  width: 20px;
  height: 20px;
}
.page_box5 img {
  margin-top: 10px;
  margin-left: 7px;
  width: 20px;
  height: 20px;
}
.page_box4 img {
  margin-top: 10px;
  margin-left: 12px;
  width: 20px;
  height: 20px;
}
.clickBtn {
  cursor: pointer;
  background-color: white;
  color: #3b8de8;
  border: none;
  padding-left: 0px;
}
.clickBtn:hover {
  background-color: #f3f6f9;
}
</style>