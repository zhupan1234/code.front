<template>
  <div id="commodityCategory">
    <div class="header">
      <div class="control">
        <button
          class="addCommodityCategory"
          @click="
            flag = 0;
            addEditDrawer = true;
          "
        >
          <img class="addIcon" src="@/assets/plus.png" />
          <span class="addTitle">新增类别</span>
        </button>
        <button class="delFile" ref="deleteFile" @click="deleteFile()">
          <img class="delIcon" src="@/assets/delete.png" />
          <span class="delTitle">删除</span>
        </button>
      </div>
      <div class="searchDiv">
        <input type="text" class="searchText" v-model="name" />
        <button class="searchFile" @click="searchCommodityType()">
          <img class="searchIcon" src="@/assets/搜索.png" />
        </button>
      </div>
    </div>

    <el-drawer
      :visible.sync="addEditDrawer"
      direction="rtl"
      size="65.16%"
      destroy-on-close
      ref="addEditDrawer"
      :with-header="false"
    >
      <add-edit-file
        :flag="flag"
        :info="info"
        @update="getData"
      ></add-edit-file>
    </el-drawer>

    <el-table
      ref="multipleTable"
      :data="tableData"
      tooltip-effect="dark"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55"></el-table-column>
      <el-table-column type="index" width="55" label="序号"></el-table-column>
      <el-table-column
        prop="parentName"
        label="一级类别名称"
        width="200"
      ></el-table-column>
      <el-table-column
        prop="name"
        label="二级类别名称"
        width="400"
      ></el-table-column>
      <el-table-column prop="address" label="操作" show-overflow-tooltip>
        <template slot-scope="scope">
          <el-button
            class="operateBtn"
            type="text"
            @click="
              handleEdit(scope.row);
              flag = 1;
              addEditDrawer = true;
            "
            >编辑</el-button
          >
          <el-button
            class="operateBtn"
            type="text"
            style="padding-left: 20px"
            @click="handleDelete(scope.row)"
            >删除</el-button
          >
        </template>
      </el-table-column>
    </el-table>
    <div class="footer">
      <span class="pageText"
        >共{{ this.totalPages }}页，{{ this.totalNum }}条数据</span
      >
      <div class="pagination">
        <button class="pageBtn" @click="previous">
          <img
            class="pageImg"
            :src="currentPage > 1 ? image.previousO : image.previous"
          />
        </button>
        <button class="pageBtn" @click="left">
          <img
            class="pageImg"
            :src="currentPage > 1 ? image.leftO : image.left"
          />
        </button>
        <button class="pageBtn1">{{ currentPage }}/{{ totalPages }}</button>
        <button class="pageBtn" @click="right">
          <img
            class="pageImg"
            :src="currentPage < totalPages ? image.rightO : image.right"
          />
        </button>
        <button class="pageBtn" @click="next">
          <img
            class="pageImg"
            :src="currentPage < totalPages ? image.nextO : image.next"
          />
        </button>
      </div>
    </div>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
import AddEditFile from "../components/AddEditFile.vue";
import {
  getNextCommodityTypePage,
  deleteCommodityTypeByIds,
  getCommodityTypeById,
} from "@/api/template.js";
export default {
  //import引入的组件需要注入到对象中才能使用
  components: {
    AddEditFile,
  },
  props: {},
  data() {
    //这里存放数据
    return {
      page: 1,
      pageSize: 5,
      currentPage: 1,
      totalNum: 1,
      totalPages: 1,
      name: "",
      tableData: [],
      flag: -1,
      multipleSelection: [],
      addEditDrawer: false,
      info: {
        id: 1,
        name: "",
        parentId: null,
        parentName: "",
        attachmentUrl: "",
        status: null,
      },
      image: {
        previous: require("@/assets/greyNext1.png"),
        previousO: require("@/assets/greyNext1.png"),
        left: require("@/assets/greyNext.png"),
        leftO: require("@/assets/greyNext.png"),
        right: require("@/assets/blueNext.png"),
        rightO: require("@/assets/blueNext.png"),
        next: require("@/assets/blueNext1.png"),
        nextO: require("@/assets/blueNext1.png"),
      },
    };
  },
  //计算属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {
    multipleSelection(val) {
      if (val.length != 0) {
        this.$refs.deleteFile.style.background = "#e87036";
      } else {
        this.$refs.deleteFile.style.background = "#bfbfbf";
      }
    },
  },
  //方法集合
  methods: {
    // 获取数据
    getData() {
      let param = {
        page: this.currentPage,
        pageSize: this.pageSize,
        name: this.name == "" ? null : this.name,
      };
      getNextCommodityTypePage(this, param).then((res) => {
        for (let i = 0; i < res.commodityTypeVOList.length; i++) {
          if (res.commodityTypeVOList[i].parentId == null) {
            res.commodityTypeVOList[i].parentName = "无";
          }
        }
        this.tableData = res.commodityTypeVOList;
        this.totalNum = res.totalNum;
        this.totalPages = res.totalPages;
      });
    },
    // 删除政策文件
    deleteFile() {
      if (this.$refs.multipleTable.selection.length == 0) {
        return 0;
      } else {
        this.$confirm("此操作将永久删除这些商品类别, 是否继续?", "提示", {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        })
          .then(() => {
            let list = [];
            for (
              let i = 0;
              i < this.$refs.multipleTable.selection.length;
              i++
            ) {
              list.push(this.$refs.multipleTable.selection[i].id);
            }
            let param = {
              ids: list,
            };
            deleteCommodityTypeByIds(this, param).then((res) => {
              this.getData();
            });
            this.$message({
              type: "success",
              message: "删除成功!",
            });
          })
          .catch(() => {
            this.$message({
              type: "info",
              message: "已取消删除",
            });
          });
      }
    },
    handleSelectionChange(val) {
      this.multipleSelection = val;
    },
    // 编辑支部文件
    handleEdit(row) {
      let param = {
        id: row.id,
      };
      getCommodityTypeById(this, param).then((res) => {
        this.info.id = res.id;
        this.info.name = res.name;
        this.info.parentId = res.parentId;
        this.info.parentName = res.parentName == null ? "无" : res.parentName;
        this.info.attachmentUrl = res.attachmentUrl;
        this.info.status = res.status;
      });
    },
    // 删除支部文件
    handleDelete(row) {
      let param = {
        ids: [row.id],
      };
      this.$confirm("此操作将永久删除该商品类别, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          deleteCommodityTypeByIds(this, param).then((res) => {
            this.getData();
          });
          this.$message({
            type: "success",
            message: "删除成功!",
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除",
          });
        });
    },

    // 搜索政策文件
    searchCommodityType() {
      let param = {
        page: this.currentPage,
        pageSize: this.pageSize,
        name: this.name == "" ? null : this.name,
      };
      getNextCommodityTypePage(this, param).then((res) => {
        console.log(res);
        for (let i = 0; i < res.commodityTypeVOList.length; i++) {
          if (res.commodityTypeVOList[i].parentId == null) {
            res.commodityTypeVOList[i].parentName = "无";
          }
        }
        this.tableData = res.commodityTypeVOList;
        this.totalNum = res.totalNum;
        this.totalPages = res.totalPages;
      });
    },

    // 向左翻页
    left() {
      if (this.currentPage > 1) {
        this.currentPage -= 1;
      }
      this.getData();
    },
    // 向右翻页
    right() {
      if (this.currentPage < this.totalPages) {
        this.currentPage += 1;
      }
      this.getData();
    },
    // 回到首页
    previous() {
      if (this.currentPage != 1) {
        this.currentPage = 1;
      }
      this.getData();
    },
    // 到末页
    next() {
      if (this.currentPage != this.totalPages) {
        this.currentPage = this.totalPages;
      }
      this.getData();
    },
  },
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {
    this.getData();
  },
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
  beforeCreate() {}, //生命周期 - 创建之前
  beforeMount() {}, //生命周期 - 挂载之前
  beforeUpdate() {}, //生命周期 - 更新之前
  updated() {}, //生命周期 - 更新之后
  beforeDestroy() {}, //生命周期 - 销毁之前
  destroyed() {}, //生命周期 - 销毁完成
  activated() {}, //如果页面有keep-alive缓存功能，这个函数会触发
};
</script>

<style lang="scss" scoped>
#commodityCategory {
  > .header {
    display: flex;
    justify-content: space-between;

    > .control {
      > .addCommodityCategory {
        width: 120px;
        height: 30px;
        background: #2a92ed;
        border-radius: 8px;
        cursor: pointer;

        > .addIcon {
          width: 20px;
          height: 20px;
          color: #ffffff;
          vertical-align: middle;
        }

        > .addTitle {
          width: 68px;
          height: 14px;
          font-size: 14px;
          font-family: DengXian;
          font-weight: 400;
          color: #ffffff;
          margin-left: 8px;
        }
      }

      > .delFile {
        width: 79px;
        height: 30px;
        margin-left: 16px;
        background: #bfbfbf;
        border-radius: 8px;
        cursor: pointer;

        > .delIcon {
          width: 19px;
          height: 21px;
          vertical-align: middle;
        }

        > .delTitle {
          font-size: 14px;
          font-family: DengXian;
          font-weight: 400;
          color: #ffffff;
          margin-left: 8px;
        }
      }
    }

    > .searchDiv {
      margin-right: 30px;

      > .searchText {
        width: 387px;
        height: 30px;
        // margin-left: 896px;
        background: #ffffff;
        border: 1px solid #b5b5b5;
        border-radius: 6px;
        padding-left: 12px;
        vertical-align: middle;
      }

      > .searchFile {
        margin-left: 15px;
        width: 26px;
        height: 27px;
        background: none;
        vertical-align: middle;
        cursor: pointer;

        > .searchIcon {
          width: 26px;
          height: 27px;
        }
      }
    }
  }

  .el-table {
    width: 98%;
    margin-top: 13px;

    /deep/ .el-checkbox__inner {
      width: 16px;
      height: 16px;
    }

    /deep/ th {
      background: rgba($color: #2a92ed, $alpha: 0.15);
      border-radius: 2px;
    }

    /deep/ td {
      border-radius: 2px;
      padding-top: 5px;
      padding-bottom: 5px;
    }
  }

  > .footer {
    display: flex;
    justify-content: space-between;

    > .pageText {
      font-size: 14px;
      font-family: DengXian;
      font-weight: 400;
      color: #000000;
      opacity: 0.8;
      margin-top: 15px;
      margin-left: 17px;
    }

    > .pagination {
      display: inline-block;
      vertical-align: middle;
      width: 219px;
      height: 47px;
      margin-right: 25px;

      > .pageBtn {
        background: rgba($color: #e0e0e0, $alpha: 0.25);
        width: 36px;
        height: 34px;
        border: 1px solid #d2d2d2;
        margin-left: 6px;
        margin-top: 8px;
        vertical-align: middle;

        > .pageImg {
          height: 20px;
          width: 20px;
          margin-top: 5px;
        }
      }

      > .pageBtn1 {
        background: none;
        width: 36px;
        height: 34px;
        border: 1px solid #d2d2d2;
        margin-left: 6px;
        margin-top: 8px;
        vertical-align: middle;
      }

      > .promptText {
        display: inline-block;
        width: 40px;
        height: 40px;
        border: 1px solid #d2d2d2;
      }
    }
  }
}
.operateBtn {
  font-size: 14px;
  font-family: DengXian;
  font-weight: 400;
  color: #2a92ed;
  border: none;
  // padding-left: 20px;
}
</style>