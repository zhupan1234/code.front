<template>
  <div>
    <el-form :model="addForm" :rules="rules" ref="ruleAddForm">
      <div class="formContent">
        <div class="formAdd">
          <img class="formAddPic" src="@/assets/添加.png" alt="" />
          <span class="formAddWord">添加客服</span>
          <div class="formClose" @click="closeAddSon">
            <img class="formClosePic" src="@/assets/关闭.png" alt="" />
          </div>
        </div>
        <!--表单 名称 简介-->
        <div class="formTitle">
          <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
          <span class="formTitleWord">客服名称</span>
        </div>
        <div class="formNameInput">
          <el-form-item prop="customerServiceName">
            <el-input
              size="mini"
              v-model="addForm.customerServiceName"
              placeholder="请输入客服名称"
              clearable
            ></el-input>
          </el-form-item>
        </div>
        <div class="formTitle">
          <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
          <span class="formTitleWord">客服电话</span>
        </div>
        <div class="formIntroInput">
          <el-form-item prop="telephone">
            <el-input
              v-model="addForm.telephone"
              size="mini"
              placeholder="请输入客服电话"
              clearable
            >
            </el-input>
          </el-form-item>
        </div>
      </div>
      <!--表单按钮-->
      <div class="formButton">
        <el-button type="info" @click="closeAddSon">
          <span class="formButton1">取消</span>
        </el-button>
        <el-button @click="addUser('ruleAddForm')">
          <span class="formButton1">确认</span>
        </el-button>
      </div>
    </el-form>
  </div>
</template>
<script>
import { addCustomerServiceOrg} from "@/api/template.js"
export default {
  data() {
    return {
      addForm: {
        customerServiceName: "",
        telephone: "",
      },
      rules: {
        customerServiceName: [{ required: true, message: "请输入客服名称", trigger: "blur" }],
        telephone: [
          { required: true, message: "请输入客服电话", trigger: "blur" },
        ],
      },
      drawer: false,
    };
  },
  methods: {
    addCustomerServiceOrg,
    closeAddSon() {
      this.drawer = false;
      this.$emit("closeAdd", this.drawer);
    },
    addUser(form) {
      this.$refs[form].validate((valid) => {
        if (valid) {
          alert("支部信息提交成功！！！");
          let res = addCustomerServiceOrg(this, {
            customerServiceName: this.addForm.customerServiceName,
            telephone: this.addForm.telephone,           
          });
          res.then(() => {
            this.drawer = false;
            this.$emit("getCustomerServiceList");
            this.$emit("closeAdd", this.drawer);
          });
        } else {
          alert("请将信息填写完整，再单击确认");
          return false;
        }
      });
    },
  },
};
</script>
<style lang="scss" scoped>
/*  表格样式  */
.formContent {
  overflow: hidden;
}

.formAdd {
  position: relative;
  margin-top: 7px;
  width: 100%;
  height: 49px;
  background: #e9f4fd;
}

.formClose {
  position: absolute;
  cursor: pointer;
  top: -60px;
  right: -60px;
  width: 120px;
  height: 120px;
  background: #cae4fa;
  border-radius: 50%;
}

.formClosePic {
  position: absolute;
  top: 76px;
  left: 28px;
  width: 22px;
  height: 22px;
}

.formAddPic {
  position: absolute;
  top: 10px;
  left: 27px;
  width: 30px;
  height: 30px;
}

.formAddWord {
  position: absolute;
  top: 16px;
  left: 62px;
  height: 18px;
  font-size: 18px;
  font-family: DengXian;
  font-weight: 400;
  color: #2a92ed;
}

.formTitle {
  margin-top: 30px;
  height: 16px;
}

.formTitlePic {
  float: left;
  width: 16px;
  height: 16px;
  margin-left: 28px;
}

.formTitleWord {
  float: left;
  margin-left: 17px;
  height: 15px;
  font-size: 16px;
  font-family: DengXian;
  font-weight: 400;
  color: #323232;
}

.formNameInput {
  height: 28px;
  margin-top: 5px;
  margin-left: 57px;
  width: 90%;
}

.formNameInput .el-input__inner {
  height: 28px;
  border-radius: 2px;
}

.formIntroInput {
  height: 68px;
  width: 90%;
  margin-top: 5px;
  margin-left: 57px;
}

.formIntroInput .el-textarea__inner {
  height: 68px;
  border-radius: 2px;
  resize: none;
}
.formButton {
  position: fixed;
  bottom: 0px;
  display: flex;
  justify-content: center;
  width: 60%;
  box-shadow: 0px -2px 4px 0px #cae4fa;
  .el-button {
    align-items: center;
    width: 120px;
    height: 40px;
    margin: 15px;
    background: #bfbfbf;
    border-color: #bfbfbf;
    border-radius: 20px;
  }
  .el-button:last-child {
    background: #2a92ed;
    border-color: #2a92ed;
  }
}
.formButton1 {
  font-size: 16px;
  font-family: DengXian;
  font-weight: 400;
  color: #ffffff;
}
</style>
