<template>
  <div>
    <!--
    <el-button type="text" size="small" @click="getmore(getnewId)"
      >查看</el-button
    >
    -->
    <!--详情抽屉-->
    <template>
      <el-drawer
        size="60%"
        :with-header="false"
        :visible.sync="getnew"
        :direction="direction"
        destroy-on-close
      >
        <div class="formContent">
          <div class="formAdd">
            <img class="formAddPic" src="@/assets/添加.png" alt="" />
            <span class="formAddWord">客服详情</span>
            <div class="formClose" @click="getnew = false">
              <img class="formClosePic" src="@/assets/关闭.png" alt="" />
            </div>
          </div>
          <div class="formTitle">
            <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
            <span class="formTitleWord">客服名称</span>
          </div>
          <div class="more">{{ addForm.customerServiceName }}</div>

          <div class="formTitle">
            <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
            <span class="formTitleWord">客服简介</span>
          </div>
          <div class="more">{{ addForm.telephone }}</div>
        </div>
      </el-drawer>
    </template>
    <el-button type="text" size="small" @click="change1(getnewId)"
      >编辑</el-button
    >
    <!--编辑抽屉-->
    <template>
      <el-drawer
        size="60%"
        :with-header="false"
        :visible.sync="changenew"
        :direction="direction"
        destroy-on-close
      >
        <div class="formContent">
          <div class="formAdd">
            <img class="formAddPic" src="@/assets/添加.png" alt="" />
            <span class="formAddWord">编辑客服信息</span>
            <div class="formClose" @click="changenew = false">
              <img class="formClosePic" src="@/assets/关闭.png" alt="" />
            </div>
          </div>
          <el-form :model="addForm" :rules="rules" ref="ruleAddForm">
            <div class="formTitle">
              <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
              <span class="formTitleWord">客服名称</span>
            </div>
            <div class="formNameInput">
              <el-form-item prop="customerServiceName">
                <el-input
                  size="mini"
                  v-model="addForm.customerServiceName"
                  clearable
                ></el-input>
              </el-form-item>
            </div>
            <div class="formTitle">
              <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
              <span class="formTitleWord">客服电话</span>
            </div>
            <div class="formIntroInput">
              <el-form-item prop="telephone">
                <el-input v-model="addForm.telephone" size="mini"> </el-input>
              </el-form-item>
            </div>
            <div class="formButton">
              <el-button type="info" @click="changenew = false">
                <span class="formButton1">取消</span>
              </el-button>
              <el-button @click="change('ruleAddForm')">
                <span class="formButton1">确认</span>
              </el-button>
            </div>
          </el-form>
        </div>
      </el-drawer>
    </template>
    <el-button
      type="text"
      size="small"
      style="margin-left: 20px"
      @click="move(getnewId)"
      >删除</el-button
    >
  </div>
</template>
<script>
import {
  getCustomerServiceOrgById,
  editCustomerServiceOrg,
  delCustomerServiceOrgById,
} from "@/api/template.js";
export default {
  props: ["getnewId"],
  data() {
    return {
      //成员名字显示
      closeAndChange: true,
      numberName: "",
      getnew: false,
      changenew: false,
      direction: "rtl",
      addForm: {
        id: 1,
        customerServiceName: "",
        telephone: "",
      },
      rules: {
        customerServiceName: [
          { required: true, message: "请输入客服名称", trigger: "blur" },
        ],
        telephone: [
          { required: true, message: "请输入客服电话", trigger: "blur" },
        ],
      },
    };
  },
  methods: {
    getCustomerServiceOrgById,
    editCustomerServiceOrg,
    delCustomerServiceOrgById,
    //删除客服
    async move(id) {
      const confirmResult = await this.$confirm(
        "此操作将永久删除该客服, 是否继续?",
        "提示",
        {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        }
      ).catch((err) => err);
      if (confirmResult !== "confirm") {
        return this.$message.error("删除客服失败");
      } else {
        this.$message.success("删除客服成功");
        let res = delCustomerServiceOrgById(this, { id: id });
        res.then(() => {
          this.$emit("firstPage");
        });
      }
    },
    //编辑客服信息
    change1(id) {
      this.getmore(id);
      this.changenew = true;
      this.getnew = false;
    },
    //确定更客服信息
    change(form) {
      this.$refs[form].validate((valid) => {
        if (valid) {
          alert("客服信息修改成功！！！");
          let res = editCustomerServiceOrg(this, {
            id: this.addForm.id,
            telephone: this.addForm.telephone,
            customerServiceName: this.addForm.customerServiceName,
          });
          res.then(() => {
            //console.log(res);
            this.changenew = false;
            this.$emit("getCustomerServiceList");
            this.closeAndChange = true;
          });
        } else {
          alert("请将信息填写完整，再单击确认");
          return false;
        }
      });
    },
    //根据客服id获取客服详细信息
    getmore(id) {
      this.getnew = true;
      let res = getCustomerServiceOrgById(this, { id: id });
      res.then((res) => {
        this.addForm.id = res.id;
        this.addForm.telephone = res.telephone;
        this.addForm.customerServiceName = res.customerServiceName;
      });
    },
  },
};
</script>
<style lang="scss" scoped>
.formContent {
  overflow: hidden;
}
.more {
  margin-top: 20px;
  margin-left: 60px;
  font-size: 14px;
  font-family: DengXian;
  font-weight: 500;
}
.formAdd {
  position: relative;
  margin-top: 7px;
  width: 100%;
  height: 49px;
  background: #e9f4fd;
}

.formClose {
  position: absolute;
  cursor: pointer;
  top: -60px;
  right: -60px;
  width: 120px;
  height: 120px;
  background: #cae4fa;
  border-radius: 50%;
}

.formClosePic {
  position: absolute;
  top: 76px;
  left: 28px;
  width: 22px;
  height: 22px;
}

.formAddPic {
  position: absolute;
  top: 10px;
  left: 27px;
  width: 30px;
  height: 30px;
}

.formAddWord {
  position: absolute;
  top: 16px;
  left: 62px;
  height: 18px;
  font-size: 18px;
  font-family: DengXian;
  font-weight: 400;
  color: #2a92ed;
}

.formTitle {
  margin-top: 30px;
  height: 16px;
}

.formTitlePic {
  float: left;
  width: 16px;
  height: 16px;
  margin-left: 28px;
}

.formTitleWord {
  float: left;
  margin-left: 17px;
  height: 15px;
  font-size: 16px;
  font-family: DengXian;
  font-weight: 400;
  color: #323232;
}

.formNameInput {
  height: 28px;
  margin-top: 5px;
  margin-left: 57px;
  width: 90%;
}

.formNameInput .el-input__inner {
  height: 28px;
  border-radius: 2px;
}

.formIntroInput {
  height: 68px;
  width: 90%;
  margin-top: 5px;
  margin-left: 57px;
}

.formIntroInput .el-textarea__inner {
  height: 68px;
  border-radius: 2px;
  resize: none;
}
.formButton {
  position: fixed;
  bottom: 0px;
  display: flex;
  justify-content: center;
  width: 60%;
  box-shadow: 0px -2px 4px 0px #cae4fa;
  .el-button {
    align-items: center;
    width: 120px;
    height: 40px;
    margin: 15px;
    background: #bfbfbf;
    border-color: #bfbfbf;
    border-radius: 20px;
  }
  .el-button:last-child {
    background: #2a92ed;
    border-color: #2a92ed;
  }
}
.formButton1 {
  font-size: 16px;
  font-family: DengXian;
  font-weight: 400;
  color: #ffffff;
}
</style>
