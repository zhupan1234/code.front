<template>
  <div>
    <div class="top">
      <!--按钮添加-->
      <div class="buttonAdd">
        <el-button @click="drawer = true">
          <img class="top_add_pic" src="@/assets/加号.png" alt="" />
          <span class="top_add"> 添加客服</span>
        </el-button>
      </div>
      <template>
        <el-drawer
          :with-header="false"
          size="60%"
          :visible.sync="drawer"
          :direction="direction"
          destroy-on-close
        >
          <!--表单-->
          <add
            @closeAdd="closeAdd"
            @getCustomerServiceList="getCustomerServiceList"
          ></add>
        </el-drawer>
      </template>
      <div class="topInput">
        <el-input
          v-model="customerServiceName"
          placeholder="请输入客服名称"
          clearable
          @clear="getCustomerServiceList"
          size="mini"
        ></el-input>
        <el-input
          v-model="telephone"
          placeholder="请输入客服电话"
          style="margin-left:20px"
          clearable
          @clear="getCustomerServiceList"
          size="mini"
        ></el-input>
        <div class="topSrc" @click="getCustomerServiceList">
          <img class="topSrcPic" src="@/assets/搜索.png" />
        </div>
      </div>
    </div>
    <!--表单-->
    <div class="zhibu">
      <el-table
        :data="tableData"
        :header-cell-style="{ background: '#DFEFFC', color: '#57504C' }"
      >
        <el-table-column type="selection"> </el-table-column>
        <el-table-column prop="customerServiceName" label="客服名称">
        </el-table-column>
        <el-table-column prop="telephone" label="客服电话"> </el-table-column>
        <el-table-column label="操作">
          <template v-slot="scope">
            <checkEdit
              :getnewId="scope.row.id"
              @getCustomerServiceList="getCustomerServiceList"
              @firstPage="firstPage"
            >
            </checkEdit>
          </template>
        </el-table-column>
      </el-table>
      <!--分页-->
      <div class="page">
        <span class="page_datanum"
          >共{{ totalPages }}页，{{ totalNum }}条数据</span
        >
        <div class="page_box">
          <div class="page_box1" @click="firstPage">
            <img src="@/assets/箭头_上一页_o.png" alt="" />
          </div>
          <div class="page_box2" @click="sub">
            <img src="@/assets/箭头-1.png" alt="" />
          </div>
          <div class="pageBox3">
            <div class="pageBox3Word">{{ pagenum }}/{{ totalPages }}</div>
          </div>
          <div class="pageBox4" @click="add">
            <img src="@/assets/箭头.png" alt="" />
          </div>
          <div class="page_box5" @click="lastPage">
            <img src="@/assets/箭头_下一页_o.png" alt="" />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import checkEdit from "./components/checkEdit.vue";
import add from "./components/add.vue";
import { getNextCustomerServiceOrgPage } from "@/api/template.js";
export default {
  components: {
    checkEdit,
    add,
  },
  data() {
    return {      
      customerServiceName: "",
      telephone: "",
      direction: "rtl",
      dialogVisible: false,
      pagenum: 1,
      //隐藏抽屉
      drawer: false,
      //表格
      totalNum: 0,
      totalPages: 0,
      tableData: [], //放表格数据
    };
  },
  created() {
    this.getCustomerServiceList();
  },
  methods: {
    getNextCustomerServiceOrgPage,
    closeAdd(val) {
      this.drawer = val;
    },
    //根据页数获取客服数据列表
    getCustomerServiceList() {
      let res = getNextCustomerServiceOrgPage(this, {
        customerServiceName: this.customerServiceName,
        telephone: this.telephone,
        page: this.pagenum,
        pageSize: 5,
      });
      res.then((res) => {
        this.tableData = res.customerServiceVOList;
        this.totalNum = res.totalNum;
        this.totalPages = res.totalPages;
      });
    },
    //上一页
    sub() {
      const a = this.pagenum;
      if (a <= 1) {
        this.pagenum = 1;
      } else {
        this.pagenum -= 1;
      }
      this.getCustomerServiceList();
    },
    //下一页
    add() {
      const a = this.pagenum;
      const b = this.totalPages;
      if (a >= b) {
        this.pagenum = b;
      } else {
        this.pagenum += 1;
      }
      this.getCustomerServiceList();
    },
    //回首页
    firstPage() {
      this.pagenum = 1;
      this.getCustomerServiceList();
    },
    //跳到末页
    lastPage() {
      let num = this.totalPages;
      this.pagenum = num;
      this.getCustomerServiceList();
    },
  },
};
</script>
<style lang="scss" scoped>
.top {
  margin-top: 13px;
  height: 30px;

  .buttonAdd {
    float: left;
    .el-button {
      position: relative;
      height: 30px;
      margin-left: 25px;
      width: 120px;
      background: #2a92ed;
      border-radius: 8px;
      border-color: #2a92ed;
      color: #ffffff;
    }
  }
  .buttonDelete {
    float: left;
    .el-button {
      position: relative;
      margin-left: 16px;
      width: 79px;
      height: 30px;
      background: #bfbfbf;
      border-radius: 8px;
      border: #bfbfbf;
    }
    .deleteColor {
      background: #2a92ed;
    }
  }

  .topInput {
    float: right;
    .el-input--mini {
      width: 387px;
    }
    /deep/.el-input__inner {
      width: 387px;
      height: 30px;
      background: #ffffff;
      border: 1px solid #b5b5b5;
      border-radius: 6px;
    }
  }
  .topSrc {
    float: right;
    margin-left: 15px;
    margin-right: 26px;
    position: relative;
    cursor: pointer;
    width: 30px;
    height: 30px;
  }
}

.top_add {
  position: absolute;
  left: 35px;
  top: 9px;
  width: 68px;
  height: 14px;
  font-size: 14px;
  font-family: DengXian;
  font-weight: 400;
  color: #ffffff;
}

.top_add_pic {
  position: absolute;
  left: 11px;
  top: 7px;
  width: 16px;
  height: 16px;
}
.top_del_pic {
  position: absolute;
  left: 12px;
  top: 6px;
  width: 16px;
  height: 18px;
}
.top_del {
  position: absolute;
  left: 36px;
  top: 8px;
  width: 27px;
  height: 14px;
  font-size: 14px;
  font-family: DengXian;
  font-weight: 400;
  color: #ffffff;
}

.topSrcPic {
  position: absolute;
  top: 1px;
  left: 1px;
  width: 26px;
  height: 27px;
}
/**表格样式 */
.zhibu {
  margin-top: 13px;
  margin-left: 24px;
}
/**页码样式 */
.page {
  display: flex;
  justify-content: space-between;
  height: 47px;
  margin-top: 14px;
  .page_datanum {
    margin-top: 16px;
    margin-left: 16px;
    height: 15px;
    font-size: 14px;
    font-family: DengXian;
    font-weight: 400;
    color: #8d8d8d;
  }
  .page_box {
    margin-right: 40px;
    height: 47px;
    display: flex;
    .page_box1,
    .page_box2,
    .pageBox3,
    .pageBox4,
    .page_box5 {
      cursor: pointer;
      width: 40px;
      height: 40px;
      margin: 3px;
      border: #ece3e1 solid 1px;
    }
    .pageBox3 {
      cursor: text;
      width: 50px;
      .pageBox3Word {
        margin-top: 10px;
        margin-left: 15px;
        font-size: 14px;
        font-family: DengXian;
        font-weight: 400;
        color: #000000;
        opacity: 0.8;
      }
    }
  }
}
.page_box1 img,
.page_box2 img,
.page_box5 img {
  margin-top: 10px;
  margin-left: 5px;
  width: 20px;
  height: 20px;
}
.pageBox4 img {
  margin-top: 12px;
  margin-left: 5px;
  width: 15px;
  height: 15px;
}
</style>
