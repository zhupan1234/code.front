<template>
  <div id="rightManage">
    <div class="table-head">
      <button class="add-bt" @click="drawer = true">
        <img src="../../../../assets/plus.png" class="add-img" />
        <span class="add-title">新增用户</span>
      </button>
      <template>
        <el-drawer
          :with-header="false"
          size="60%"
          :visible.sync="drawer"
          destroy-on-close
        >
          <!--表单-->
          <loginAdd @closeAdd="closeAdd" @getUserList="getUserList"></loginAdd>
        </el-drawer>
      </template>

      <button class="delBt" ref="delbt" @click="deletemany()">
        <img src="../../../../assets/delete.png" class="delImg" />
        <span class="del-title">删除</span>
      </button>
      <input
        type="text"
        class="search-put"
        placeholder="用户名称"
        v-model="searchName"
      />
      <button class="search-data" @click="getUserList()">
        <img class="search-img" src="../../../../assets/blueSearch.png" />
      </button>
    </div>
    <el-table
      class="Table-container"
      ref="multipleTable"
      :data="this.tableData"
      tooltip-effect="dark"
      :header-cell-style="headerstyle"
      @selection-change="selectionChange"
    >
      <el-table-column type="selection"> </el-table-column>
      <el-table-column prop="account" label="用户名名称"> </el-table-column>
      <el-table-column prop="password" label="用户名密码"> </el-table-column>
      <el-table-column prop="add" label="相关操作" show-overflow-tooltip>
        <template slot-scope="scope">
          <loginOperate :getnewId="scope.row.id" @getUserList1="getUserList1">
          </loginOperate>
        </template>
      </el-table-column>
    </el-table>
    <!-- 统计页数 -->
    <div class="pagination">
      <span class="pageText">
        共{{ this.totalPages }}页，{{ this.pageSize }}条数据
      </span>
      <!-- 翻页功能 -->
      <div class="turn-container">
        <div class="first-pagenum" @click="firstpage()">
          <img
            src="../../../../assets/greyNext1.png"
            class="firstpage-img"
          />
        </div>
        <div class="first-pagenum" @click="backpage()">
          <img src="../../../../assets/greyNext.png" class="firstpage-img" />
        </div>
        <div class="sta-pagenum">
          <span class="pagenum">{{ this.pagenum }}/{{ this.totalPages }}</span>
        </div>
        <div class="first-pagenum" @click="nextpage()">
          <img src="../../../../assets/blueNext.png" class="nextpage-img" />
        </div>
        <div class="first-pagenum" @click="lastpage()">
          <img
            src="../../../../assets/blueNext1.png"
            class="firstpage-img"
          />
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import loginAdd from "../loginUserManage/components/loginAdd.vue";
import loginOperate from "../loginUserManage/components/loginOperate.vue";
import { getNextmanagementPage, delManageMentById } from "@/api/template.js";
export default {
  components: {
    loginOperate,
    loginAdd,
  },
  props: {},
  data() {
    //这里存放数据
    return {
      drawer: false,
      searchName: "",
      tableData: [],
      multipleSelection: [],
      headerstyle() {
        return "background: #dfeffc;color:black";
      },
      totalPages: 1,
      pageSize: 1,
      pagenum: 1,
      checkdrawer: false,
    };
  },
  watch: {
    multipleSelection() {
      if (this.multipleSelection.length != 0) {
        this.$refs.delbt.style.background = "#2d9dff";
      } else {
        this.$refs.delbt.style.background = "#bfbfbf";
      }
    },
  },
  created() {
    this.getUserList();
  },
  methods: {
    getNextmanagementPage,
    delManageMentById,
    closeAdd() {
      this.drawer = false;
    },
    //获取管理员列表信息
    getUserList() {
      let res = getNextmanagementPage(this, {
        account: this.searchName,
        page: this.pagenum,
        pageSize: 5,
      });
      res.then((res) => {
        this.tableData = res.manageMentVOList;
        this.pageSize = res.totalNum;
        this.totalPages = res.totalPages;
      });
    },
    getUserList1() {
      let res = getNextmanagementPage(this, {
        account: this.searchName,
        page: 1,
        pageSize: 5,
      });
      res.then((res) => {
        this.tableData = res.manageMentVOList;
        this.pageSize = res.totalNum;
        this.totalPages = res.totalPages;
      });
    },
    add() {
      console.log("你好");
    },
    deletemany() {
      this.$confirm("此操作将永久删除这些商品, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          for (let i = 0; i < this.multipleSelection.length; i++) {
            let res = delManageMentById(this, {
              id: this.multipleSelection[i].id,
            });
            res.then(() => {
              this.pagenum = 1;
              this.getUserList();
            });
          }
          this.$message({
            type: "success",
            message: "删除成功!",
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除",
          });
        });
    },
    getuser() {
      console.log("你好");
    },
    selectionChange(val) {
      this.multipleSelection = val;
    },
    //对表中数据进行操作
    handleCheck1() {
      this.$refs.loginCheck.checkdrawer = true;
    },
    handleEdit1() {},
    handleDelete1() {},
    //实现翻页功能
    firstpage() {
      this.pagenum = 1;
      this.getUserList();
    },
    backpage() {
      const back = this.pagenum;
      if (back <= 1) {
        this.pagenum = 1;
      } else {
        this.pagenum -= 1;
      }
      this.getUserList();
    },
    nextpage() {
      const next = this.pagenum;
      const last = this.totalPages;
      if (next >= last) {
        this.pagenum = last;
      } else {
        this.pagenum += 1;
      }
      this.getUserList();
    },
    lastpage() {
      let last = this.totalPages;
      this.pagenum = last;
      this.getUserList();
    },
  },
};
</script>
<style lang="scss" scoped>
//登录页面css
.table-head {
  vertical-align: middle;
  position: relative;
  display: fixed;
  height: 30px;
  margin-left: 20px;
  margin-top: 20px;
}
.add-bt {
  width: 120px;
  height: 35px;
  background: #2d9dff;
  border-radius: 8px;
  position: absolute;
  left: 0px;
}
.add-img {
  width: 22px;
  height: 22px;
  color: #ffffff;
  vertical-align: middle;
}
.add-title {
  width: 68px;
  height: 14px;
  font-size: 14px;
  font-family: DengXian;
  font-weight: 400;
  color: #ffffff;
  margin-left: 6px;
}

.delBt {
  width: 79px;
  height: 35px;
  background: #bfbfbf;
  border-radius: 8px;
  position: absolute;
  left: 150px;
}
.delImg {
  width: 19px;
  height: 21px;
  vertical-align: middle;
}

.del-title {
  font-size: 14px;
  font-family: DengXian;
  font-weight: 400;
  color: #ffffff;
  margin-left: 8px;
}
//搜索框
.search-put {
  padding-left: 10px;
  width: 25%;
  height: 30px;
  background: #ffffff;
  border: 1px solid #b5b5b5;
  border-radius: 6px;
  vertical-align: middle;
  position: absolute;
  right: 40px;
}
.search-put:focus {
  border: 1px solid #4297f1;
}
.search-data {
  position: absolute;
  right: 2px;
  cursor: pointer;
  width: 36px;
  height: 27px;
  background: none;
  vertical-align: middle;
}
.searchText {
  width: 387px;
  height: 30px;
  background: #ffffff;
  border: 1px solid #b5b5b5;
  border-radius: 6px;
  padding-left: 12px;
  vertical-align: middle;
}

.searchBtn {
  margin-left: 15px;
  width: 26px;
  height: 27px;
  background: none;
  vertical-align: middle;
}
.search-img {
  width: 25px;
  height: 25px;
  vertical-align: middle;
}

//表中的内容样式
.Table-container {
  margin-top: 20px;
}
.el-table-column {
  background-color: #ed742a;
}
.el-table {
  width: 100%;
}
.operatebt {
  width: 50px;
  height: 30px;
  font-size: 10px;
  font-family: DengXian;
  line-height: 10px;
  color: #4297f1;
  border: none;

  border-radius: 4px;
}
.operate-del-bt {
  width: 50px;
  height: 30px;
  font-size: 10px;
  font-family: DengXian;
  line-height: 10px;
  color: #4297f1;
  border: none;
  border-radius: 4px;
}

//表底部统计以及分页
.pagination {
  width: 100%;
  display: flex;
  vertical-align: middle;
  height: 100px;
  margin-top: 20px;
}
.pageText {
  font-size: 14px;
  font-family: DengXian;
  font-weight: 400;
  color: #000000;
  opacity: 0.8;
  vertical-align: middle;
  position: absolute;
  margin-top: 15px;
  margin-left: 25px;
}
.turn-container {
  display: flex;
  width: 219px;
  height: 47px;
  position: absolute;
  right: 40px;
  vertical-align: middle;
}
.firstpage-img {
  width: 19px;
  height: 19px;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  margin: auto;
}
.nextpage-img {
  width: 16px;
  height: 16px;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  margin: auto;
}
.first-pagenum {
  position: relative;
  cursor: pointer;
  width: 40px;
  height: 40px;
  margin: 3px;
  border: #ece3e1 solid 1px;
  text-align: center;
  vertical-align: middle;
  background-color: #f7f7f7;
}
.sta-pagenum {
  position: relative;
  cursor: pointer;
  width: 40px;
  height: 40px;
  margin: 3px;
  border: #ece3e1 solid 1px;
  text-align: center;
  vertical-align: middle;
  background-color: #ffffff;
}
.pagenum {
  width: 19px;
  height: 11px;
  font-size: 14px;
  font-family: DengXian;
  font-weight: 400;
  color: #000000;
  opacity: 0.8;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  margin: auto;
}
</style>