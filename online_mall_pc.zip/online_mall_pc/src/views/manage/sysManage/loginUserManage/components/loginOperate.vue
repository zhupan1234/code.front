<template>
  <div>
    <el-button type="text" size="small" @click="getmore(id)">查看</el-button>
    <!--详情抽屉-->
    <template>
      <el-drawer
        size="60%"
        :with-header="false"
        :visible.sync="getnew"
        :direction="direction"
        destroy-on-close
      >
        <div class="formContent">
          <div class="formAdd">
            <img
              class="formAddPic"
              src="../../../../../assets/添加.png"
              alt=""
            />
            <div class="formAddWord">用户查看</div>
            <div class="formClose" @click="getnew = false">
              <img
                class="formClosePic"
                src="../../../../../assets/关闭.png"
                alt=""
              />
            </div>
          </div>
          <div class="formTitle">
            <img
              class="formTitlePic"
              src="../../../../../assets/小房子.png"
              alt=""
            />
            <div class="formTitleWord">用户名名称</div>
          </div>
          <div class="more">{{ addForm.account }}</div>
          <div class="formTitle">
            <img
              class="formTitlePic"
              src="../../../../../assets/小房子.png"
              alt=""
            />
            <div class="formTitleWord">用户名密码</div>
          </div>
          <div class="more">{{ addForm.password }}</div>
        </div>
      </el-drawer>
    </template>
    <el-button
      type="text"
      size="small"
      style="margin-left: 20px"
      @click="change1(getnewId)"
      >编辑</el-button
    >
    <!--编辑抽屉-->
    <template>
      <el-drawer
        size="60%"
        :with-header="false"
        :visible.sync="changenew"
        :direction="direction"
        destroy-on-close
      >
        <div class="formContent">
          <div class="formAdd">
            <img
              class="formAddPic"
              src="../../../../../assets/添加.png"
              alt=""
            />
            <div class="formAddWord">编辑用户信息</div>
            <div class="formClose" @click="changenew = false">
              <img
                class="formClosePic"
                src="../../../../../assets/关闭.png"
                alt=""
              />
            </div>
          </div>
          <el-form :model="addForm" :rules="rules" ref="ruleAddForm">
            <div class="formTitle">
              <img
                class="formTitlePic"
                src="../../../../../assets/小房子.png"
                alt=""
              />
              <div class="formTitleWord">用户名名称</div>
            </div>
            <div class="formNameInput">
              <el-input
                size="mini"
                v-model="addForm.account"
                clearable
              ></el-input>
            </div>
            <div class="formTitle">
              <img
                class="formTitlePic"
                src="../../../../../assets/小房子.png"
                alt=""
              />
              <span class="formTitleWord">用户名密码</span>
            </div>
            <div class="formNameInput">
              <el-input
                size="mini"
                v-model="addForm.password"
                clearable
              ></el-input>
            </div>
            <div class="formButton">
              <el-button type="info" @click="changenew = false">
                <span class="formButton1">取消</span>
              </el-button>
              <el-button @click="change(getnewId)">
                <span class="formButton1">确认</span>
              </el-button>
            </div>
          </el-form>
        </div>
      </el-drawer>
    </template>

    <el-button
      type="text"
      size="small"
      style="margin-left: 20px"
      @click="Delete(getnewId)"
      >删除</el-button
    >
  </div>
</template>
<script>
import { delManageMentById } from "@/api/template.js";
import { getManageMentById } from "@/api/template.js";
import { editManageMentOrg } from "@/api/template.js";
export default {
  props: ["getnewId"],
  data() {
    return {
      id: "",
      //成员名字显示
      closeAndChange: true,
      numberName: "",
      input: "",
      textarea: "",
      getnew: false,
      changenew: false,
      direction: "rtl",
      addForm: {
        account: "asjf",
        password: "ihoafjk",
      },
      rules: {
        name: [
          { required: true, message: "请输入用户名名称", trigger: "blur" },
        ],
        price: [
          { required: true, message: "请输入用户名密码", trigger: "blur" },
        ],
      },
    };
  },
  created() {
    setTimeout(() => {
      this.id = this.getnewId;
    }, 200);
  },
  methods: {
    delManageMentById,
    getManageMentById,
    editManageMentOrg,

    //编辑支部信息
    change1(id) {
      this.getmore(id);
      this.changenew = true;
      this.getnew = false;
    },
    Delete(id) {
      this.$confirm("此操作将永久删除该商品, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          let res = delManageMentById(this, { id: id });
          res.then(() => {
            this.pagenum = 1;
            this.$emit("getUserList1");
          });
          this.$message({
            type: "success",
            message: "删除成功!",
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除",
          });
        });
    },

    /*  let res = delManageMentById(this, { id: id });
        res.then(() => {
          this.pagenum = 1;
        this.$emit("getUserList1"); */

    //确定更改支部信息
    change(form) {
      // this.$refs[form].validate((valid) => {
      //   if (valid) {
      //     alert("支部信息修改成功！！！");
      //     this.addForm.secId = this.dataCard[this.myradio - 1].id;
      //     if(this.myarr.length!==0){
      //       this.membs = this.myarr;
      //     };
      //     let res = editPartyOrg(this, {
      //       name: this.addForm.name,
      //       introduction: this.addForm.introduction,
      //       secId: this.addForm.secId,
      //       membs: this.membs,
      //       id: this.addForm.id,
      //     });
      //     res.then(() => {
      //       //console.log(res);
      //       this.changenew = false;
      //       this.$emit("getUserList");
      //       this.closeAndChange = true;
      //     });
      //   } else {
      //     alert("请将信息填写完整，再单击确认");
      //     return false;
      //   }
      // });
    },
    change(id) {
      let res = editManageMentOrg(this, {
        account: this.addForm.account,
        password: this.addForm.password,
        id: id,
      });
      res.then(() => {
        this.changenew = false;
        this.$emit("getUserList");
        this.closeAndChange = true;
      });
    },
    getmore(id) {
      this.getnew = true;
      console.log("fangfa ");
      let param = {
        id: id,
      };
      this.getManageMentById(this, param).then((res) => {
        console.log(res), (this.addForm.account = res.account);
        this.addForm.password = res.password;
      });
    },
    //根据支部id获取支部详细信息
    /*     getmore(id) {
      this.getnew = true;
      let res =getManageMentById(this, { id: id });
        res.then(() => {
          console.log("dfhjkas")
       this.addForm.account=res.account;
       this.addForm.password=res.password;
       console.log(res);
        });
    }, */
  },
};
</script>
<style lang="scss" scoped>
.more {
  margin-top: 20px;
  margin-left: 60px;
  font-size: 14px;
  font-family: DengXian;
  font-weight: 500;
}
.formAdd {
  position: relative;
  display: flex;
  align-items: center;
  margin-top: 7px;
  width: 100%;
  height: 49px;
  background: #e9f4fd;
  .formAddPic {
    margin-left: 27px;
    width: 30px;
    height: 30px;
  }

  .formAddWord {
    margin-left: 11px;
    height: 18px;
    font-size: 18px;
    font-family: DengXian;
    font-weight: 400;
    color: #2a92ed;
  }
  .formClose {
    position: absolute;
    cursor: pointer;
    top: -60px;
    right: -60px;
    width: 120px;
    height: 120px;
    background: #cae4fa;
    border-radius: 50%;
  }
  .formClosePic {
    position: absolute;
    top: 76px;
    left: 28px;
    width: 22px;
    height: 22px;
  }
}

.formTitle {
  display: flex;
  align-items: center;
  margin-top: 30px;
  height: 16px;
  .formTitlePic {
    width: 16px;
    height: 16px;
    margin-left: 28px;
  }
  .formTitleWord {
    margin-left: 17px;
    height: 15px;
    font-size: 16px;
    font-family: DengXian;
    font-weight: 400;
    color: #323232;
  }
}

.formNameInput {
  height: 28px;
  margin-top: 5px;
  margin-left: 57px;
  width: 90%;
  .el-input__inner {
    height: 28px;
    border-radius: 2px;
  }
}
.formButton {
  position: fixed;
  bottom: 0px;
  display: flex;
  justify-content: center;
  width: 60%;
  box-shadow: 0px -2px 4px 0px #cae4fa;
  .el-button {
    align-items: center;
    width: 120px;
    height: 40px;
    margin: 15px;
    background: #bfbfbf;
    border-color: #bfbfbf;
    border-radius: 20px;
  }
  .el-button:last-child {
    background: #2a92ed;
    border-color: #2a92ed;
  }
}
.formButton1 {
  font-size: 16px;
  font-family: DengXian;
  font-weight: 400;
  color: #ffffff;
}
</style>
