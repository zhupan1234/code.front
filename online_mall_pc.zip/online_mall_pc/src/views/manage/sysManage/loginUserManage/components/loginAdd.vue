<template>
  <div>
    <el-form :model="addForm" :rules="rules" ref="ruleAddForm">
      <div class="formContent">
        <div class="formAdd">
          <img class="formAddPic" src="@/assets/添加.png" alt="" />
          <div class="formAddWord">添加用户</div>
          <div class="formClose" @click="closeAddSon">
            <img class="formClosePic" src="@/assets/关闭.png" alt="" />
          </div>
        </div>
        <!--表单 名称 简介-->
        <div class="formTitle">
          <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
          <div class="formTitleWord">用户名名称</div>
        </div>
        <div class="formNameInput">
          <el-form-item prop="name">
            <el-input
              size="mini"
              v-model="addForm.name"
              placeholder="请输入用户名名称"
              clearable
            ></el-input>
          </el-form-item>
        </div>
        <div class="formTitle">
          <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
          <span class="formTitleWord">用户密码</span>
        </div>
        <div class="formNameInput">
          <el-form-item prop="cipher">
            <el-input
              v-model="addForm.cipher"
              size="mini"
              placeholder="请输入用户密码"
              clearable
            >
            </el-input>
          </el-form-item>
        </div>
      </div>
      <!--表单按钮-->
      <div class="formButton">
        <el-button type="info" @click="closeAddSon">
          <span class="formButton1">取消</span>
        </el-button>
        <el-button @click="addUser('ruleAddForm')">
          <span class="formButton1">确认</span>
        </el-button>
      </div>
    </el-form>
  </div>
</template>
<script>
import { addManageMent } from "@/api/template.js";
export default {
  data() {
    return {
      addForm: {
        name: "",
        cipher: "",
      },
      rules: {
        name: [
          { required: true, message: "请输入用户名名称", trigger: "blur" },
        ],
        cipher: [
          { required: true, message: "请输入用户密码", trigger: "blur" },
        ],
      },
      drawer: false,
    };
  },
  methods: {
    addManageMent,
    closeAddSon() {
      this.drawer = false;
      this.$emit("closeAdd", this.drawer);
    },
    addUser() {
       if (this.addForm.name == "" ||this.addForm.cipher== "") {
          alert("请补全管理员信息");
        } else{
      let res = addManageMent(this, {
        account: this.addForm.name,
        password:this.addForm.cipher
      });
      res.then(() => {
        this.drawer = false;
        this.$emit("getUserList");
        this.$emit("closeAdd", this.drawer);
      });
      }
    },
    // addUser(form) {
    //   this.$refs[form].validate((valid) => {
    //     if (valid) {
    //       alert("支部信息提交成功！！！");
    //       //添加时删除label属性，arr只传递id
    //       this.myarr.forEach((element) => {
    //         if (element.label) {
    //           delete element.label;
    //         }
    //       });
    //       this.addForm.secId = this.myradio;
    //       this.membs = this.myarr;
    //       let res = addPartyOrg(this, {
    //         name: this.addForm.name,
    //         introduction: this.addForm.introduction,
    //         photo: this.addForm.photo,
    //         score: this.addForm.score,
    //         secId: this.addForm.secId,
    //         likeNum: this.addForm.likeNum,
    //         membs: this.membs,
    //         id: this.addForm.id,
    //       });
    //       res.then(() => {
    //         // console.log(res);
    //         this.drawer = false;
    //         this.$emit("getUserList");
    //         this.$emit("closeAdd", this.drawer);
    //       });
    //     } else {
    //       alert("请将信息填写完整，再单击确认");
    //       return false;
    //     }
    //   });
    // },
  },
};
</script>
<style lang="scss" scoped>
.formAdd {
  position: relative;
  display: flex;
  align-items: center;
  margin-top: 7px;
  width: 100%;
  height: 49px;
  background: #e9f4fd;
  .formAddPic {
    margin-left: 27px;
    width: 30px;
    height: 30px;
  }

  .formAddWord {
    margin-left: 11px;
    height: 18px;
    font-size: 18px;
    font-family: DengXian;
    font-weight: 400;
    color: #2a92ed;
  }
  .formClose {
    position: absolute;
    cursor: pointer;
    top: -60px;
    right: -60px;
    width: 120px;
    height: 120px;
    background: #cae4fa;
    border-radius: 50%;
  }
  .formClosePic {
    position: absolute;
    top: 76px;
    left: 28px;
    width: 22px;
    height: 22px;
  }
}

.formTitle {
  display: flex;
  align-items: center;
  margin-top: 30px;
  height: 16px;
  .formTitlePic {
    width: 16px;
    height: 16px;
    margin-left: 28px;
  }
  .formTitleWord {
    margin-left: 17px;
    height: 15px;
    font-size: 16px;
    font-family: DengXian;
    font-weight: 400;
    color: #323232;
  }
}

.formNameInput {
  height: 28px;
  margin-top: 5px;
  margin-left: 57px;
  width: 90%;
  .el-input__inner {
    height: 28px;
    border-radius: 2px;
  }
}
.formButton {
  position: fixed;
  bottom: 0px;
  display: flex;
  justify-content: center;
  width: 60%;
  box-shadow: 0px -2px 4px 0px #cae4fa;
  .el-button {
    align-items: center;
    width: 120px;
    height: 40px;
    margin: 15px;
    background: #bfbfbf;
    border-color: #bfbfbf;
    border-radius: 20px;
  }
  .el-button:last-child {
    background: #2a92ed;
    border-color: #2a92ed;
  }
}
.formButton1 {
  font-size: 16px;
  font-family: DengXian;
  font-weight: 400;
  color: #ffffff;
}
</style>
