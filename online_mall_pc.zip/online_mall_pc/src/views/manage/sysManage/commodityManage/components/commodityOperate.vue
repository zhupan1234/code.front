<template>
  <div>
    <el-button type="text" size="small" @click="getmore(getnewId)"
      >查看</el-button
    >
    <!--详情抽屉-->
    <template>
      <el-drawer
        size="60%"
        :with-header="false"
        :visible.sync="getnew"
        :direction="direction"
        destroy-on-close
      >
        <div class="formContent">
          <div class="formAdd">
            <img
              class="formAddPic"
              src="../../../../../assets/添加.png"
              alt=""
            />
            <div class="formAddWord">商品详情</div>
            <div class="formClose" @click="getnew = false">
              <img
                class="formClosePic"
                src="../../../../../assets/关闭.png"
                alt=""
              />
            </div>
          </div>

          <div
            v-for="(addForm, index) in commodityList"
            :key="index"
            class="commidtyCT"
          >
            <el-collapse>
              <el-collapse-item class="table2">
                <template slot="title">
                  <div>
                    <el-row class="rowInput">
                      <el-col :span="12" class="colInput">
                        <div class="formTitle">
                          <img
                            class="formTitlePic"
                            src="../../../../../assets/小房子.png"
                            alt=""
                          />
                          <div class="formTitleWord">商品名称</div>
                        </div>
                        <div class="more">{{ addForm.name }}</div>
                      </el-col>
                      <el-col :span="12" class="colInput">
                        <div class="formTitle">
                          <img
                            class="formTitlePic"
                            src="../../../../../assets/小房子.png"
                            alt=""
                          />
                          <div class="formTitleWord">商品规格</div>
                        </div>
                        <div class="more">{{ addForm.specificationName }}</div>
                      </el-col>
                    </el-row>
                  </div>
                </template>
                <div>
                  <el-row class="rowInput">
                    <el-col :span="12" class="colInput">
                      <div class="formTitle">
                        <img
                          class="formTitlePic"
                          src="../../../../../assets/小房子.png"
                          alt=""
                        />
                        <div class="formTitleWord">商品简介</div>
                      </div>
                      <div class="more">{{ addForm.introduction }}</div>
                    </el-col>
                    <el-col :span="12" class="colInput">
                      <div class="formTitle">
                        <img
                          class="formTitlePic"
                          src="../../../../../assets/小房子.png"
                          alt=""
                        />
                        <div class="formTitleWord">商品类别</div>
                      </div>
                      <div class="more">{{ addForm.typeName }}</div>
                    </el-col>
                  </el-row>
                </div>

                <div>
                  <el-row class="rowInput">
                    <el-col :span="12" class="colInput">
                      <div class="formTitle">
                        <img
                          class="formTitlePic"
                          src="../../../../../assets/小房子.png"
                          alt=""
                        />
                        <div class="formTitleWord">商品库存</div>
                      </div>
                      <div class="more">{{ addForm.stock }}</div>
                    </el-col>
                    <el-col :span="12" class="colInput">
                      <div class="formTitle">
                        <img
                          class="formTitlePic"
                          src="../../../../../assets/小房子.png"
                          alt=""
                        />
                        <div class="formTitleWord">商品价格</div>
                      </div>
                      <div class="more">{{ addForm.price }}</div>
                    </el-col>
                  </el-row>
                </div>

                <div class="formTitle">
                  <img
                    class="formTitlePic"
                    src="../../../../../assets/小房子.png"
                    alt=""
                  />
                  <div class="formTitleWord">商品状态</div>
                </div>
                <div class="more">{{ addForm.status }}</div>
              </el-collapse-item>
            </el-collapse>
          </div>
        </div>
      </el-drawer>
    </template>

    <!--编辑抽屉-->
    <el-button
      type="text"
      size="small"
      @click="change1(getnewId)"
      style="margin-left: 20px"
      >编辑</el-button
    >
    <template>
      <el-drawer
        size="60%"
        :with-header="false"
        :visible.sync="changenew"
        :direction="direction"
        destroy-on-close
      >
        <div class="formContent">
          <div class="formAdd">
            <img
              class="formAddPic"
              src="../../../../../assets/添加.png"
              alt=""
            />
            <div class="formAddWord">商品编辑</div>
            <div class="formClose" @click="changenew = false">
              <img
                class="formClosePic"
                src="../../../../../assets/关闭.png"
                alt=""
              />
            </div>
          </div>

          <div
            v-for="(addForm, index) in commodityList"
            :key="index"
            class="commidtyCT"
          >
            <el-collapse>
              <el-collapse-item class="table2">
                <template slot="title">
                  <div>
                    <el-row class="rowInput">
                      <el-col :span="12" class="colInput">
                        <div class="formTitle">
                          <img
                            class="formTitlePic"
                            src="../../../../../assets/小房子.png"
                            alt=""
                          />
                          <div class="formTitleWord">商品名称</div>
                        </div>
                        <div class="more">
                          <el-input
                            size="mini"
                            v-model="addForm.name"
                            clearable
                          ></el-input>
                        </div>
                      </el-col>
                      <el-col :span="12" class="colInput">
                        <div class="formTitle">
                          <img
                            class="formTitlePic"
                            src="../../../../../assets/小房子.png"
                            alt=""
                          />
                          <div class="formTitleWord">商品规格</div>
                        </div>
                        <div class="more">
                          <el-input
                            size="mini"
                            v-model="addForm.specificationName"
                            clearable
                          ></el-input>
                        </div>
                      </el-col>
                    </el-row>
                  </div>
                </template>
                <div>
                  <el-row class="rowInput">
                    <el-col :span="12" class="colInput">
                      <div class="formTitle">
                        <img
                          class="formTitlePic"
                          src="../../../../../assets/小房子.png"
                          alt=""
                        />
                        <div class="formTitleWord">商品简介</div>
                      </div>
                      <div class="more">
                        <el-input
                          size="mini"
                          v-model="addForm.introduction"
                          clearable
                        ></el-input>
                      </div>
                    </el-col>
                    <el-col :span="12" class="colInput">
                      <div class="formTitle">
                        <img
                          class="formTitlePic"
                          src="../../../../../assets/小房子.png"
                          alt=""
                        />
                        <div class="formTitleWord">商品类别</div>
                      </div>

                      <!-- <div class="more">{{ addForm.typeName }}</div> -->
                      <div class="formNameInput">
                        <!-- <el-form-item prop="typeName">
                <el-input v-model="addForm.typeName" size="mini"> </el-input>
              </el-form-item> -->
                        <el-select
                          v-model="addForm.commodityTypeId"
                          placeholder="商品类别"
                          class="optionSelect"
                          clearable
                        >
                          <el-option
                            v-for="item in typeKind"
                            :key="item.id"
                            :label="item.name"
                            :value="item.id"
                          >
                          </el-option>
                        </el-select>
                      </div>
                    </el-col>
                  </el-row>
                </div>

                <div>
                  <el-row class="rowInput">
                    <el-col :span="12" class="colInput">
                      <div class="formTitle">
                        <img
                          class="formTitlePic"
                          src="../../../../../assets/小房子.png"
                          alt=""
                        />
                        <div class="formTitleWord">商品库存</div>
                      </div>
                      <div class="more">
                        <el-input
                          size="mini"
                          v-model="addForm.stock"
                          clearable
                        ></el-input>
                      </div>
                    </el-col>
                    <el-col :span="12" class="colInput">
                      <div class="formTitle">
                        <img
                          class="formTitlePic"
                          src="../../../../../assets/小房子.png"
                          alt=""
                        />
                        <div class="formTitleWord">商品价格</div>
                      </div>
                      <div class="more">
                        <el-input
                          size="mini"
                          v-model="addForm.price"
                          clearable
                        ></el-input>
                      </div>
                    </el-col>
                  </el-row>
                </div>

                <div>
                  <el-row class="rowInput">
                    <el-col :span="12" class="colInput">
                      <div class="formTitle">
                        <img
                          class="formTitlePic"
                          src="../../../../../assets/小房子.png"
                          alt=""
                        />
                        <div class="formTitleWord">商品状态</div>
                      </div>
                      <!-- <div class="more">{{ addForm.status }}</div> -->
                      <div class="formNameInput">
                        <!-- <el-form-item prop="status">
                <el-input
                  size="mini"
                  v-model="addForm.status"
                  clearable
                ></el-input>
              </el-form-item> -->
                        <el-select
                          v-model="addForm.status"
                          placeholder="商品状态"
                          class="optionSelect"
                          clearable
                        >
                          <el-option
                            v-for="item in statusKind"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value"
                          >
                          </el-option>
                        </el-select>
                      </div>
                    </el-col>
                    <el-col :span="12" class="colInput">
                      <div class="formTitle">
                        <img
                          class="formTitlePic"
                          src="../../../../../assets/小房子.png"
                          alt=""
                        />
                        <div class="formTitleWord">商品价格</div>
                      </div>
                      <div class="more">
                        <el-button type="primary" @click="edit(addForm)">
                          编辑</el-button
                        >
                      </div>
                    </el-col>
                  </el-row>
                </div>
              </el-collapse-item>
            </el-collapse>
          </div>
        </div>
      </el-drawer>
    </template>

    <!-- <div class="formNameInput">
              <el-form-item prop="specificationsName">
                <el-input
                  size="mini"
                  v-model="addForm.specificationsName"
                  clearable
                ></el-input>
              </el-form-item>
            </div> -->
    <el-button
      type="text"
      size="small"
      style="margin-left: 20px"
      @click="Delete(getnewId)"
      >删除</el-button
    >
  </div>
</template>
<script>
import {
  delCommodityById,
  getCommodityById,
  checkType,
  editCommodityById,
} from "@/api/template.js";
export default {
  props: ["getnewId"],
  data() {
    return {
      commodityCheck: false,
      statusKind: [
        {
          value: 0,
          label: "未上架",
        },
        {
          value: 1,
          label: "在售",
        },
        {
          value: 2,
          label: "下架",
        },
        {
          value: 3,
          label: "售完",
        },
      ],
      commodityList: [],
      typeKind: [],
      //成员名字显示
      closeAndChange: true,
      numberName: "",
      input: "",
      textarea: "",
      getnew: false,
      changenew: false,
      direction: "rtl",
      id: "",
      addForm: {
        name: "jiew",
        introduction: "fs",
        price: 12,
        typeName: "fa",
        stock: 12,
        status: "和",
        commodityId: 20,
        specificationsId: 28,
        commodityTypeId: 9,
        description: "看监考老师的功夫",
        specificationsName: "九年开始打",
        attachmentUrl: "ksdfa",
      },

      rules: {
        name: [{ required: true, message: "请输入商品名称", trigger: "blur" }],
        price: [{ required: true, message: "请输入商品价格", trigger: "blur" }],
      },
    };
  },
  created() {
    setTimeout(() => {
      this.id = this.getnewId;
    }, 1000);
    this.getType();
  },
  methods: {
    editCommodityById,
    checkType,
    delCommodityById,
    getCommodityById,
    //编辑支部信息
    get() {
      this.$emit("getUserList1");
    },
    change1(id) {
      this.getmore1(id);
      this.changenew = true;
      this.getnew = false;
      console.log(this.commodityList);
    },
    checkCom() {
      this.commodityCheck = !this.commodityCheck;
    },
    getType() {
      this.checkType(this, {}).then((res) => {
        this.typeKind = res;
      });
    },
    Delete(id) {
      this.$confirm("此操作将永久删除该商品类别, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          let res = delCommodityById(this, { commodityId: id });
          res.then(() => {
            this.get();
          });

          this.$message({
            type: "success",
            message: "删除成功!",
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除",
          });
        });
    },
    //确定更改支部信息
    change(form) {
      // this.$refs[form].validate((valid) => {
      //   if (valid) {
      //     alert("支部信息修改成功！！！");
      //     this.addForm.secId = this.dataCard[this.myradio - 1].id;
      //     if(this.myarr.length!==0){
      //       this.membs = this.myarr;
      //     };
      //     let res = editPartyOrg(this, {
      //       name: this.addForm.name,
      //       introduction: this.addForm.introduction,
      //       secId: this.addForm.secId,
      //       membs: this.membs,
      //       id: this.addForm.id,
      //     });
      //     res.then(() => {
      //       //console.log(res);
      //       this.changenew = false;
      //       this.$emit("getUserList");
      //       this.closeAndChange = true;
      //     });
      //   } else {
      //     alert("请将信息填写完整，再单击确认");
      //     return false;
      //   }
      // });
    },
    //根据支部id获取支部详细信息

    getmore1(id) {
      this.getnew = true;
      console.log("fangfa ");
      console.log(id);
      let param = {
        commodityId: id,
      };
      this.getCommodityById(this, param).then((res) => {
        console.log("afuhid");
        console.log(res);
        this.commodityList = res;

        console.log(this.commodityList);
        (this.addForm.name = res.name),
          (this.addForm.introduction = res.introduction),
          (this.addForm.price = res.price),
          (this.addForm.status = this.getState(res.status)),
          (this.addForm.typeName = res.typeName),
          (this.addForm.specificationsId = res.specificationsId),
          (this.addForm.commodityTypeId = res.commodityTypeId),
          (this.addForm.description = res.description),
          (this.addForm.specificationsName = res.specificationName),
          (this.addForm.attachmentUrl = res.attachmentUrl);
      });
    },
    getmore(id) {
      this.getnew = true;
      console.log("fangfa ");
      console.log(id);
      let param = {
        commodityId: id,
      };
      this.getCommodityById(this, param).then((res) => {
        console.log("afuhid");
        console.log(res);
        this.commodityList = res;
        for (let i = 0; i < this.commodityList.length; i++) {
          this.commodityList[i].status = this.getState(
            this.commodityList[i].status
          );
          console.log("dfhjkakl;");
        }
        console.log(this.commodityList);
        (this.addForm.name = res.name),
          (this.addForm.introduction = res.introduction),
          (this.addForm.price = res.price),
          (this.addForm.status = this.getState(res.status)),
          (this.addForm.typeName = res.typeName),
          (this.addForm.specificationsId = res.specificationsId),
          (this.addForm.commodityTypeId = res.commodityTypeId),
          (this.addForm.description = res.description),
          (this.addForm.specificationsName = res.specificationName),
          (this.addForm.attachmentUrl = res.attachmentUrl);
      });
    },

    edit(addForm) {
      console.log("bianji");
      let param = {
        name: addForm.name,
        price: addForm.price,
        status: addForm.status,
        introduction: addForm.introduction,
        description: addForm.description,
        specificationsName: addForm.specificationsName,
        stock: addForm.stock,
        commodityTypeId: addForm.commodityTypeId,
        commodityId: addForm.id,
        specificationsId: addForm.specificationsId,
      };
      this.editCommodityById(this, param).then((res) => {
        console.log(res);
        this.get();
        this.changenew = false;
      });

      console.log(addForm);
    },
    getState(status) {
      console.log("执行");
      if (status == 0) {
        return "未上架";
      }
      if (status == 1) {
        return "在售";
      }
      if (status == 2) {
        return "下架";
      }
      if (status == 3) {
        return "售完";
      }
    },
  },
};
</script>
<style lang="scss" scoped>
.more {
  margin-top: 20px;
  margin-left: 60px;
  font-size: 14px;
  font-family: DengXian;
  font-weight: 500;
}
.formAdd {
  position: relative;
  display: flex;
  align-items: center;
  margin-top: 7px;
  width: 100%;
  height: 49px;
  background: #e9f4fd;
  .formAddPic {
    margin-left: 27px;
    width: 30px;
    height: 30px;
  }

  .formAddWord {
    margin-left: 11px;
    height: 18px;
    font-size: 18px;
    font-family: DengXian;
    font-weight: 400;
    color: #2a92ed;
  }
  .formClose {
    position: absolute;
    cursor: pointer;
    top: -60px;
    right: -60px;
    width: 120px;
    height: 120px;
    background: #cae4fa;
    border-radius: 50%;
  }
  .formClosePic {
    position: absolute;
    top: 76px;
    left: 28px;
    width: 22px;
    height: 22px;
  }
}

.formTitle {
  display: flex;
  align-items: center;
  margin-top: 30px;
  height: 16px;
  .formTitlePic {
    width: 16px;
    height: 16px;
    margin-left: 28px;
  }
  .formTitleWord {
    margin-left: 17px;
    height: 15px;
    font-size: 16px;
    font-family: DengXian;
    font-weight: 400;
    color: #323232;
  }
}

.formNameInput {
  height: 28px;
  margin-top: 18px;
  margin-left: 57px;
  width: 90%;
  .el-input__inner {
    height: 28px;
    border-radius: 2px;
  }
}
.formButton {
  position: fixed;
  bottom: 0px;
  display: flex;
  justify-content: center;
  width: 60%;
  box-shadow: 0px -2px 4px 0px #cae4fa;
  .el-button {
    align-items: center;
    width: 120px;
    height: 40px;
    margin: 15px;
    background: #bfbfbf;
    border-color: #bfbfbf;
    border-radius: 20px;
  }
  .el-button:last-child {
    background: #2a92ed;
    border-color: #2a92ed;
  }
}
.formButton1 {
  font-size: 16px;
  font-family: DengXian;
  font-weight: 400;
  color: #ffffff;
}
.commidtyCT {
  margin-top: 30px;
}
/deep/.el-input--suffix .el-input__inner {
  height: 30px;
}
.table2 {
  /deep/ .el-collapse-item__header {
    height: 100px;
  }
}
/deep/.el-row {
  width: 1000px;
}
</style>