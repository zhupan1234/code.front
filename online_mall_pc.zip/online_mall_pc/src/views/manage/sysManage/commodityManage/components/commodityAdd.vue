<template>
  <div>
    <el-form :model="addForm" ref="ruleAddForm">
      <div class="formContent">
        <div class="formAdd">
          <img class="formAddPic" src="@/assets/添加.png" alt="" />
          <div class="formAddWord">添加商品</div>
          <div class="formClose" @click="closeAdd">
            <img class="formClosePic" src="@/assets/关闭.png" alt="" />
          </div>
        </div>
        <!--表单 名称 简介-->
        <div class="formTitle">
          <img
            class="formTitlePic"
            src="../../../../../assets/小房子.png"
            alt=""
          />
          <div class="formTitleWord">商品名称</div>
        </div>
        <div class="formNameInput">
          <el-form-item prop="name">
            <el-input size="mini" v-model="addForm.name" clearable></el-input>
          </el-form-item>
        </div>
        <div class="formTitle">
          <img
            class="formTitlePic"
            src="../../../../../assets/小房子.png"
            alt=""
          />
          <span class="formTitleWord">商品简介</span>
        </div>
        <div class="formNameInput">
          <el-form-item prop="introduction">
            <el-input
              size="mini"
              v-model="addForm.introduction"
              clearable
            ></el-input>
          </el-form-item>
        </div>
        <div class="formTitle">
          <img
            class="formTitlePic"
            src="../../../../../assets/小房子.png"
            alt=""
          />
          <div class="formTitleWord">商品类别</div>
        </div>
        <div class="formNameInput">
          <!-- <el-form-item prop="typeName">
                <el-input v-model="addForm.typeName" size="mini"> </el-input>
              </el-form-item> -->
          <el-select
            v-model="addForm.typeName"
            placeholder="商品类别"
            class="optionSelect"
            clearable
          >
            <el-option
              v-for="item in typeKind"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            >
            </el-option>
          </el-select>
        </div>

        <div class="formTitle">
          <img
            class="formTitlePic"
            src="../../../../../assets/小房子.png"
            alt=""
          />
          <div class="formTitleWord">商品库存</div>
        </div>
        <div class="formNameInput">
          <el-form-item prop="stock">
            <el-input size="mini" v-model="addForm.stock" clearable></el-input>
          </el-form-item>
        </div>
        <div class="formTitle">
          <img
            class="formTitlePic"
            src="../../../../../assets/小房子.png"
            alt=""
          />
          <div class="formTitleWord">商品价格</div>
        </div>
        <div class="formNameInput">
          <el-form-item prop="price">
            <el-input size="mini" v-model="addForm.price" clearable></el-input>
          </el-form-item>
        </div>

        <div class="formTitle">
          <img
            class="formTitlePic"
            src="../../../../../assets/小房子.png"
            alt=""
          />
          <div class="formTitleWord">商品状态</div>
        </div>
        <div class="formNameInput">
          <!-- <el-form-item prop="status">
                <el-input
                  size="mini"
                  v-model="addForm.status"
                  clearable
                ></el-input>
              </el-form-item> -->
          <el-select
            v-model="addForm.status"
            placeholder="商品状态"
            class="optionSelect"
            clearable
          >
            <el-option
              v-for="item in statusKind"
              :key="item.value"
              :label="item.label"
              :value="item.value"
            >
            </el-option>
          </el-select>
        </div>
        <div class="formTitle">
          <img
            class="formTitlePic"
            src="../../../../../assets/小房子.png"
            alt=""
          />
          <div class="formTitleWord">概述</div>
        </div>
        <div class="formNameInput">
          <el-form-item prop="description">
            <el-input
              size="mini"
              v-model="addForm.description"
              clearable
            ></el-input>
          </el-form-item>
        </div>

        <div class="formTitle">
          <img
            class="formTitlePic"
            src="../../../../../assets/小房子.png"
            alt=""
          />
          <div class="formTitleWord">规格名称</div>
        </div>
        <div class="formNameInput">
          <el-form-item prop="specificationsName">
            <el-input
              size="mini"
              v-model="addForm.specificationsName"
              clearable
            ></el-input>
          </el-form-item>
        </div>

        <!-- <div class="formTitle">
          <img
            class="formTitlePic"
            src="../../../../../assets/小房子.png"
            alt=""
          />
          <div class="formTitleWord">展示图片</div>
        </div>
        <div class="formNameInput">
        </div> -->

        <div class="formTitle">
          <img
            class="formTitlePic"
            src="../../../../../assets/小房子.png"
            alt=""
          />
          <div class="formTitleWord">轮播图片</div>
        </div>
        <div class="imgWrapper">
          <el-upload
            action="#"
            multiple
            :limit="1"
            accept=".jpg,.jpeg,.png"
            list-type="picture-card"
            :auto-upload="true"
            ref="pictureUpload"
            :http-request="httpRequest"
            :on-change="handleChange"
          >
            <i slot="default" class="el-icon-plus"></i>
            <div slot="file" slot-scope="{ file }">
              <img
                class="el-upload-list__item-thumbnail"
                :src="file.url"
                alt=""
              />
              <span class="el-upload-list__item-actions">
                <span
                  class="el-upload-list__item-preview"
                  @click="handlePictureCardPreview(file)"
                >
                  <i class="el-icon-zoom-in"></i>
                </span>
                <span
                  v-if="!disabled"
                  class="el-upload-list__item-delete"
                  @click="handleRemove(file)"
                >
                  <i class="el-icon-delete"></i>
                </span>
              </span>
            </div>
          </el-upload>
          <el-dialog :visible.sync="dialogVisible" append-to-body>
            <div style="width: 100%; padding: 30px">
              <img width="100%" :src="dialogImageUrl" alt="" />
            </div>
          </el-dialog>
        </div>
      </div>
      <!--表单按钮-->
      <div class="formButton">
        <el-button type="info" @click="closeAdd">
          <span class="formButton1">取消</span>
        </el-button>
        <el-button @click="addUser()">
          <span class="formButton1">确认</span>
        </el-button>
      </div>
    </el-form>
  </div>
</template>
<script>
import { addCommodityOrg, checkType } from "@/api/template.js";
export default {
  data() {
    return {
      dialogVisible: false,
      dialogImageUrl: "",
      addForm: {
        name: "",
        introduction: "",
        stock: "",
        typeName: "",
        specificationsName: "",
        status: "",
        fileList: [],

        disabled: false,
        attachmentUrl: "",
      },

      drawer: false,
      statusKind: [
        {
          value: 0,
          label: "未上架",
        },
        {
          value: 1,
          label: "在售",
        },
        {
          value: 2,
          label: "下架",
        },
        {
          value: 3,
          label: "售完",
        },
      ],
      typeKind: [],
      fileList: {
        name: "food2.jpeg",
        url: "/commodityRotationChart/handPaintedMask0.png",
      },
      fileList1: {
        name: "food2.jpeg",
        url: "/commodityRotationChart/ginkgoSquirrelCardSet0.png",
      },
    };
  },
  methods: {
    checkType,
    addCommodityOrg,
    closeAdd() {
      this.$emit("closeAdd", this.drawer);
    },
    getType() {
      this.checkType(this, {}).then((res) => {
        this.typeKind = res;
      });
    },
    get() {
      this.$emit("getUserList1");
    },
    addUser() {
      console.log(this.attachmentUrl);
      if (
        this.addForm.name == "" ||
        this.addForm.introduction == "" ||
        this.addForm.stock == "" ||
        this.addForm.typeName == "" ||
        this.addForm.price == "" ||
        this.addForm.specificationsName == ""
      ) {
        alert("请补全商品信息");
      } else {
        let param = {
          name: this.addForm.name,
          price: this.addForm.price,
          status: this.addForm.status,
          introduction: this.addForm.introduction,
          description: this.addForm.description,
          specificationsName: this.addForm.specificationsName,
          stock: this.addForm.stock,

          commodityTypeId: this.addForm.typeName,
          attachmentUrl: this.attachmentUrl,
        };
        this.addCommodityOrg(this, param).then((res) => {
          console.log(res);
          this.get();
          this.closeAdd();
        });
      }
    },

    httpRequest(param) {
      // console.log(param);
      const formData = new FormData(); // FormData对象
      formData.append("file", this.upFile); // file封装到FormData里
      //请求后台上传数据的接口
      this.$http
        .post(
          "http://localhost:8080/onlinemall/pc/commodity/addCommodityPicture",
          formData,
          {
            headers: { "Content-Type": "multipart/form-data" },
          }
        )
        .then((res) => {
          this.attachmentUrl = res.data;
        });
    },

    handleRemove(file) {
      this.$refs.pictureUpload.handleRemove(file);
    },
    handlePictureCardPreview(file) {
      this.dialogImageUrl = file.url;
      this.dialogVisible = true;
    },
    handleChange(file, fileList) {
      console.log(fileList);
      this.upFile = file.raw;
    },
  },
  created() {
    this.getType();
  },
};
</script>
<style lang="scss" scoped>
.formContent {
  overflow-y: scroll;
  overflow-x: hidden;
  margin-bottom: 15%;
}
.formAdd {
  position: relative;
  display: flex;
  align-items: center;
  margin-top: 7px;
  width: 100%;
  height: 49px;
  background: #e9f4fd;
  .formAddPic {
    margin-left: 27px;
    width: 30px;
    height: 30px;
  }

  .formAddWord {
    margin-left: 11px;
    height: 18px;
    font-size: 18px;
    font-family: DengXian;
    font-weight: 400;
    color: #2a92ed;
  }
  .formClose {
    position: absolute;
    cursor: pointer;
    top: -60px;
    right: -60px;
    width: 120px;
    height: 120px;
    background: #cae4fa;
    border-radius: 50%;
  }
  .formClosePic {
    position: absolute;
    top: 76px;
    left: 28px;
    width: 22px;
    height: 22px;
  }
}

.formTitle {
  display: flex;
  align-items: center;
  margin-top: 30px;
  height: 16px;
  .formTitlePic {
    width: 16px;
    height: 16px;
    margin-left: 28px;
  }
  .formTitleWord {
    margin-left: 17px;
    height: 15px;
    font-size: 16px;
    font-family: DengXian;
    font-weight: 400;
    color: #323232;
  }
}

.formNameInput {
  height: 28px;
  margin-top: 5px;
  margin-left: 57px;
  width: 90%;
  .el-input__inner {
    height: 28px;
    border-radius: 2px;
  }
}
/deep/.optionSelect {
  height: 100px;
}
.formButton {
  position: fixed;
  bottom: 0px;
  display: flex;
  justify-content: center;
  width: 60%;
  box-shadow: 0px -2px 4px 0px #cae4fa;
  .el-button {
    align-items: center;
    width: 120px;
    height: 40px;
    margin: 15px;
    background: #bfbfbf;
    border-color: #bfbfbf;
    border-radius: 20px;
  }
  .el-button:last-child {
    background: #2a92ed;
    border-color: #2a92ed;
  }
}
.formButton1 {
  font-size: 16px;
  font-family: DengXian;
  font-weight: 400;
  color: #ffffff;
}

.imgWrapper {
  margin-left: 57px;
  margin-top: 10px;
}
</style>

