<template>
  <div id="sysManage">
    <div class="navBar">
      <div class="iconAndText">
        <img class="systemIcon" src="@/assets/系统管理.png" />
        <span class="systemTitle">后台管理</span>
      </div>
      <hr class="longStringLeft" />
      <div class="navigation">
        <el-row class="tac">
          <el-col>
            <el-menu
              :default-active="$route.path"
              class="el-menu-vertical-demo"
              active-text-color="#000000"
              background-color="rgba(237, 116, 42, 0.001)"
              router
            >
              <el-menu-item index="/manage/sysManage/loginUserManage">
                <img class="manageIcon" src="@/assets/shenpi.png" />
                <span
                  class="manageTitle"
                  slot="title"
                  style="padding-left: 20px"
                  >登录人员管理</span
                >
                <div class="highlight"></div>
              </el-menu-item>
              <el-menu-item index="/manage/sysManage/commodityManage">
                <img class="manageIcon" src="@/assets/shenpi.png" />
                <span
                  class="manageTitle"
                  slot="title"
                  style="padding-left: 20px"
                  >商品管理</span
                >
                <div class="highlight"></div>
              </el-menu-item>
              <el-menu-item index="/manage/sysManage/orderManage">
                <img class="manageIcon" src="@/assets/shenpi.png" />
                <span
                  class="manageTitle"
                  slot="title"
                  style="padding-left: 20px"
                  >订单管理</span
                >
                <div class="highlight"></div>
              </el-menu-item>
              <el-menu-item index="/manage/sysManage/userManage">
                <img class="manageIcon" src="@/assets/shenpi.png" />
                <span
                  class="manageTitle"
                  slot="title"
                  style="padding-left: 20px"
                  >用户管理</span
                >
                <div class="highlight"></div>
              </el-menu-item>
              <el-menu-item index="/manage/sysManage/configurationManage">
                <img class="manageIcon" src="@/assets/shenpi.png" />
                <span
                  class="manageTitle"
                  slot="title"
                  style="padding-left: 20px"
                  >配置管理</span
                >
                <div class="highlight"></div>
              </el-menu-item>
              <el-menu-item index="/manage/sysManage/customServiceManage">
                <img class="manageIcon" src="@/assets/shenpi.png" />
                <span
                  class="manageTitle"
                  slot="title"
                  style="padding-left: 20px"
                  >客服管理</span
                >
                <div class="highlight"></div>
              </el-menu-item>
              <el-menu-item index="/manage/sysManage/freightManage">
                <img class="manageIcon" src="@/assets/shenpi.png" />
                <span
                  class="manageTitle"
                  slot="title"
                  style="padding-left: 20px"
                  >运费管理</span
                >
                <div class="highlight"></div>
              </el-menu-item>
            </el-menu>
          </el-col>
        </el-row>
      </div>
    </div>
    <router-view class="container"></router-view>
  </div>
</template>
<script>
export default {
  components: {},
  props: {},
  data() {
    //这里存放数据
    return {};
  },
  methods: {},
};
</script>
<style lang="scss" scoped>
* {
  padding: 0;
  margin: 0;
}
#sysManage {
  height: 100%;
  width: 100%;
  display: flex;

  > .navBar {
    background: rgba(42, 146, 237, 0.1);
    margin-top: 2px;
    width: 18%;

    > .iconAndText {
      display: flex;

      > .systemIcon {
        width: 30px;
        height: 30px;
        padding-left: 29px;
        padding-top: 20px;
      }

      > .systemTitle {
        font-size: 20px;
        font-family: DengXian;
        font-weight: 400;
        color: #2a92ed;
        padding-top: 26px;
        padding-left: 16px;
      }
    }

    > .description {
      font-size: 14px;
      font-family: DengXian;
      font-weight: 400;
      color: #323232;
      padding-left: 20px;
      padding-top: 15px;
    }

    > .longStringLeft {
      background-color: #000000;
      opacity: 0.2;
      height: 1px;
      margin-top: 21px;
      margin-right: 17px;
      margin-left: 18px;
    }

    > .navigation {
      display: flex;
      flex-direction: column;
      padding-top: 22px;

      > .manageTitle {
        font-size: 14px;
        font-family: DengXian;
        font-weight: bold;
        color: #000000;
      }

      .highlight {
        width: 8px;
        height: 56px;
        float: right;
      }
    }
  }

  > .container {
    width: 83.33%;
    background: #ffffff;
    margin-top: 16px;
    margin-left: 20px;
    margin-right: 20px;
  }
}

.el-menu-item:hover {
  background: rgba($color: #2a92ed, $alpha: 0.3) !important;
}

.el-menu-item.is-active {
  background: rgba($color: #2a92ed, $alpha: 0.5) !important;

  > .highlight {
    background: #2a92ed;
  }
}
</style>
