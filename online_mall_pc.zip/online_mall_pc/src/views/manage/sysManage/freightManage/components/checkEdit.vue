<template>
  <div>
    <!--
    <el-button type="text" size="small" @click="getmore(getnewId)"
      >查看</el-button
    >
    -->
    <!--详情抽屉-->
    <template>
      <el-drawer
        size="60%"
        :with-header="false"
        :visible.sync="getnew"
        :direction="direction"
        destroy-on-close
      >
        <div class="formContent">
          <div class="formAdd">
            <img class="formAddPic" src="@/assets/添加.png" alt="" />
            <div class="formAddWord">运费查看</div>
            <div class="formClose" @click="getnew = false">
              <img class="formClosePic" src="@/assets/关闭.png" alt="" />
            </div>
          </div>
          <div class="formTitle">
            <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
            <div class="formTitleWord">地区名称</div>
          </div>
          <div class="more">{{ addForm.areaName }}</div>
          <div class="formTitle">
            <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
            <div class="formTitleWord">运费价格</div>
          </div>
          <div class="more">{{ addForm.freight }}</div>

          <div class="formTitle">
            <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
            <div class="formTitleWord">满减金额</div>
          </div>
          <div class="more">{{ addForm.threshold }}</div>
        </div>
      </el-drawer>
    </template>
    <el-button type="text" size="small" @click="change1(getnewId)"
      >编辑</el-button
    >
    <!--编辑抽屉-->
    <template>
      <el-drawer
        size="60%"
        :with-header="false"
        :visible.sync="changenew"
        :direction="direction"
        destroy-on-close
      >
        <div class="formContent">
          <div class="formAdd">
            <img class="formAddPic" src="@/assets/添加.png" alt="" />
            <div class="formAddWord">编辑运费</div>
            <div class="formClose" @click="changenew = false">
              <img class="formClosePic" src="@/assets/关闭.png" alt="" />
            </div>
          </div>
          <el-form :model="addForm" :rules="rules" ref="ruleAddForm">
            <div class="formTitle">
              <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
              <div class="formTitleWord">地区名称</div>
            </div>
            <div class="formNameInput">
              <el-form-item prop="areaName">
                <div>{{ addForm.areaName }}</div>
                <!--<el-input
                 :disabled="true"
                  size="mini"
                  v-model="addForm.areaName"
                  clearable
                ></el-input>-->
              </el-form-item>
            </div>
            <div class="formTitle">
              <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
              <span class="formTitleWord">运费价格</span>
            </div>
            <div class="formNameInput">
              <el-form-item prop="freight">
                <el-input
                  size="mini"
                  v-model="addForm.freight"
                  clearable
                ></el-input>
              </el-form-item>
            </div>
            <div class="formTitle">
              <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
              <div class="formTitleWord">满减金额</div>
            </div>
            <div class="formNameInput">
              <el-form-item prop="threshold">
                <el-input v-model="addForm.threshold" size="mini"> </el-input>
              </el-form-item>
            </div>
            <div class="formButton">
              <el-button type="info" @click="changenew = false">
                <span class="formButton1">取消</span>
              </el-button>
              <el-button @click="change('ruleAddForm')">
                <span class="formButton1">确认</span>
              </el-button>
            </div>
          </el-form>
        </div>
      </el-drawer>
    </template>
    <el-button
      type="text"
      size="small"
      style="margin-left: 20px"
      @click="move(getnewId)"
      >删除</el-button
    >
  </div>
</template>
<script>
import {
  getThresholdOrgById,
  editThresholdOrg,
  delThresholdServiceOrgById,
} from "@/api/template.js";
export default {
  props: ["getnewId"],
  data() {
    return {
      options: [],
      closeAndChange: true,
      getnew: false,
      changenew: false,
      direction: "rtl",
      addForm: {
        id: 1,
        areaName: "",
        freight: "",
        threshold: "",
      },
      rules: {
        areaName: [
          { required: true, message: "请输入地区名称", trigger: "blur" },
        ],
        freight: [
          { required: true, message: "请输入运费价格", trigger: "blur" },
        ],
        threshold: [
          { required: true, message: "请输入满减金额", trigger: "blur" },
        ],
      },
    };
  },
  methods: {
    getThresholdOrgById,
    editThresholdOrg,
    delThresholdServiceOrgById,
    async move(id) {
      const confirmResult = await this.$confirm(
        "此操作将永久删除该运费, 是否继续?",
        "提示",
        {
          confirmButtonText: "确定",
          cancelButtonText: "取消",
          type: "warning",
        }
      ).catch((err) => err);
      if (confirmResult !== "confirm") {
        return this.$message.error("删除运费失败");
      } else {
        this.$message.success("删除运费成功");
        let res = delThresholdServiceOrgById(this, { id: id });
        res.then(() => {
          this.$emit("firstPage");
        });
      }
    },
    //编辑运费信息
    change1(id) {
      this.getmore(id);
      this.changenew = true;
      this.getnew = false;
    },
    //确定更改运费信息
    change(form) {
      this.$refs[form].validate((valid) => {
        if (valid) {
          alert("运费信息修改成功!!!");
          let res = editThresholdOrg(this, {
            areaName: this.addForm.areaName,
            freight: this.addForm.freight,
            threshold: this.addForm.threshold,
            id: this.addForm.id,
          });
          res.then(() => {
            this.changenew = false;
            this.$emit("getThresholdList");
            this.closeAndChange = true;
          });
        } else {
          alert("请将信息填写完整，再单击确认");
          return false;
        }
      });
    },
    //根据运费id获取运费详细信息
    getmore(id) {
      this.getnew = true;
      let res = getThresholdOrgById(this, { id: id });
      res.then((res) => {
        this.addForm.id = res.id;
        this.addForm.areaName = res.areaName;
        this.addForm.freight = res.freight;
        this.addForm.threshold = res.threshold;
      });
    },
  },
};
</script>
<style lang="scss" scoped>
.more {
  margin-top: 20px;
  margin-left: 60px;
  font-size: 14px;
  font-family: DengXian;
  font-weight: 500;
}
.formAdd {
  position: relative;
  display: flex;
  align-items: center;
  margin-top: 7px;
  width: 100%;
  height: 49px;
  background: #e9f4fd;
  .formAddPic {
    margin-left: 27px;
    width: 30px;
    height: 30px;
  }

  .formAddWord {
    margin-left: 11px;
    height: 18px;
    font-size: 18px;
    font-family: DengXian;
    font-weight: 400;
    color: #2a92ed;
  }
  .formClose {
    position: absolute;
    cursor: pointer;
    top: -60px;
    right: -60px;
    width: 120px;
    height: 120px;
    background: #cae4fa;
    border-radius: 50%;
  }
  .formClosePic {
    position: absolute;
    top: 76px;
    left: 28px;
    width: 22px;
    height: 22px;
  }
}

.formTitle {
  display: flex;
  align-items: center;
  margin-top: 30px;
  height: 16px;
  .formTitlePic {
    width: 16px;
    height: 16px;
    margin-left: 28px;
  }
  .formTitleWord {
    margin-left: 17px;
    height: 15px;
    font-size: 16px;
    font-family: DengXian;
    font-weight: 400;
    color: #323232;
  }
}

.formNameInput {
  height: 28px;
  margin-top: 5px;
  margin-left: 57px;
  width: 90%;
  .el-input__inner {
    height: 28px;
    border-radius: 2px;
  }
}
.formButton {
  position: fixed;
  bottom: 0px;
  display: flex;
  justify-content: center;
  width: 60%;
  box-shadow: 0px -2px 4px 0px #cae4fa;
  .el-button {
    align-items: center;
    width: 120px;
    height: 40px;
    margin: 15px;
    background: #bfbfbf;
    border-color: #bfbfbf;
    border-radius: 20px;
  }
  .el-button:last-child {
    background: #2a92ed;
    border-color: #2a92ed;
  }
}
.formButton1 {
  font-size: 16px;
  font-family: DengXian;
  font-weight: 400;
  color: #ffffff;
}
</style>
