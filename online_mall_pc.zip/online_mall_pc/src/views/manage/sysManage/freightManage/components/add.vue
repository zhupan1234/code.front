<template>
  <div>
    <el-form :model="addForm" :rules="rules" ref="ruleAddForm">
      <div class="formContent">
        <div class="formAdd">
          <img class="formAddPic" src="@/assets/添加.png" alt="" />
          <div class="formAddWord">添加运费</div>
          <div class="formClose" @click="closeAddSon">
            <img class="formClosePic" src="@/assets/关闭.png" alt="" />
          </div>
        </div>
        <!--表单 名称 简介-->
        <div class="formTitle">
          <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
          <div class="formTitleWord">地区名称</div>
        </div>
        <div class="formNameInput">
          <el-form-item prop="areaName">
            <el-cascader
              @click="getAllArea"
              v-model="addForm.areaName"
              :options="options"
              @change="handleChange"
            ></el-cascader>
            <!--<el-input
              size="mini"
              v-model="addForm.areaName"
              placeholder="请输入地区名称"
              clearable
            ></el-input>-->
          </el-form-item>
        </div>
        <div class="formTitle">
          <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
          <span class="formTitleWord">运费价格</span>
        </div>
        <div class="formNameInput">
          <el-form-item prop="freight">
            <el-input
              v-model="addForm.freight"
              size="mini"
              placeholder="请输入运费价格"
              clearable
            >
            </el-input>
          </el-form-item>
        </div>
        <div class="formTitle">
          <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
          <span class="formTitleWord">满减金额</span>
        </div>
        <div class="formNameInput">
          <el-form-item prop="threshold">
            <el-input
              v-model="addForm.threshold"
              size="mini"
              placeholder="请输入满减金额"
              clearable
            >
            </el-input>
          </el-form-item>
        </div>
      </div>
      <!--表单按钮-->
      <div class="formButton">
        <el-button type="info" @click="closeAddSon">
          <span class="formButton1">取消</span>
        </el-button>
        <el-button @click="addUser('ruleAddForm')">
          <span class="formButton1">确认</span>
        </el-button>
      </div>
    </el-form>
  </div>
</template>
<script>
import { addThresholdOrg,getArea } from "@/api/template.js";
export default {
  data() {
    return {
      options: [],
      addForm: {
        areaName: "",
        freight: "",
        threshold: "",
      },
      rules: {
        areaName: [
          { required: true, message: "请输入地区名称", trigger: "blur" },
        ],
        freight: [
          { required: true, message: "请输入运费价格", trigger: "blur" },
        ],
        threshold: [
          { required: true, message: "请输入满减金额", trigger: "blur" },
        ],
      },
      drawer: false,
    };
  },
  created() {   
    this.getAllArea();
  },
  methods: {
    addThresholdOrg,getArea,
     getAllArea(){
      let res=getArea(this,{});
      res.then((res)=>{       
        this.options=res        
      })
    },
    handleChange(value) {
      console.log(value[1]);
      this.addForm.areaName=value[1]
    },
    closeAddSon() {
      this.drawer = false;
      this.$emit("closeAdd", this.drawer);
    },
    addUser(form) {
      this.$refs[form].validate((valid) => {
        if (valid) {
          alert("运费信息提交成功!!!");
          let res = addThresholdOrg(this, {
            areaName: this.addForm.areaName,
            freight: this.addForm.freight,
            threshold: this.addForm.threshold,
          });
          res.then(() => {
            this.drawer = false;
            this.$emit("getThresholdList");
            this.$emit("closeAdd", this.drawer);
          });
        } else {
          alert("请将信息填写完整,再单击确认");
          return false;
        }
      });
    },
  },
};
</script>
<style lang="scss" scoped>
.formAdd {
  position: relative;
  display: flex;
  align-items: center;
  margin-top: 7px;
  width: 100%;
  height: 49px;
  background: #e9f4fd;
  .formAddPic {
    margin-left: 27px;
    width: 30px;
    height: 30px;
  }

  .formAddWord {
    margin-left: 11px;
    height: 18px;
    font-size: 18px;
    font-family: DengXian;
    font-weight: 400;
    color: #2a92ed;
  }
  .formClose {
    position: absolute;
    cursor: pointer;
    top: -60px;
    right: -60px;
    width: 120px;
    height: 120px;
    background: #cae4fa;
    border-radius: 50%;
  }
  .formClosePic {
    position: absolute;
    top: 76px;
    left: 28px;
    width: 22px;
    height: 22px;
  }
}

.formTitle {
  display: flex;
  align-items: center;
  margin-top: 30px;
  height: 16px;
  .formTitlePic {
    width: 16px;
    height: 16px;
    margin-left: 28px;
  }
  .formTitleWord {
    margin-left: 17px;
    height: 15px;
    font-size: 16px;
    font-family: DengXian;
    font-weight: 400;
    color: #323232;
  }
}

.formNameInput {
  height: 28px;
  margin-top: 5px;
  margin-left: 57px;
  width: 90%;
  .el-input__inner {
    height: 28px;
    border-radius: 2px;
  }
}
.formButton {
  position: fixed;
  bottom: 0px;
  display: flex;
  justify-content: center;
  width: 60%;
  box-shadow: 0px -2px 4px 0px #cae4fa;
  .el-button {
    align-items: center;
    width: 120px;
    height: 40px;
    margin: 15px;
    background: #bfbfbf;
    border-color: #bfbfbf;
    border-radius: 20px;
  }
  .el-button:last-child {
    background: #2a92ed;
    border-color: #2a92ed;
  }
}
.formButton1 {
  font-size: 16px;
  font-family: DengXian;
  font-weight: 400;
  color: #ffffff;
}
</style>
