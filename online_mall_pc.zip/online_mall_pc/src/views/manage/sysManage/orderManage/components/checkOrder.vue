<template>
  <div>
    <el-button type="text" size="small" @click="getmore(getnewId)"
      >查看</el-button
    >
    <!--详情抽屉-->
    <template>
      <el-drawer
        size="60%"
        :with-header="false"
        :visible.sync="getnew"
        :direction="direction"
        destroy-on-close
      >
        <div class="formContent">
          <div class="formAdd">
            <img class="formAddPic" src="@/assets/添加.png" alt="" />
            <span class="formAddWord">订单详情</span>
            <div class="formClose" @click="getnew = false">
              <img class="formClosePic" src="@/assets/关闭.png" alt="" />
            </div>
          </div>
          <div class="formTitle">
            <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
            <span class="formTitleWord">订单编号</span>
          </div>
          <div class="more">{{ addForm.transactionNumber }}</div>

          <div class="formTitle">
            <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
            <span class="formTitleWord">订单名称</span>
          </div>
          <div class="more">{{ addForm.name }}</div>
          <div class="formTitle">
            <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
            <span class="formTitleWord">商品规格</span>
          </div>
          <div class="more">
            数量:{{ addForm.number }}&nbsp;&nbsp;&nbsp;&nbsp;价格:{{
              addForm.price
            }}&nbsp;&nbsp;&nbsp;&nbsp;规格:{{ addForm.specifications }}
          </div>
          <div class="formTitle">
            <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
            <span class="formTitleWord">用户名</span>
          </div>
          <div class="more">{{ addForm.userName }}</div>
          <div class="formTitle">
            <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
            <span class="formTitleWord">收货信息</span>
          </div>
          <div class="more">
            收货人:{{ addForm.consignee }}&nbsp;&nbsp;&nbsp;&nbsp;收货地址:{{
              addForm.address
            }}&nbsp;&nbsp;&nbsp;&nbsp;收货电话:{{ addForm.phoneNumber }}
          </div>
          <div class="formTitle">
            <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
            <span class="formTitleWord">订单状态</span>
          </div>
          <div class="more">{{ addForm.status }}</div>
        </div>
      </el-drawer>
    </template>
  </div>
</template>
<script>
import { getItemById } from "@/api/template.js";
export default {
  props: ["getnewId"],
  data() {
    return {
      //成员名字显示
      closeAndChange: true,
      numberName: "",
      input: "",
      textarea: "",
      getnew: false,
      changenew: false,
      direction: "rtl",
      addForm: {
        id: "",
        transactionNumber: "222",
        name: "555",
        number: "",
        price: "",
        specifications: "",
        userName: "",
        address: "",
        consignee: "",
        phoneNumber: "",
        status: "",
      },

      rules: {
        name: [{ required: true, message: "请输入支部名称", trigger: "blur" }],
        tel: [{ required: true, message: "请输入支部简介", trigger: "blur" }],
      },
    };
  },
  methods: {
    //编辑订单信息
    change1(id) {
      this.getmore(id);
      this.changenew = true;
      this.getnew = false;
    },
    //确定更改支部信息
    change(form) {
      // this.$refs[form].validate((valid) => {
      //   if (valid) {
      //     alert("支部信息修改成功！！！");
      //     this.addForm.secId = this.dataCard[this.myradio - 1].id;
      //     if(this.myarr.length!==0){
      //       this.membs = this.myarr;
      //     };
      //     let res = editPartyOrg(this, {
      //       name: this.addForm.name,
      //       introduction: this.addForm.introduction,
      //       secId: this.addForm.secId,
      //       membs: this.membs,
      //       id: this.addForm.id,
      //     });
      //     res.then(() => {
      //       //console.log(res);
      //       this.changenew = false;
      //       this.$emit("getUserList");
      //       this.closeAndChange = true;
      //     });
      //   } else {
      //     alert("请将信息填写完整，再单击确认");
      //     return false;
      //   }
      // });
    },
    //根据订单id获取订单详细信息
    getmore(id) {
      this.getnew = true;
      let res = getItemById(this, { id: id });
      res.then((res) => {
        this.addForm.id = res.id;
        this.addForm.transactionNumber = res.transactionNumber;
        this.addForm.name = res.name;
        this.addForm.number = res.number;
        this.addForm.price = res.price;
        this.addForm.specifications = res.specifications;
        this.addForm.userName = res.userName;
        this.addForm.consignee = res.consignee;
        this.addForm.address = res.address;
        this.addForm.phoneNumber = res.phoneNumber;
        this.addForm.status = res.status;
        if (this.addForm.status == 0) {
          this.addForm.status = "已取消";
        } else if (this.addForm.status == 1) {
          this.addForm.status = "待付款";
        } else if (this.addForm.status == 2) {
          this.addForm.status = "待发货";
        } else if (this.addForm.status == 3) {
          this.addForm.status = "已发货";
        } else {
          this.addForm.status = "已完成";
        }
      });
    },
  },
};
</script>
<style lang="scss" scoped>
.formContent {
  overflow: hidden;
}
.more {
  margin-top: 20px;
  margin-left: 60px;
  font-size: 14px;
  font-family: DengXian;
  font-weight: 500;
}
.formAdd {
  position: relative;
  margin-top: 7px;
  width: 100%;
  height: 49px;
  background: #e9f4fd;
}

.formClose {
  position: absolute;
  cursor: pointer;
  top: -60px;
  right: -60px;
  width: 120px;
  height: 120px;
  background: #cae4fa;
  border-radius: 50%;
}

.formClosePic {
  position: absolute;
  top: 76px;
  left: 28px;
  width: 22px;
  height: 22px;
}

.formAddPic {
  position: absolute;
  top: 10px;
  left: 27px;
  width: 30px;
  height: 30px;
}

.formAddWord {
  position: absolute;
  top: 16px;
  left: 62px;
  height: 18px;
  font-size: 18px;
  font-family: DengXian;
  font-weight: 400;
  color: #2a92ed;
}

.formTitle {
  margin-top: 30px;
  height: 16px;
}

.formTitlePic {
  float: left;
  width: 16px;
  height: 16px;
  margin-left: 28px;
}

.formTitleWord {
  float: left;
  margin-left: 17px;
  height: 15px;
  font-size: 16px;
  font-family: DengXian;
  font-weight: 400;
  color: #323232;
}

.formNameInput {
  height: 28px;
  margin-top: 5px;
  margin-left: 57px;
  width: 90%;
}

.formNameInput .el-input__inner {
  height: 28px;
  border-radius: 2px;
}

.formIntroInput {
  height: 68px;
  width: 90%;
  margin-top: 5px;
  margin-left: 57px;
}

.formIntroInput .el-textarea__inner {
  height: 68px;
  border-radius: 2px;
  resize: none;
}
.formButton {
  position: fixed;
  bottom: 0px;
  display: flex;
  justify-content: center;
  width: 60%;
  box-shadow: 0px -2px 4px 0px rgba(210, 84, 0, 0.25);
  .el-button {
    align-items: center;
    width: 120px;
    height: 40px;
    margin: 15px;
    background: #bfbfbf;
    border-color: #bfbfbf;
    border-radius: 20px;
  }
  .el-button:last-child {
    background: #2a92ed;
    border-color: #2a92ed;
  }
}
.formButton1 {
  font-size: 16px;
  font-family: DengXian;
  font-weight: 400;
  color: #ffffff;
}
</style>
