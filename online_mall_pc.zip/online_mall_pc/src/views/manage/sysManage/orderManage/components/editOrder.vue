<template>
  <div>
    <el-button
      type="text"
      size="small"
      class="editBotton"
      @click="change1(getnewId)"
      >编辑</el-button
    >
    <!--编辑抽屉-->
    <template>
      <el-drawer
        size="60%"
        :with-header="false"
        :visible.sync="changenew"
        :direction="direction"
        destroy-on-close
      >
        <div class="formContent">
          <div class="formAdd">
            <img class="formAddPic" src="@/assets/添加.png" alt="" />
            <span class="formAddWord">编辑订单信息</span>
            <div class="formClose" @click="changenew = false">
              <img class="formClosePic" src="@/assets/关闭.png" alt="" />
            </div>
          </div>
          <el-form :model="editForm" :rules="rules" ref="ruleAddForm">
            <div class="formTitle">
              <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
              <span class="formTitleWord">订单编号</span>
            </div>
            <div class="formNameInput">
              <el-form-item prop="transactionNumber">
                <el-input
                  size="mini"
                  v-model="editForm.transactionNumber"
                  :disabled="true"
                  clearable
                ></el-input>
              </el-form-item>
            </div>
            <div class="formTitle">
              <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
              <span class="formTitleWord">订单名称</span>
            </div>
            <div class="formNameInput">
              <el-form-item prop="name">
                <el-input
                  size="mini"
                  v-model="editForm.name"
                  :disabled="true"
                  clearable
                ></el-input>
              </el-form-item>
            </div>

            <div class="formTitle">
              <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
              <span class="formTitleWord">订单规格</span>
            </div>
            <div class="formTitle">
              <span class="formTitleNumber">数量</span>
              <el-form-item prop="number">
                <el-input
                  size="mini"
                  v-model="editForm.number"
                  class="inputNumber"
                  :disabled="true"
                  clearable
                ></el-input>
              </el-form-item>
            </div>
            <div class="formTitlePrice">
              <span class="formTitleNumber">价格</span>
              <el-form-item prop="price">
                <el-input
                  size="mini"
                  v-model="editForm.price"
                  class="inputNumber"
                  :disabled="true"
                  clearable
                ></el-input>
              </el-form-item>
            </div>
            <div class="formTitleSpecifications">
              <span class="formTitleNumber">规格</span>
              <el-form-item prop="specifications">
                <el-input
                  size="mini"
                  v-model="editForm.specifications"
                  class="inputSpecifications"
                  :disabled="true"
                  clearable
                ></el-input>
              </el-form-item>
            </div>
            <div class="formTitle">
              <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
              <span class="formTitleWord">用户名</span>
            </div>
            <div class="formNameInput">
              <el-form-item prop="userName">
                <el-input
                  size="mini"
                  v-model="editForm.userName"
                  :disabled="true"
                  clearable
                ></el-input>
              </el-form-item>
            </div>
            <div class="formTitle">
              <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
              <span class="formTitleWord">收货信息</span>
            </div>
            <div class="formTitle">
              <span class="formTitleNumber">收货人</span>
              <el-form-item prop="consignee">
                <el-input
                  size="mini"
                  v-model="editForm.consignee"
                  class="inputConsignee"
                  clearable
                ></el-input>
              </el-form-item>
            </div>
            <div class="formTitlePrice">
              <span class="formTitleNumber">收货地址</span>
              <el-form-item prop="address">
                <el-input
                  size="mini"
                  v-model="editForm.address"
                  class="inputAddress"
                  clearable
                ></el-input>
              </el-form-item>
            </div>
            <div class="formTitlePhone">
              <span class="formTitleNumber">收货电话</span>
              <el-form-item prop="phoneNumber">
                <el-input
                  size="mini"
                  v-model="editForm.phoneNumber"
                  class="inputAddress"
                  clearable
                ></el-input>
              </el-form-item>
            </div>
            <div class="formTitle">
              <img class="formTitlePic" src="@/assets/小房子.png" alt="" />
              <span class="formTitleWord">订单状态</span>
            </div>
            <div class="formNameInput">
              <el-form-item prop="atatus">
                <el-input
                  size="mini"
                  v-model="editForm.status"
                  :disabled="true"
                  clearable
                ></el-input>
              </el-form-item>
            </div>
            <div class="formButton">
              <el-button type="info" @click="changenew = false">
                <span class="formButton1">取消</span>
              </el-button>
              <el-button @click="updateOrder()">
                <span class="formButton1">确认</span>
              </el-button>
            </div>
          </el-form>
        </div>
      </el-drawer>
    </template>
  </div>
</template>

<script>
import {
  getItemById,
  editOrder,
  editOrderCommodity,
} from "@/api/template.js";
export default {
  props: ["getnewId"],
  data() {
    return {
      //成员名字显示
      orderId: "",
      commodityId: "",
      id: "",
      closeAndChange: true,
      numberName: "",
      input: "",
      textarea: "",
      getnew: false,
      changenew: false,
      direction: "rtl",
      editForm: {
        id: "",
        transactionNumber: "222",
        name: "555",
        number: "",
        price: "",
        specifications: "",
        userName: "",
        address: "",
        consignee: "",
        phoneNumber: "",
        status: "",
      },

      rules: {
        transactionNumber: [
          { required: true, message: "请输入支部名称", trigger: "blur" },
        ],
        name: [{ required: true, message: "请输入支部简介", trigger: "blur" }],
      },
    };
  },
  methods: {
    //编辑订单信息
    change1(id) {
      this.getmore(id);
      this.changenew = true;
      this.getnew = false;
    },
    //确认编辑订单信息
    updateOrder() {
      let res = editOrder(this, {
        id: this.getnewId,
        transactionNumber: this.editForm.transactionNumber,
        consignee: this.editForm.consignee,
        address: this.editForm.address,
        phoneNumber: this.editForm.phoneNumber,
      });
      res.then((res) => {
        this.changenew = false;
        this.$emit("getUserList");
      });
      this.updataCommodity();
    },
    updataCommodity() {
      let res = editOrderCommodity(this, {
        id: this.getnewId,
        orderId: this.getnewId,
        commodityId: this.commodityId,
        name: this.editForm.name,
        number: this.editForm.number,
        price: this.editForm.price,
        specifications: this.editForm.specifications,
      });
      res.then((res) => {
        this.changenew = false;
        this.$emit("getUserList");
      });
    },

    //根据订单id获取订单详细信息
    getmore(id) {
      this.getnew = true;
      let res = getItemById(this, { id: id });
      res.then((res) => {
        this.editForm.id = res.id;
        this.editForm.transactionNumber = res.transactionNumber;
        this.editForm.name = res.name;
        this.editForm.number = res.number;
        this.editForm.price = res.price;
        this.editForm.specifications = res.specifications;
        this.editForm.userName = res.userName;
        this.editForm.consignee = res.consignee;
        this.editForm.address = res.address;
        this.editForm.phoneNumber = res.phoneNumber;
        this.editForm.status = res.status;
        if (this.editForm.status == 0) {
          this.editForm.status = "已取消";
        } else if (this.editForm.status == 1) {
          this.editForm.status = "待付款";
        } else if (this.editForm.status == 2) {
          this.editForm.status = "待发货";
        } else if (this.editForm.status == 3) {
          this.editForm.status = "已发货";
        } else {
          this.editForm.status = "已完成";
        }
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.editBotton {
  position: absolute;
  left: 50px;
  top: 12px;
}
.inputNumber {
  position: absolute;
  left: 80px;
  top: -30px;
  width: 80px;
}
.inputConsignee {
  position: absolute;
  left: 90px;
  top: -30px;
  width: 90px;
}
.inputSpecifications {
  position: absolute;
  left: 80px;
  top: -30px;
  width: 280px;
}
.inputAddress {
  position: absolute;
  left: 120px;
  top: -30px;
  width: 280px;
}
.inputSpecifications {
  position: absolute;
  left: 80px;
  top: -30px;
  width: 280px;
}

.formAdd {
  position: relative;
  margin-top: 7px;
  width: 100%;
  height: 49px;
  background: #e9f4fd;
}

.formClose {
  position: absolute;
  cursor: pointer;
  top: -60px;
  right: -60px;
  width: 120px;
  height: 120px;
  background: #cae4fa;
  border-radius: 50%;
}

.formClosePic {
  position: absolute;
  top: 76px;
  left: 28px;
  width: 22px;
  height: 22px;
}

.formAddPic {
  position: absolute;
  top: 10px;
  left: 27px;
  width: 30px;
  height: 30px;
}

.formAddWord {
  position: absolute;
  top: 16px;
  left: 62px;
  height: 18px;
  font-size: 18px;
  font-family: DengXian;
  font-weight: 400;
  color: #2a92ed;
}

.formTitle {
  margin-top: 30px;
  height: 16px;
}
.formTitlePrice {
  margin-left: 160px;
  margin-top: -15px;
  height: 16px;
}
.formTitleSpecifications {
  margin-left: 330px;
  margin-top: -15px;
  height: 16px;
}
.formTitlePhone {
  margin-left: 550px;
  margin-top: -15px;
  height: 16px;
}

.formTitlePic {
  float: left;
  width: 16px;
  height: 16px;
  margin-left: 28px;
}

.formTitleWord {
  float: left;
  margin-left: 17px;
  height: 15px;
  font-size: 16px;
  font-family: DengXian;
  font-weight: 400;
  color: #323232;
}
.formTitleNumber {
  margin-left: 40px;
  width: 20px;
}

.formNameInput {
  height: 28px;
  margin-top: 5px;
  margin-left: 57px;
  width: 90%;
}

.formNameInput .el-input__inner {
  height: 28px;
  border-radius: 2px;
}

.formIntroInput {
  height: 68px;
  width: 90%;
  margin-top: 5px;
  margin-left: 57px;
}

.formIntroInput .el-textarea__inner {
  height: 68px;
  border-radius: 2px;
  resize: none;
}
.formButton {
  position: fixed;
  bottom: 0px;
  display: flex;
  justify-content: center;
  width: 60%;
  box-shadow: 0px -2px 4px 0px rgba(210, 84, 0, 0.25);
  .el-button {
    align-items: center;
    width: 120px;
    height: 40px;
    margin: 15px;
    background: #bfbfbf;
    border-color: #bfbfbf;
    border-radius: 20px;
  }
  .el-button:last-child {
    background: #2a92ed;
    border-color: #2a92ed;
  }
}
.formButton1 {
  font-size: 16px;
  font-family: DengXian;
  font-weight: 400;
  color: #ffffff;
}
</style>
