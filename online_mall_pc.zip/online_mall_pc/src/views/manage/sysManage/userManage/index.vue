<template>
  <div id="branchManage">
    <div class="tabs">
      <div class="top_input">
        <el-input
          v-model="userName"
          clearable
          @clear="getUserList"
          size="mini"
          placeholder="请输入用户信息"
        ></el-input>
        <div class="top_src" @click="searchUser">
          <img class="top_src_pic" src="@/assets/搜索.png" alt="" />
        </div>
      </div>
      <div class="table">
        <el-table
          :data="tableData"
          :header-cell-style="{ background: '#daecfb', color: '#697077' }"
          @selection-change="selectionChange"
        >
          <el-table-column type="selection"> </el-table-column>
          <el-table-column prop="userName" label="用户名称"> </el-table-column>
          <el-table-column label="相关操作">
            <template slot-scope="scope">
              <el-button
                type="text"
                class="clickBtn"
                @click="handleClick(scope.$index, scope.row)"
              >
                查看
              </el-button>
            </template>
          </el-table-column>
        </el-table>
        <!--分页-->
        <div class="page">
          <span class="page_datanum"
            >共{{ totalPages }}页，{{ totalNum }}条数据</span
          >
          <div class="page_box">
            <div class="page_box1" @click="firstPage()">
              <img src="@/assets/greyNext1.png" alt="" />
            </div>
            <div class="page_box2" @click="previousPage()">
              <img src="@/assets/greyNext.png" alt="" />
            </div>
            <div class="page_box3">
              <div class="page_box3_word">{{ page }}/{{ totalPages }}</div>
            </div>
            <div class="page_box4" @click="nextPage()">
              <img src="@/assets/blueNext.png" alt="" />
            </div>
            <div class="page_box5" @click="lastPage()">
              <img src="@/assets/blueNext1.png" alt="" />
            </div>
          </div>
        </div>
      </div>
    </div>
    <check-drawer ref="checkDrawer"></check-drawer>
  </div>
</template>
<script>
import checkDrawer from "./components/checkDrawer.vue";
import { getUserPageVO, getUserOrder } from "@/api/template.js";
export default {
  components: {
    checkDrawer,
  },
  props: {},
  data() {
    //这里存放数据
    return {
      totalNum: 1,
      pageSize: 5,
      totalPages: 1,
      page: 1,
      userName: "",
      myname: "",
      activeName: "first", //默认绑定用户管理
      tableData: [
        {
          id: 1,
          userName: "jdlfjal",
        },
      ], //表单数据
      multipleSelection: [], //放选中数据
    };
  },
  created() {
    this.getUserList();
  },
  methods: {
    getUserOrder,
    getUserPageVO,
    //回首页
    firstPage() {
      this.page = 1;
      this.getUserList();
    },
    //上一页
    previousPage() {
      const a = this.page;
      if (a <= 1) {
        this.page = 1;
      } else {
        this.page -= 1;
      }
      this.getUserList();
    },
    //下一页
    nextPage() {
      if (this.page >= this.totalPages) {
        this.page = this.totalPages;
      } else {
        this.page = this.page + 1;
      }
      this.getUserList();
    },
    //跳到末页
    lastPage() {
      if (this.page != this.totalPages) {
        this.page = this.totalPages;
      }
      this.getUserList();
    },
    handleClick(index, row) {
      this.$refs.checkDrawer.drawer = true;
      this.$refs.checkDrawer.disabled = false;
      this.$refs.checkDrawer.userId = row.id;
      this.$refs.checkDrawer.userName = row.userName;
    },
    getUserList() {
      let param = {
        page: this.page,
        pageSize: this.pageSize,
      };
      getUserPageVO(this, param).then((res) => {
        this.tableData = res.userList;
        this.totalNum = res.totalNum;
        this.totalPages = res.totalPages;
      });
    },
    // 搜索用户
    searchUser() {
      let param = {
        page: this.page,
        pageSize: this.pageSize,
        userName: this.userName == "" ? null : this.userName,
      };
      getUserPageVO(this, param).then((res) => {
        this.tableData = res.userList;
        this.totalNum = res.totalNum;
        this.totalPages = res.totalPages;
      });
    },
    //把选中行的数据传递给数组multipleSelection
    selectionChange(val) {
      //console.log(val);
      this.multipleSelection = val;
    },
    handleClick2() {},
  },
};
</script>
<style lang="scss" scoped>
.top_input {
  margin-bottom: 20px;
  display: flex;
  float: right;
  .el-input--mini {
    width: 300px;
  }
  /deep/.el-input__inner {
    width: 300px;
    height: 30px;
    background: #ffffff;
    border: 1px solid #b5b5b5;
    border-radius: 6px;
  }
  .top_src_pic {
    width: 26px;
    height: 27px;
    margin-left: 15px;
    margin-right: 30px;
  }
}
/**表格样式 */
.table {
  margin-top: 20px;
}
/**页码样式 */
.page {
  display: flex;
  justify-content: space-between;
  height: 47px;
  margin-top: 14px;
  .page_datanum {
    margin-top: 16px;
    margin-left: 16px;
    height: 15px;
    font-size: 14px;
    font-family: DengXian;
    font-weight: 400;
    color: #8d8d8d;
  }
  .page_box {
    margin-right: 40px;
    height: 47px;
    display: flex;
    .page_box1,
    .page_box2,
    .page_box3,
    .page_box4,
    .page_box5 {
      cursor: pointer;
      width: 40px;
      height: 40px;
      margin: 3px;
      border: #ece3e1 solid 1px;
    }
    .page_box3 {
      cursor: text;
      width: 50px;
      .page_box3_word {
        margin-top: 10px;
        margin-left: 15px;
        font-size: 14px;
        font-family: DengXian;
        font-weight: 400;
        color: #000000;
        opacity: 0.8;
      }
    }
  }
}
.page_box1 img {
  margin-top: 10px;
  margin-left: 10px;
  width: 20px;
  height: 20px;
}
.page_box2 img {
  margin-top: 10px;
  margin-left: 5px;
  width: 20px;
  height: 20px;
}
.page_box5 img {
  margin-top: 10px;
  margin-left: 7px;
  width: 20px;
  height: 20px;
}
.page_box4 img {
  margin-top: 10px;
  margin-left: 12px;
  width: 20px;
  height: 20px;
}
.clickBtn {
  font-size: 14px;
  font-family: DengXian;
  font-weight: 400;
  color: #2a92ed;
  border: none;
}
</style>