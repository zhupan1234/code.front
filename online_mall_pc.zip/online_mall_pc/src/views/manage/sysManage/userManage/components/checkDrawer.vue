<template>
  <el-drawer
    style="margin-top: 80px; margin-bottom: 20px"
    size="60%"
    :visible.sync="drawer"
    :direction="direction"
    @open="open"
    :with-header="false"
  >
    <div class="top">
      <img src="@/assets/订单信息.png" class="pgtianjia" />
      <div class="add-party">订单信息</div>
      <div class="close-border" @click="closeDrawer()">
        <img src="@/assets/选项卡关闭按钮.png" class="close-top-header" />
      </div>
    </div>
    <div class="drawercenter">
      <div class="inpuittitle">
        <img src="@/assets/257用户资料 (1).png" class="leftimg2" />
        用户名称:{{ userName }}
      </div>

      <div class="inpuittitle">
        <img src="@/assets/订单.png" class="leftimg2" /> 订单管理
      </div>

      <div class="table">
        <el-table
          :data="tableData"
          :header-cell-style="{ background: '#daecfb', color: '#697077' }"
        >
          <el-table-column prop="id" label="订单ID"> </el-table-column>
          <el-table-column prop="consignee" label="收货人"> </el-table-column>
          <el-table-column prop="address" label="收货地址"> </el-table-column>
          <el-table-column prop="phoneNumber" label="联系电话">
          </el-table-column>
          <el-table-column prop="transactionNumber" label="交易单号">
          </el-table-column>
          <el-table-column prop="purchaseTime" label="交易时间">
          </el-table-column>
          <el-table-column prop="freight" label="订单运费"> </el-table-column>
          <el-table-column prop="totalPrice" label="订单总金额">
          </el-table-column>
          <el-table-column prop="status" label="收货状态"> </el-table-column>
        </el-table>
      </div>
    </div>
    <div class="btnManage">
      <el-button class="cancelBtn" @click="closeDrawer2()">取消</el-button>
      <el-button class="confirmBtn" @click="save()">确认</el-button>
    </div>
  </el-drawer>
</template>
<script>
import { getUserOrder } from "@/api/template.js";

export default {
  components: {},
  data() {
    //这里存放数据
    return {
      totalNum: 5,
      totalPages: 1,
      //分页
      pagenum: 1,
      pageSize: 5,
      userName: "",
      direction: "rtl",
      input: "",
      textarea: "",
      drawer: false,
      id: null,
      disabled: false,
      tableData: [],
      userId: "",
      userName: "",
    };
  },
  //计算属性 类似于data概念
  computed: {},
  //监控data中的数据变化
  watch: {},
  //方法集合
  methods: {
    getUserOrder,

    //右上角关闭按钮关闭卡片
    closeCard() {
      this.isShow = false;
    },
    open() {
      let params = {
        userId: this.userId,
      };
      getUserOrder(this, params).then((res) => {
        this.tableData = res;
        for (let i = 0; i < this.tableData.length; i++) {
          if (this.tableData[i].status == 0) {
            this.tableData[i].status = "已取消";
          } else if (this.tableData[i].status == 1) {
            this.tableData[i].status = "待付款";
          } else if (this.tableData[i].status == 2) {
            this.tableData[i].status = "待发货";
          } else if (this.tableData[i].status == 3) {
            this.tableData[i].status = "已发货";
          } else {
            this.tableData[i].status = "已完成";
          }
        }
        this.totalNum = res.totalNum;
        this.totalPages = res.totalPages;
      });
    },
    //关闭抽屉
    async closeDrawer() {
      const confirmResult = await this.$confirm("确定关闭？", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
      }).catch((err) => err);
      if (confirmResult !== "confirm") {
        this.drawer = true;
      } else {
        this.drawer = false;
      }
    },
    handleRemove(file, fileList) {
      console.log(file, fileList);
    },

    handlePictureCardPreview(file) {
      this.dialogImageUrl = file.url;
      this.dialogVisible = true;
    },
    //抽屉里确认按钮
    save() {
      this.drawer = false;
    },
    closeDrawer2() {
      this.drawer = false;
    },
  },

  //生命周期 - 创建完成（可以访问当前this实例）
  created() {},
};
</script>

<style lang="scss" scoped>
.el-drawer__header {
  background-color: #f9f3f1 !important;
  justify-content: space-around !important;
  font-size: 1.2rem;
  color: #c77f75;
  text-align: left;
  padding: 1rem !important;
  margin-bottom: 0rem !important;
}
.el-upload--picture-card {
  width: 18.86667rem !important;
}
.drawercenter {
  margin-left: 10px;
}
.uploadbox {
  margin-right: 765px;
}
.transferhr {
  border: none;
  height: 2px;
  background-color: #cfe4f8;
  opacity: 0.2;
  margin-top: 20px;
}
.leftimg2 {
  height: 30px;
  width: 10px;
  margin-right: 14px;
}
.inpuittitle {
  margin: 1rem 0 0.5rem 0;
  text-align: left;
  display: flex;
  align-items: center;
  img {
    width: 2%;
  }
}

.cfmbtn {
  background: #ed742a;
  border-radius: 20px;
  width: 120px;
  height: 40px;
  color: #ffffff;
  border: none;
}
.qtbtn {
  color: #ffffff;
  background: #cccccc;
  border-radius: 20px;
  width: 120px;
  height: 40px;
  border: none;
}

.iconplus {
  margin-right: 900px;
}

.el-input {
  margin-left: 35px;
  width: 97%;
}
.el-input__inner {
  margin: 11px 17px;
  width: 180px;
  height: 20px;
  border: 1px solid #e5e5e5;
}
.clearfix:before,
.clearfix:after {
  display: table;
  content: "";
}
.clearfix:after {
  clear: both;
}

.top {
  background: #f2f8fe;
  display: flex;
  padding-top: 12px;
  width: 100%;
  text-align: center;
  word-break: keep-all;
  height: 50px;
  margin-top: 10px;
  font-size: 20px;
}
.pgtianjia {
  width: 25px;
  height: 25px;
  margin-right: 10px;
  vertical-align: middle;
  margin-left: 10px;
}
.close-border {
  position: absolute;
  cursor: pointer;
  top: -50px;
  right: -50px;
  width: 110px;
  height: 110px;
  background: #d5e8fa;
  border-radius: 50%;
}
.close-top-header {
  position: absolute;
  top: 60px;
  left: 20px;
  width: 30px;
  height: 30px;
}
.blank_div {
  height: 300px;
}
.btnManage {
  position: absolute;
  bottom: 0;
  width: 100%;
  height: 80px;
  background: #ffffff;
  box-shadow: 0px -2px 4px 0px rgba(161, 158, 155, 0.25);
}
.cancelBtn {
  width: 120px;
  height: 40px;
  background: rgba($color: #000000, $alpha: 0.25);
  border-radius: 20px;
  margin-left: 36%;
  margin-top: 18px;
  cursor: pointer;
  font-size: 16px;
  font-family: DengXian;
  font-weight: 400;
  color: #ffffff;
}
.confirmBtn {
  width: 120px;
  height: 40px;
  background: #2a92ed;
  border-radius: 20px;
  margin-left: 28px;
  cursor: pointer;
  font-size: 16px;
  font-family: DengXian;
  font-weight: 400;
  color: #ffffff;
}
/**页码样式 */
.page {
  display: flex;
  justify-content: space-between;
  height: 47px;
  margin-top: 14px;
  .page_datanum {
    margin-top: 16px;
    margin-left: 16px;
    height: 15px;
    font-size: 14px;
    font-family: DengXian;
    font-weight: 400;
    color: #8d8d8d;
  }
  .page_box {
    margin-right: 40px;
    height: 47px;
    display: flex;
    .page_box1,
    .page_box2,
    .page_box3,
    .page_box4,
    .page_box5 {
      cursor: pointer;
      width: 40px;
      height: 40px;
      margin: 3px;
      border: #ece3e1 solid 1px;
    }
    .page_box3 {
      cursor: text;
      width: 50px;
      .page_box3_word {
        margin-top: 10px;
        margin-left: 15px;
        font-size: 14px;
        font-family: DengXian;
        font-weight: 400;
        color: #000000;
        opacity: 0.8;
      }
    }
  }
}
.page_box1 img {
  margin-top: 10px;
  margin-left: 10px;
  width: 20px;
  height: 20px;
}
.page_box2 img {
  margin-top: 10px;
  margin-left: 5px;
  width: 20px;
  height: 20px;
}
.page_box5 img {
  margin-top: 10px;
  margin-left: 7px;
  width: 20px;
  height: 20px;
}
.page_box4 img {
  margin-top: 10px;
  margin-left: 12px;
  width: 20px;
  height: 20px;
}
</style>