<template>
  <div>
    <div class="home">
      <!--头部导航栏-->
      <div class="title">
        <div class="titleLeftBox">
          <img class="titleLeft" src="@/assets/小标识icon.png" />
          <span class="titleLoge">后台管理系统</span>
          <div class="titleRow"></div>
          <!-- <img class="titleLeft1" src="@/assets/left.png" /> -->
        </div>
        <!-- <div class="titleCenterBox">
          <div
            class="titleUser"
            :class="selectNum === item.id ? 'colorchange' : ''"
            @click="Change(item.id)"
            v-for="item in colorChange"
            :key="item.id"
          >
            <img class="titleUserPic" :src="item.pic" />
            <span class="titleUserWord">{{ item.name }}</span>
          </div>
        </div> -->
        <div class="titleRightBox">
          <!-- <img class="titleRight" src="@/assets/right.png" />
          <div class="title_return_word">返回首页</div>
          <img class="title_return_pic" src="@/assets/返回icon.png" alt="" /> -->
          <div class="titleRow2"></div>
          <div class="title_name_word">{{this.$store.state.userName}}，欢迎你</div>
          <img class="title_name_pic" src="@/assets/u18.png" alt="" />
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  components: {},
  props: {},
  data() {
    //这里存放数据
    return {
      url: "index",
      selectNum: 1,
      colorChange: [
        {
          id: 1,
          name: "系统",
          pic: require("@/assets/系统icon.png"),
        },
        {
          id: 2,
          name: "用户",
          pic: require("@/assets/用户icon.png"),
        },
        {
          id: 3,
          name: "计划",
          pic: require("@/assets/计划icon.png"),
        },
        {
          id: 4,
          name: "审批",
          pic: require("@/assets/审批icon.png"),
        },
        {
          id: 5,
          name: "工作",
          pic: require("@/assets/工作icon.png"),
        },
        {
          id: 6,
          name: "材料",
          pic: require("@/assets/材料icon.png"),
        },
        {
          id: 7,
          name: "积分",
          pic: require("@/assets/积分icon.png"),
        },
        {
          id: 8,
          name: "统计",
          pic: require("@/assets/统计icon.png"),
        },
      ],
    };
  },
  mounted() {
    this.checkRouter(this.$router.currentRoute.fullPath);
  },
  watch: {
    $route: {
      handler: function (val) {
        let path = val.path;
        if (path.indexOf("customerServiceManage") !== -1) {
          this.selectNum = 1;
        }
        if (path.indexOf("freightManage") !== -1) {
          this.selectNum = 2;
        }
      },
      // 深度观察监听
      deep: true,
    },
  },
  methods: {
    checkRouter(path) {
      if (path.indexOf("userManage") !== -1) {
        this.selectNum = 1;
      }
      if (path.indexOf("deptManage") !== -1) {
        this.selectNum = 2;
      }
      if (path.indexOf("authorityManage") !== -1) {
        this.selectNum = 3;
      }
      if (path.indexOf("postManage") !== -1) {
        this.selectNum = 4;
      }
      if (path.indexOf("companyManage") !== -1) {
        this.selectNum = 5;
      }
      if (path.indexOf("configManage") !== -1) {
        this.selectNum = 6;
      }
    },
    beforeRouteEnter(to, from, next) {
      next((vm) => {
        // //console.dir(to)
        let path = to.path;
        if (path.indexOf("customerServiceManage") !== -1) {
          vm.selectNum = 1;
        }
        if (path.indexOf("freightManage") !== -1) {
          vm.selectNum = 2;
        }
        console.log(vm); //当前组件的实例
      });
    },
    Change(id) {
      let path = "";
      if (this.colorChange[id - 1].id === 1) {
        //人员管理
        this.selectNum = 1;
        path = "/sysManage/noticeManage";
      }
      if (this.colorChange[id - 1].id === 2) {
        //部门管理
        this.selectNum = 2;
        path = "/sysManage/noticeManage";
      }
      if (this.colorChange[id - 1].id === "authorityManage") {
        //权限管理
        this.selectNum = 3;
        path = "/sysManage/authorityManage";
      }
      if (this.colorChange[id - 1].id === "postManage") {
        //职务管理
        this.selectNum = 4;
        path = "/sysManage/postManage";
      }
      if (this.colorChange[id - 1].id === "companyManage") {
        //公司管理
        this.selectNum = 5;
        path = "/sysManage/companyManage";
      }
      if (this.colorChange[id - 1].id === "configManage") {
        //配置管理
        this.selectNum = 6;
        path = "/sysManage/configManage";
      }
      this.$router.push({
        path: path,
      });
    },
  },
};
</script>
<style lang="scss" scoped>
/*头部导航栏*/
.title {
  width: 100%;
  display: flex;
  justify-content: space-between;
  height: 80px;
  background: #2a92ed;
  box-shadow: 0px 3px 5px 0px rgba(0, 0, 0, 0.15);
}
.titleLeftBox {
  height: 80px;
  display: flex;
  .titleLeft {
    margin-left: 19px;
    margin-top: 14px;
    width: 50px;
    height: 48px;
  }
  .titleLoge {
    margin-left: 20px;
    margin-top: 15px;
    width: 180px;
    font-size: 30px;
    font-family: Microsoft YaHei;
    font-weight: bold;
    color: #ffffff;
    text-shadow: 0px 3px 5px rgba(0, 0, 0, 0.15);
  }

  .titleRow {
    margin-top: 13px;
    margin-left: 18px;
    width: 1px;
    height: 54px;
    background: #ffffff;
  }
  .titleLeft1 {
    margin-left: 12px;
    margin-top: 9px;
    width: 16px;
    height: 61px;
    background: #ffffff;
    opacity: 0.3;
  }
}
.titleCenterBox {
  width: 1280px;
  display: flex;
}
.titleUser {
  flex: 1;
  display: flex;
  justify-content: center;
  text-align: center;
  height: 80px;
  align-items: center;
  cursor: pointer;
  .titleUserPic {
    width: 37px;
    height: 37px;
  }
  .titleUserWord {
    margin-left: 8px;
    height: 20px;
    font-size: 20px;
    font-family: DengXian;
    color: #fdf1e9;
    font-weight: bold;
    inline-size: auto;
  }
}
.titleUser:hover {
  background: #6ab3f2;
}
.colorchange {
  background: #6ab3f2;
}

.titleRightBox {
  display: flex;
  align-items: center;
  height: 80px;
  .titleRight {
    height: 61px;
    background: #ffffff;
    opacity: 0.3;
  }
  .title_return_word {
    margin-left: 37px;
    width: 60px;
    height: 15px;
    font-size: 15px;
    font-family: Microsoft YaHei;
    font-weight: 400;
    color: #ffffff;
  }
  .title_return_pic {
    margin-left: 6px;
    width: 20px;
    height: 20px;
  }
  .titleRow2 {
    margin-left: 29px;
    width: 1px;
    height: 54px;
    background: #ffffff;
  }
  .title_name_word {
    margin-left: 15px;
    width: 98px;
    height: 14px;
    font-size: 14px;
    font-family: DengXian;
    font-weight: bold;
    color: #ffffff;
    opacity: 0.5;
  }
  .title_name_pic {
    margin-left: 8px;
    width: 7px;
    height: 6px;
  }
}

/*左侧导航栏 */
.nav {
  height: 998px;
  background-color: #e9f4fd;
  box-shadow: 0px 3px 5px 0px rgba(0, 0, 0, 0.15);
  .nav_guanli {
    position: relative;
    height: 50px;
    .nav_guanli_pic {
      position: absolute;
      top: 20px;
      left: 29px;
      width: 30px;
    }
    .nav_guanli_word1 {
      position: absolute;
      top: 26px;
      left: 75px;
      font-size: 20px;
      font-family: DengXian;
      font-weight: 400;
      color: #2a92ed;
      inline-size: auto;
    }
  }
  .nav_guanli_word2 {
    margin-top: 15px;
    margin-left: 20px;
    width: 180px;
    height: 14px;
    font-size: 14px;
    font-family: DengXian;
    font-weight: 400;
    color: #323232;
    inline-size: auto;
  }
  .nav_row {
    margin-top: 21px;
    margin-left: 18px;
    width: 245px;
    height: 1px;
    background: #000000;
    opacity: 0.2;
  }
  .nav_box {
    position: relative;
    margin-top: 43px;
    height: 200px;
    width: 100%;
    .nav_box1 {
      cursor: pointer;
      display: flex;
      height: 50px;
      background: #e9f4fd;
    }
    .nav_box1_pic {
      margin-left: 23px;
      margin-top: 10px;
      width: 20px;
      height: 22px;
    }
    .nav_box1_word {
      margin-top: 16px;
      margin-left: 16px;
      width: 54px;
      height: 14px;
      font-size: 14px;
      font-family: DengXian;
      font-weight: 400;
      color: #000000;
      inline-size: auto;
    }
    .nav_box1_right {
      position: absolute;
      display: none;
      right: 0px;
      width: 8px;
      height: 50px;
      background: #2a92ed;
    }
    .nav_box1:hover .nav_box1_right {
      display: block;
    }
    .leftcolorchangebox {
      display: block;
    }
    .leftcolorchange {
      background-color: #8bc8fe;
    }
    .nav_box1:hover {
      background-color: #8bc8fe;
    }
  }
}
/*内容模块 */
.content {
  height: 984px;
  background: #ffffff;
}
</style>
