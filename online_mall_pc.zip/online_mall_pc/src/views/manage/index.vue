<template>
  <div id="manage">
    <div class="contaniner" v-if="this.$store.state.isLogin == true">
      <Header></Header>
      <router-view />
    </div>
  </div>
</template>
<script>
import Header from "../manage/components/Header.vue";
export default {
  components: { Header },
  props: {},
  data() {
    //这里存放数据
    return {};
  },
  methods: {},
  created() {
    if (this.$store.state.isLogin != true) {
      this.$message.warning("请先登录!");
      setTimeout(() => {
        this.$router.push("/login");
      }, 1000);
    }
  },
};
</script>
<style lang="scss" scoped>
* {
  padding: 0;
  margin: 0;
}
#manage {
  height: 100%;
  width: 100%;
}
.contaniner {
  height: 100%;
  width: 100%;
}
</style>