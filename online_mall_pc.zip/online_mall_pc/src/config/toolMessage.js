// 工具类
import { Message } from 'element-ui'
class ToolMessage {
  static commonOption = {
    showClose: true,
    duration: 2000
  }

  static error(message) {
    Message({
      ...ToolMessage.commonOption,
      message,
      type: 'error'
    })
  }

  static success(message) {
    Message({
      ...ToolMessage.commonOption,
      message,
      type: 'success'
    })
  }

  static warning(message) {
    Message({
      ...ToolMessage.commonOption,
      message,
      type: 'warning'
    })
  }
}

export {
  ToolMessage
}
