// export const projectUrl = "http://118.190.104.193:8080/"
export const projectUrl = "http://118.190.104.193:8080/"

export const xmPrefix = 'onlinemall/';

// 用于文件下载
export const fileCatalog = 'upload/';



