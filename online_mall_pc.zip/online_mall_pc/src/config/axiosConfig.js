import Vue from 'vue'
import axios from 'axios'
import { projectUrl, xmPrefix } from "./config"
import {
  Loading,
  Message
} from 'element-ui';
import serverApi from '../api/serverApi'
// 响应时间
// axios.defaults.timeout = 5 * 1000
// 配置cookie
axios.defaults.withCredentials = true
// 配置请求头
// axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=UTF-8'
// 静态资源
// Vue.prototype.$static = ''

// 配置服务器端IP接口地址
axios.defaults.baseURL = projectUrl + xmPrefix

// 把axios配置到VUE构造函数上, 目的是为了能够让所有的组件都可以调用axios

Vue.prototype.$http = axios

let loadingInstance = '';

// POST传参序列化(添加请求拦截器)
// axios.interceptors.request.use(
//   config => {
//     // loadingInstance = Indicator.open({
//     //     text: '加载中...',
//     //     spinnerType: 'fading-circle'
//     //   });
//     if (config.method === 'post') {
//       config.data = qs.stringify(config.data)
//     }
//     return config
//   },
//   err => {
//     // loadingInstance.close()
//     Toast({
//         message: '请求失败',
//         position: 'bottom',
//         duration: 3000
//       });
//     return Promise.reject(err)
//   }
// )
// 返回状态判断(添加响应拦截器)
axios.interceptors.response.use(
  res => {
    if (res.status === 200) {
      if (res.data.code != null && res.data.code != 0) {
        Message({
          message: res.data.message,
          type: 'warning',
          duration: 3000,
        });
      }
      return res.data
    } else {
      Message({
        message: res.data.message,
        type: 'warning',
        duration: 3000,
      });
    }
  },
  err => {
    Message({
      message: '请求失败，请稍后再试',
      type: 'error',
      duration: 3000,
    });
    return Promise.reject(err)
  }
)

// 发送请求
export function fetchPost(url, params, loading) {//添加参数信息
  if (loading) {
    loadingInstance = Loading.service()
  }
  return new Promise((resolve, reject) => {
    axios
      .post(serverApi[url], params)
      .then(
        res => {
          if ((res.code === 0) && loading) {
            loadingInstance.close();
          }
          resolve(res.data)
        }
      )
      .catch(err => {
        if (loading) {
          loadingInstance.close();
        }
        reject(err.data)
      })
  })
}

export function fetchGet(url, params, loading) {
  if (loading) {
    loadingInstance = Loading.service()
  }
  return new Promise((resolve, reject) => {
    axios
      .get(serverApi[url], {
        params: params
      })
      .then(res => {
        if ((res.code === 0) && loading) {
          loadingInstance.close();
        }
        resolve(res.data)
      })
      .catch(err => {
        if (loading) {
          loadingInstance.close();
        }
        reject(err.data)
      })
  })
}

export function fetchGet_down(url, params, loading) {
  if (loading) {
    loadingInstance = Loading.service()
  }
  return new Promise((resolve, reject) => {
    axios
      // eslint-disable-next-line no-unexpected-multiline
      ({
        url: serverApi[url],
        method: 'get',
        params: params,
        responseType: 'blob',
        responseEncoding: 'UTF-8'
      })
      .then(res => {
        if ((res.code === 0) && loading) {
          loadingInstance.close();
        }
        resolve(res)
      })
      .catch(err => {
        if (loading) {
          loadingInstance.close();
        }
        reject(err.data)
      })
  })
}

export function fetchDelete(url, params, loading) {
  if (loading) {
    loadingInstance = Loading.service()
  }
  return new Promise((resolve, reject) => {
    axios
      .delete(serverApi[url], {
        params: params
      })
      .then(res => {
        if ((res.code === 0) && loading) {
          loadingInstance.close();
        }
        resolve(res.data)
      })
      .catch(err => {
        if (loading) {
          loadingInstance.close();
        }
        reject(err.data)
      })
  })
}
/*  组件内部的调用方法 */
// getData () {
//   let params = {
//     userId: this.userId
//   }
//   this.$get('/xxx', params).then(res => {
//     this.listsData = res.data
//   }).catch(() => {
//   })
// }