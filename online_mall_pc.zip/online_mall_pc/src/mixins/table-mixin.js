/**
 * 组件混入封装
 * 实现功能：表格查询
 */
export default {
  data () {
    return {
      dataSource: [],
      getFun: null,
      pageInfo: {
        pageSize: 10,
        nowPage: 1,
        listTotalNumber: 0,
        totalPage: 0
      },
      loading: false,
      searchInfo: {}
    }
  },
  created () {
    this.init({})
  },
  methods: {
    // 数据初始化
    init ({ dataSource, getFun, searchInfo, pageInfo }) {
      pageInfo = pageInfo || {}
      this.dataSource = dataSource || []
      this.getFun = getFun || null
      this.searchInfo = searchInfo || {}
      const { pageSize, nowPage, listTotalNumber, totalPage } = pageInfo
      this.pageInfo = {
        pageSize: pageSize || 10,
        nowPage: nowPage || 1,
        listTotalNumber: listTotalNumber || 0,
        totalPage: totalPage || 0
      }
    },
    // 表格数据查询
    async getTableData (payload) {
      const { getFun, searchInfo, pageInfo } = payload
      // 分页
      if (pageInfo !== undefined) {
        this.pageInfo = { ...this.pageInfo, ...pageInfo }
      } else {
        // 不分页
        this.pageInfo = undefined
      }
      if (searchInfo !== undefined) this.searchInfo = { ...searchInfo }
      this.getFun = getFun
      this.loading = true
      const data = await this.getFun(this,{
        ...this.searchInfo,
        page: this.pageInfo ? this.pageInfo.nowPage : undefined,
        pageSize: this.pageInfo ? this.pageInfo.pageSize : undefined
      })
      this.loading = false
      if (data) {
        if (this.pageInfo && (this.pageInfo.pageSize || this.pageInfo.nowPage)) {
          this.dataSource = data.list // 该值需要后端进行统一
          this.pageInfo.listTotalNumber = data.totalNum
          this.pageInfo.totalPage = data.totalPages
        } else {
          this.dataSource = data.data
          
        }
      } else {
        this.$message.error("获取数据错误")
        this.dataSource = []
      }
    },
    // 获取第一页数据
    goToFirstPage() {
      if ( this.pageInfo.nowPage != 1) {
        this.pageInfo.nowPage = 1;
        this.getTableData({
          getFun: this.getFun,
          searchInfo:this.searchInfo,
          pageInfo:this.pageInfo
        })
      }
    },
    // 获取上一页数据
    goToPreviousPage() {
      this.pageInfo.nowPage--;
      if (this.pageInfo.nowPage < 1) {
        this.pageInfo.nowPage = 1;
      } else {
        this.getTableData({
          getFun: this.getFun,
          searchInfo:this.searchInfo,
          pageInfo:this.pageInfo
        })
      }
    },
    // 获取下一页数据
    goToNextPage() {
      this.pageInfo.nowPage++;
      if (this.pageInfo.nowPage > this.pageInfo.totalPage) {
        this.pageInfo.nowPage = this.pageInfo.totalPage;
      } else {
        this.getTableData({
          getFun: this.getFun,
          searchInfo:this.searchInfo,
          pageInfo:this.pageInfo
        })
      }
    },
    // 获取最后一页数据
    goToLastPage() {
      if (this.pageInfo.nowPage != this.pageInfo.totalPage) {
        this.pageInfo.nowPage = this.pageInfo.totalPage;
        this.getTableData({
          getFun: this.getFun,
          searchInfo:this.searchInfo,
          pageInfo:this.pageInfo
        })
      }
    },
    // 处理筛选表单提交
    handleFilterFormSubmit (searchInfo) {
      Object.keys(searchInfo).some(item => {
        if (!searchInfo[item] && searchInfo[item] !== 0 && searchInfo[item] !== false && searchInfo[item] !== undefined) {
          searchInfo[item] = undefined
        }
      })
      this.searchInfo = searchInfo;
      this.getTableData({
        getFun: this.getFun,
        pageInfo: this.pageInfo === undefined ? undefined : { pageSize: 10, nowPage: 1 },
        searchInfo
      })
    },
    // 重置表单 务必保证 searchInfo 为一个Object 不可以为 null || undefined
    // resetForm (form) {
    //   form.resetFields()
    //   this.searchInfo = {}
    //   this.getTableData({
    //     getFun: this.getFun,
    //     pageInfo: this.pageInfo === undefined ? undefined : { pageSize: 10, pageNum: 1 }
    //   })
    // }
  }
}
