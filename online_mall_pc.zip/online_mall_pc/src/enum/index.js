// 该文件用于存储前端的一些定义变量，使用时直接在导入使用
// 示例
export const FULL_NAV = [
  '/',
  '/login',
  '/register'
]
