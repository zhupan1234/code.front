// 首页地图
export const getAllUser = (that, info) => {
  return that.$post('getAllUserInfo', {
    ...info
  })
}
// 获取客服列表
export const getNextCustomerServiceOrgPage = (that, info) => {
  return that.$post('getNextCustomerServiceOrgPage', {
    ...info
  })
}
// 根据ID查询客服信息
export const getCustomerServiceOrgById = (that, info) => {
  return that.$post('getCustomerServiceOrgById', {
    ...info
  })
}
// 根据ID修改某一客服信息
export const editCustomerServiceOrg = (that, info) => {
  return that.$post('editCustomerServiceOrg', {
    ...info
  })
}
// 新增客服信息
export const addCustomerServiceOrg = (that, info) => {
  return that.$post('addCustomerServiceOrg', {
    ...info
  })
}
// 获取运费列表
export const getNextThresholdOrgPage = (that, info) => {
  return that.$post('getNextThresholdOrgPage', {
    ...info
  })
}
// 根据ID获取运费详情
export const getThresholdOrgById = (that, info) => {
  return that.$post('getThresholdOrgById', {
    ...info
  })
}
// 编辑运费
export const editThresholdOrg = (that, info) => {
  return that.$post('editThresholdOrg', {
    ...info
  })
}
// 新增运费配置
export const addThresholdOrg = (that, info) => {
  return that.$post('addThresholdOrg', {
    ...info
  })
}

export const accountLogin = (that, info) => {
  return that.$post('accountLogin', {
    ...info
  })
}

export const getNextOrderPage = (that, info) => {
  return that.$post('getNextOrderPage', {
    ...info
  })
}

export const getItemById = (that, info) => {
  return that.$post('getItemById', {
    ...info
  })
}

export const editOrder = (that, info) => {
  return that.$post('editOrder', {
    ...info
  })
}

export const editOrderCommodity = (that, info) => {
  return that.$post('editOrderCommodity', {
    ...info
  })
}

export const addCommodityType = (that, info) => {
  return that.$post('addCommodityType', {
    ...info
  })
}

export const deleteCommodityTypeByIds = (that, info) => {
  return that.$post('deleteCommodityTypeByIds', {
    ...info
  })
}

export const updateCommodityType = (that, info) => {
  return that.$post('updateCommodityType', {
    ...info
  })
}

export const getNextCommodityTypePage = (that, info) => {
  return that.$post('getNextCommodityTypePage', {
    ...info
  })
}

export const getCommodityVOList = (that, info) => {
  return that.$post('getCommodityVOList', {
    ...info
  })
}

export const addRecommendCommodity = (that, info) => {
  return that.$post('addRecommendCommodity', {
    ...info
  })
}

export const delRecommendCommodity = (that, info) => {
  return that.$post('delRecommendCommodity', {
    ...info
  })
}

export const getRecommendCommodityPageVO = (that, info) => {
  return that.$post('getRecommendCommodityPageVO', {
    ...info
  })
}

export const getCommodityTypeById = (that, info) => {
  return that.$post('getCommodityTypeById', {
    ...info
  })
}
// 获取用户列表
export const getUserPageVO = (that, info) => {
  return that.$post('getUserPageVO', {
    ...info
  })
}
// 获取用户列表
export const getUserOrder = (that, info) => {
  return that.$post('getUserOrder', {
    ...info
  })
}
// 获取轮播图列表
export const getRotationChartPageVO = (that, info) => {
  return that.$post('getRotationChartPageVO', {
    ...info
  })
}
//新增轮播图
export const addRotationChart = (that, info) => {
  return that.$post('addRotationChart', {
    ...info
  })
}
// 删除轮播图
export const delRotationChart = (that, info) => {
  return that.$post('delRotationChart', {
    ...info
  })
}
export const getNextmanagementPage = (that, info) => {
  return that.$post('getNextmanagementPage', {
    ...info
  })
}
export const addManageMent = (that, info) => {
  return that.$post('addManageMent', {
    ...info
  })
}
export const delManageMentById = (that, info) => {
  return that.$post('delManageMentById', {
    ...info
  })
}

export const getManageMentById = (that, info) => {
  return that.$post('getManageMentById', {
    ...info
  })
}
export const editManageMentOrg = (that, info) => {
  return that.$post('editManageMentOrg', {
    ...info
  })
}
export const getNextCommodityPage = (that, info) => {
  return that.$post('getNextCommodityPage', {
    ...info
  })
}
export const delCommodityById = (that, info) => {
  return that.$post('delCommodityById', {
    ...info
  })
}
export const addCommodityOrg = (that, info) => {
  return that.$post('addCommodityOrg', {
    ...info
  })
}
export const getCommodityById = (that, info) => {
  return that.$post('getCommodityById', {
    ...info
  })
}

export const checkType = (that, info) => {
  return that.$post('checkType', {
    ...info
  })
}
//获取地址
export const getArea = (that, info) => {
  return that.$post('getArea', {
    ...info
  })
}
//删除运费
export const delThresholdServiceOrgById = (that, info) => {
  return that.$post('delThresholdServiceOrgById', {
    ...info
  })
}

//删除运费
export const delCustomerServiceOrgById = (that, info) => {
  return that.$post('delCustomerServiceOrgById', {
    ...info
  })
}
export const editCommodityById = (that, info) => {
  return that.$post('editCommodityById', {
    ...info
  })
}