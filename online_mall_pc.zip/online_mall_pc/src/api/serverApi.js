// 该文件用于存储api路径信息
export default {
    // 登录
    getAllUserInfo: 'common/v1/getAllDeptAndUsers',
    //获取客服列表
    getNextCustomerServiceOrgPage: '/pc/customerService/getNextCustomerServiceOrgPage',
    //根据ID查询客服信息
    getCustomerServiceOrgById: '/pc/customerService/getCustomerServiceOrgById',
    //根据ID修改某一客服信息
    editCustomerServiceOrg: '/pc/customerService/editCustomerServiceOrg',
    //新增客服信息
    addCustomerServiceOrg: '/pc/customerService/addCustomerServiceOrg',
    //获取运费列表
    getNextThresholdOrgPage: '/pc/threshold/getNextThresholdOrgPage',
    //根据ID获取运费详情
    getThresholdOrgById: '/pc/threshold/getThresholdOrgById',
    //编辑运费
    editThresholdOrg: '/pc/threshold/editThresholdOrg',
    //新增运费配置
    addThresholdOrg: '/pc/threshold/addThresholdOrg',

    accountLogin: '/pc/login/accountLogin',

    getNextOrderPage: '/pc/order/getNextOrderPage',

    getNextOrderByStatusPage: '/pc/order/getNextOrderByStatusPage',

    getItemById: '/pc/order/getItemById',

    editOrder: '/pc/order/editOrder',

    editOrderCommodity: '/pc/order/editOrderCommodity',

    addCommodityType: '/pc/commodityType/addCommodityType',

    deleteCommodityTypeByIds: '/pc/commodityType/deleteCommodityTypeByIds',

    updateCommodityType: '/pc/commodityType/updateCommodityType',

    getNextCommodityTypePage: '/pc/commodityType/getNextCommodityTypePage',

    getCommodityVOList: '/pc/commodityType/getCommodityVOList',

    getCommodityTypeById: '/pc/commodityType/getCommodityTypeById',

    addRecommendCommodity: '/pc/recommendCommodity/addRecommendCommodity',

    delRecommendCommodity: '/pc/recommendCommodity/deleteRecommendCommodityByIds',

    getRecommendCommodityPageVO: '/pc/recommendCommodity/getRecommendCommodityPageVO',
    //获取用户列表
    getUserPageVO: '/pc/User/getUserPageVO',
    //获取用户订单
    getUserOrder: '/pc/User/getUserOrder',
    //获取轮播图列表
    getRotationChartPageVO: '/pc/RotationChart/getRotationChartPageVO',
    //新增轮播图
    addRotationChart: '/pc/RotationChart/addRotationChart',
    //删除轮播图
    delRotationChart: '/pc/RotationChart/delRotationChart',
    //获取管理员列表
    getNextmanagementPage: '/pc/management/getNextmanagementPage',
    //新增管理员
    addManageMent: '/pc/management/addManageMent',
    //根据id删除管理员
    delManageMentById: '/pc/management/delManageMentById',
    //根据id查看管理员
    getManageMentById: '/pc/management/getManageMentById',
    //根据id编辑管理员
    editManageMentOrg: '/pc/management/editManageMentOrg',
    //显示商品列表
    getNextCommodityPage: '/pc/commodity/getNextCommodityPage',
    //根据id删除商品
    delCommodityById: '/pc/commodity/delCommodityById',
    //新增商品
    addCommodityOrg: '/pc/commodity/addCommodityOrg',
    //查看商品
    getCommodityById: "/pc/commodity/getCommodityById",

    checkType: "/pc/commodity/checkType",

    getArea: '/pc/area/getArea',
    //编辑商品
    editCommodityById: "/pc/commodity/editCommodityById",

    delThresholdServiceOrgById: '/pc/threshold/delThresholdServiceOrgById',

    delCustomerServiceOrgById: '/pc/customerService/delCustomerServiceOrgById'
    
}
