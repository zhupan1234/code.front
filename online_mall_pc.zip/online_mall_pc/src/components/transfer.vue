<!--穿梭框-->
<template>
  <div
    class="transferContainer"
    style="display: flex; align-items: center; justify-content: center"
  >
    <div class="leftTransfer">
      <el-input :placeholder="selectTitle" v-model="filterText"> </el-input>
      <el-tree
        class="filter-tree"
        show-checkbox
        :data="allInfo"
        node-key="id"
        :props="defaultProps"
        :filter-node-method="filterNode"
        ref="tree"
      >
      </el-tree>
    </div>
    <div class="transferEvent">
      <div
        class="el-icon-arrow-right iconSize"
        @click="getCheckedNodes()"
      ></div>
      <div class="el-icon-arrow-left iconSize" @click="removeSelect()"></div>
    </div>
    <div class="rightTransfer">
      <div class="selectAll">
        <el-checkbox
          :indeterminate="isIndeterminate"
          v-model="checkAll"
          @change="handleCheckAllChange"
          >全选</el-checkbox
        >
      </div>
      <div class="selectContent">
        <el-checkbox-group
          v-model="checkedOption"
          @change="handleCheckedCitiesChange"
        >
          <el-checkbox
            v-for="(item, index) in selectOption"
            :label="item"
            :key="index"
            >{{ item.name }}</el-checkbox
          >
        </el-checkbox-group>
      </div>
    </div>
  </div>
</template>

<script>
//这里可以导入其他文件（比如：组件，工具js，第三方插件js，json文件，图片文件等等）
//例如：import 《组件名称》 from '《组件路径》';
export default {
  //import引入的组件需要注入到对象中才能使用
  watch: {
    //  selected(newValue){
    //     console.dir(newValue);
    //      this.selectOption = newValue;
    //  },
    //  searchText(newValue){
    //      console.dir(newValue);
    //      this.filterText = newVale;
    //  },
    filterText(val) {
      this.$refs.tree.filter(val);
    },
    selectOption(val) {
      this.setCheckedNodes(this.selectOption);
    },
  },
  components: {},
  data() {
    //这里存放数据
    return {
      checkAll: false,
      checkedOption: [],
      isIndeterminate: false,

      selectOption: [],
      filterText: "",
      defaultProps: {
        children: "children",
        label: "name",
      },
    };
  },
  props: ["allInfo", "selected", "selectTitle"],
  //方法集合
  methods: {
    // 获取树节点选择数据
    getCheckedNodes() {
      // console.log(this.$refs.tree.getCheckedNodes());
      let selectValue = this.$refs.tree.getCheckedNodes();
      let tempSelect = [];
      for (let key in selectValue) {
        if (selectValue[key].children == undefined) {
          if (this.selectOption.length > 0) {
            let flag = true;
            for (let m in this.selectOption) {
              if (this.selectOption[m].id == selectValue[key].id) {
                flag = false;
              }
            }
            if (flag) {
              if (this.filterText != "") {
                if (selectValue[key].title.indexOf(this.filterText) != -1) {
                  tempSelect.push(selectValue[key]);
                }
              } else {
                tempSelect.push(selectValue[key]);
              }
            }
          } else {
            if (this.filterText != "") {
              if (selectValue[key].title.indexOf(this.filterText) != -1) {
                tempSelect.push(selectValue[key]);
              }
            } else {
              tempSelect.push(selectValue[key]);
            }
          }
        }
      }
      this.selectOption.push(...tempSelect); //将数据移动到右边
    },
    //   设置已选择数据
    setCheckedNodes(list) {
      console.dir(list);
      this.$refs.tree.setCheckedNodes(list);
    },
    //   树组件搜索
    filterNode(value, data) {
      if (!value) return true;
      return data.name.indexOf(value) !== -1;
    },

    //   判断是否全选
    handleCheckAllChange(val) {
      this.checkedOption = val ? this.selectOption : [];
      this.isIndeterminate = false;
    },
    //   选择器勾选
    handleCheckedCitiesChange(value) {
      let checkedCount = value.length;
      this.checkAll = checkedCount === this.selectOption.length;
      this.isIndeterminate =
        checkedCount > 0 && checkedCount < this.selectOption.length;
    },
    removeSelect() {
      let indexList = [];
      for (let key in this.checkedOption) {
        let index = null;
        for (let m in this.selectOption) {
          if (this.selectOption[m].id == this.checkedOption[key].id) {
            indexList.push(m);
          }
        }
      }
      console.log(indexList);
      let selectList = [];
      for (let key in this.selectOption) {
        let flag = true;
        for (let m in indexList) {
          if (key == indexList[m]) {
            flag = false;
          }
        }
        if (flag) {
          selectList.push(this.selectOption[key]);
        }
      }
      this.checkedOption = [];
      this.selectOption = selectList;
      this.setCheckedNodes(this.selectOption);
      this.checkAll = false;
      this.isIndeterminate = false;
    },
    // 确认选择（改方法发送到父组件）
    confirm() {
      return this.selectOption;
    },
  },
  //生命周期 - 创建完成（可以访问当前this实例）
  created() {
    this.selectOption = JSON.parse(JSON.stringify(this.selected));
    // 获取所有人员信息
    // this.allInfo=this.$tools.getAllUserInfo(this);
    // 获取所有部门信息
    // this.allDeptarments=this.$tools.getAllDeptarments(this);
  },
  //生命周期 - 挂载完成（可以访问DOM元素）
  mounted() {},
};
</script>
<style lang='scss' scoped>
//@import url(); 引入公共css类
.transferContainer {
  width: 100%;
  height: 400px;
  background-color: white;
}
.leftTransfer {
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  width: 40%;
  overflow: auto;
  height: 100%;
  position: relative;
}
.transferContainer /deep/ .leftTransfer {
  .el-input {
    position: absolute;
    top: 0px;
    font-size: 14px;
    display: inline-block;
    width: 100%;
    height: 40px;
    z-index: 999;
  }
  .el-input__inner {
    border-radius: 4px;
    border: 0px;
    border-bottom: 1px solid #dcdfe6;
    height: 40px;
    line-height: 40px;
    padding: 0 15px;
  }
  // .el-input__inner:hover{
  //     border: 1px solid $headerbg-color;
  // }
  .el-tree {
    width: 100%;
    border-radius: 4px;
    top: 40px;
    overflow: auto;
    position: absolute;
    bottom: 0px;
    cursor: default;
    background: #ffffff;
    color: #606266;
    // display: grid;
  }
  .el-tree__empty-text {
    font-size: 14px;
  }
  .el-tree-node__content {
    height: 26px;
  }
  .el-tree-node__label {
    font-size: 14px;
    margin-right: 14px;
  }
  .el-tree-node__expand-icon {
    font-size: 12px;
    padding: 6px;
  }
  .el-checkbox {
    font-weight: 500;
    font-size: 14px;
    margin-right: 10px;
  }
  .el-checkbox__inner {
    border: 1px solid #dcdfe6;
    border-radius: 2px;
    width: 14px;
    height: 14px;
  }
  .el-checkbox__input.is-checked .el-checkbox__inner {
    border-color: $headerbg-color;
  }
  .el-checkbox__inner::after {
    border: 1px solid #ffffff;
    border-left: 0;
    border-top: 0;
    height: 7px;
    left: 4px;
    position: absolute;
    top: 1px;
    width: 3px;
  }
  .el-checkbox__input.is-indeterminate .el-checkbox__inner::before {
    height: 2px;
    left: 0;
    right: 0;
    top: 5px;
  }
  .el-checkbox__input.is-indeterminate .el-checkbox__inner {
    border-color: $headerbg-color;
  }
}

.rightTransfer {
  border: 1px solid #dcdfe6;
  border-radius: 4px;
  width: 40%;
  overflow: auto;
  height: 100%;
  position: relative;
  // padding-left: 10px;
}
.transferContainer /deep/.rightTransfer {
  .selectAll {
    position: absolute;
    top: 0px;
    width: 100%;
    height: 40px;
    border-radius: 4px;
    border-bottom: 1px solid #dcdfe6;
    display: flex;
    align-items: center;
  }
  .selectContent {
    position: absolute;
    top: 40px;
    bottom: 0px;
    width: 100%;
    overflow: auto;
    // display: grid;
  }
  .el-checkbox {
    color: #606266;
    font-weight: 500;
    font-size: 14px;
    margin-right: 30px;
    margin-left: 10px;
    display: flex;
    align-items: center;
  }
  .el-checkbox {
    font-weight: 500;
    font-size: 14px;
    margin-right: 10px;
    line-height: 26px;
    height: 26px;
  }
  .el-checkbox__inner {
    border: 1px solid #dcdfe6;
    border-radius: 2px;
    width: 14px;
    height: 14px;
  }
  .el-checkbox__input.is-checked .el-checkbox__inner {
    border-color: $headerbg-color;
  }
  .el-checkbox__inner::after {
    border: 1px solid #ffffff;
    border-left: 0;
    border-top: 0;
    height: 7px;
    left: 4px;
    position: absolute;
    top: 1px;
    width: 3px;
  }
  .el-checkbox__input.is-indeterminate .el-checkbox__inner::before {
    height: 2px;
    left: 0;
    right: 0;
    top: 5px;
  }
  .el-checkbox__input.is-indeterminate .el-checkbox__inner {
    border-color: $headerbg-color;
  }
  .el-checkbox__label {
    display: inline-block;
    padding-left: 10px;
    line-height: 19px;
    font-size: 14px;
  }
}
.transferEvent {
  width: 20%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  .iconSize {
    margin-top: 10px;
    width: 60px;
    height: 60px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    background: $asideHover-color;
    color: $mainActiveTitle-color;
    font-size: 30px;
    line-height: 50px;
    cursor: pointer;
  }
  .iconSize:hover {
    background: $asideActive-color;
  }
}
</style>