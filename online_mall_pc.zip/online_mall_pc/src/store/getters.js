// 定义mapGetters辅助函数
// 使用示例：
// import { mapGetters } from 'vuex'
// ...mapGetters(['addRoutes'])

const getters = {
  addRoutes: state => state.permission.addRoutes,
}
export default getters
