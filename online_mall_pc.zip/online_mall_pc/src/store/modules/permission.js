/**
 * 路由权限配置
 */
import { constRouter } from '@/router'
/**
 * 路由数据封装（包含嵌套路由，递归实现）
 * @param {Array} res 封装结果
 * @param {Array} route 获取的路由数据
 * @param {Number} level 当前路由级别
 */
function generaMenu (res, route = [], level = 0) {
  route.forEach((item) => {
    const menu = {
      path: item.menuUrl,
      component: resolve => require([`@/views${item.menuUrl}`], resolve),
      name: item.menuName,
      label: item.label,
      type: item.menuType || undefined,
      iconClass: item.iconClass || undefined,
      meta: {
        id: item.menuId,
        level,
        breadName: (item.menuUrl) ? item.label : '',
        openId: item.parentId || '',
        path: `@/views${item.menuUrl}`,
        permission: JSON.parse(item.permission) || []
      },
      children: []
    }
    if (item.children && item.children.length !== 0) {
      generaMenu(menu.children, item.children, level + 1)
    }
    res.push(menu)
  })
}
export default {
  namespaced: true,
  state: {
    addRoutes: [], // 用户可访问路由表
    routes: [...constRouter] // 完整路由表
  },
  mutations: {
    SET_ROUTE (state, routes) {
      state.addRoutes = routes
      state.routes = state.routes.concat(routes)
    },
    CLEAR_ROUTE: (state) => {
      state.routes = [...constRouter]
      state.addRoutes = []
    }
  },
  actions: {
    /**
     * 查询当前用户权限信息（包含菜单和菜单权限）
     * @param {commit}
     * @param {*} user
     * @returns
     */
    async setRoutes ({ commit }, menuList) {
      const accessedRoutes = []
      generaMenu(accessedRoutes, menuList)
      commit('SET_ROUTE', accessedRoutes)
      return new Promise(resolve => {
        resolve(accessedRoutes)
      })
    },
    clearRoutes ({ commit }) {
      commit('CLEAR_ROUTE')
    }
  }
}
