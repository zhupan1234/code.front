import Vue from 'vue'
import Vuex from 'vuex'
import getters from './getters'

/**
 * 自动引入当前文件夹下所有module
 * require.context(directory, useSubdirectories = false, regExp = /^.//);
 * @param {String} directory 读取文件的路径
 * @param {Boolean} directory 匹配文件的正则表达式
 * @param {regExp} regExp 读取文件的路径
 */

const modulesFiles = require.context('./modules', true, /.js$/)
const modulesMap = modulesFiles.keys().reduce((modules, modulePath) => {
  const moduleName = modulePath.replace(/^.\/(.*)\.js/, '$1')
  const value = modulesFiles(modulePath)
  modules[moduleName] = value.default
  return modules
}, {})

Vue.use(Vuex)

const state = {
  isLogin: false,
  userName: ""
}

const mutations = {
  setLogin(state, isLogin) {
    state.isLogin = isLogin;
  },
  setUserName(state, userName) {
    state.userName = userName;
  }
}

export default new Vuex.Store({
  modules: modulesMap,
  getters,
  state,
  mutations,
})
