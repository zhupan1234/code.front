import Vue from 'vue'
import VueRouter from 'vue-router'

const originalPush = VueRouter.prototype.push
VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}

Vue.use(VueRouter)
// 没有权限限制的路由
export const constRouter = [
  {
    path: '/',
    redirect: '/login',
    hidden: true,
    component: () => import('../views/login')
  },
  {
    path: "/login",
    name: "Login",
    hidden: true,
    component: () => import("../views/login"), //所有的路由组件导入均采取动态加载的方式
  },

  {
    path: "/manage",
    redirect: "/manage/sysManage/loginUserManage",
    name: "manage",
    hidden: true,
    component: () => import("../views/manage/index"),
    children: [
      {
        path: "/manage/sysManage",
        name: "sysManage",
        hidden: true,
        component: () => import("../views/manage/sysManage"),
        children: [
          {
            path: '/manage/sysManage/loginUserManage',
            name: "loginUserManage",
            hidden: true,
            component: () => import('../views/manage/sysManage/loginUserManage')
          },
          {
            path: '/manage/sysManage/commodityManage',
            name: "commodityManage",
            hidden: true,
            component: () => import('../views/manage/sysManage/commodityManage')
          },
          {
            path: '/manage/sysManage/orderManage',
            name: "orderManage",
            hidden: true,
            component: () => import('../views/manage/sysManage/orderManage')
          },
          {
            path: '/manage/sysManage/userManage',
            name: "userManage",
            hidden: true,
            component: () => import('../views/manage/sysManage/userManage')
          },
          {
            path: '/manage/sysManage/configurationManage',
            name: "configurationManage",
            hidden: true,
            component: () => import('../views/manage/sysManage/configurationManage')
          },
          {
            path: '/manage/sysManage/customServiceManage',
            name: "customServiceManage",
            hidden: true,
            component: () => import('../views/manage/sysManage/customServiceManage')
          },
          {
            path: '/manage/sysManage/freightManage',
            name: "freightManage",
            hidden: true,
            component: () => import('../views/manage/sysManage/freightManage')
          },
        ],
      },
    ],
  },
];

const router = new VueRouter({
  mode: "history",
  // 根据具体项目进行修改
  base: "test",
  routes: constRouter,
});

export default router;
