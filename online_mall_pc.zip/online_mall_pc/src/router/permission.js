// 该文件为权限配置文件，通过配置动态路由和状态管理器实现权限展示

import router, { lastRoute } from '.'
import store from '../store'
import { ToolMessage } from '../config/toolMessage'
import NProgress from 'nprogress'

import 'nprogress/nprogress.css'

NProgress.configure({ showSpinner: false })
const whiteList = ['/login', '/register'] // 排除的路径

router.beforeEach(async (to, from, next) => {
  NProgress.start()
  next() // 放开下面要删掉该行
  // if (whiteList.indexOf(to.path) !== -1) {
  //   next()
  // } else {
  //   const hasToken = sessionStorage.getItem('token')
  //   if (hasToken) {
  //     // 若路由信息已附加则说明动态路由已经添加
  //     const hasRoutes = store.getters.addRoutes && store.getters.addRoutes.length > 0
  //     if (hasRoutes) {
  //       // 路由信息
  //       next() // 继续即可
  //     } else {
  //       try {
  //         // 先请求获取用户角色
  //         const userInfo = JSON.parse(sessionStorage.getItem('store'))?.user.userInfo
  //         const menuList = store.getters.userInfo.menuList || userInfo.menuList
  //         // 根据当前用户角色动态生成路由 permission/setRoutes这里的实现方法需要返回一个promise
  //         const newRoutes = await store.dispatch('permission/setRoutes', menuList)
  //         // // 添加这些路由
  //         // 当newRoutes为[],提示当前用户无权限，请联系管理员
  //         if (newRoutes.length === 0) {
  //           ToolMessage.error('当前用户无权限，请联系管理员')
  //           next('/login')
  //         } else {
  //           const all = [...newRoutes, ...lastRoute]
  //           all.some(route => {
  //             router.addRoute(route)
  //           })
  //           // 继续路由切换,确保addRoutes完成
  //           next({ ...to, replace: true })
  //         }
  //       } catch (error) {
  //         // 出错需要重置令牌并重新登陆(令牌过期,网络错误等原因)
  //         await store.dispatch('user/clearUser')
  //         ToolMessage.error(error || '网络错误')
  //         next('/login')
  //       }
  //     }
  //   } else {
  //     // 用户无令牌
  //     if (whiteList.indexOf(to.path) !== -1) {
  //       // 白名单路由放过
  //       next()
  //     } else {
  //       // 重定向至登录页
  //       next('/login')
  //     }
  //   }
  // }
})

router.afterEach(() => {
  NProgress.done()
})
