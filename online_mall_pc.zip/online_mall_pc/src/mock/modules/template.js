/**
 * 该文件为mock.js的示例文件
 */
 import Mock from 'mockjs'

 // 配置下发查询
 Mock.mock(/config\/searchConfigDone/, 'post', (options) => {
   console.log(`%c${decodeURIComponent(options.url)}`, 'color:blue')
   return Mock.mock({
     code: 0,
     message: '查询成功',
     data: {
       'list|10': [
         {
           'orderId|+1': 1,
           gatewayIp: '@ip',
           vpnNum: '22',
           'gatewayType|1': ['conv', 'pre']
         }
       ],
       total: 20,
       pageNum: 1,
       pageSize: 5,
       pages: 2
     }
   })
 })
 