const env = process.env.NODE_ENV
function requireAll (r) { r.keys().forEach(r) }
if (env.indexOf('mock') !== -1) {
  requireAll(require.context('./modules/', true, /\.js$/))
}
