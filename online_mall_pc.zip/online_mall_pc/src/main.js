import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import ElementUI from 'element-ui'
import { ToolMessage } from './config/toolMessage'
import {fetchGet_down, fetchGet, fetchPost, fetchDelete} from './config/axiosConfig'
import {projectUrl, xmPrefix} from './config/config'
import './mock/'
import './router/permission'
import 'nprogress/nprogress.css'
// 自定义element主题色
import '../src/css/element-variables.scss'
// 初始化全局样式
import '../src/css/reset.scss'
// 全局scss变量
import '../src/css/var.scss'
// 全局样式
import '../src/css/common.scss'

Vue.use(ElementUI)
Vue.use(store)

Vue.prototype.projectUrl = projectUrl;
Vue.prototype.xmPrefix = xmPrefix;

Vue.prototype.$get = fetchGet;
Vue.prototype.$post = fetchPost;
Vue.prototype.$delete = fetchDelete;
Vue.prototype.$get_down = fetchGet_down;
Vue.prototype.$message = ToolMessage
Vue.prototype.$bus = new Vue();

// 阻止启动生产消息
Vue.config.productionTip = false
new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
