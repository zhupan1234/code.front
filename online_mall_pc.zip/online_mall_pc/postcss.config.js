module.exports = () => ({
  plugins: [
    require('autoprefixer')(),
    require('postcss-plugin-px2rem')({
      minPixelValue: 1.01,
      mediaQuery: false,
      rootValue: 15
    })
  ]
})
