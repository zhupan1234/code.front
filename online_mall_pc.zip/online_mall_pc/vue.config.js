module.exports = {
  publicPath: '/test/',
  outputDir: 'test',
  css: {
    loaderOptions: {
      sass: {
        prependData: '@import "@/css/var.scss";',
      },
    },
  },

  // disable source map in production
  productionSourceMap: false,
  lintOnSave: false,
  // babel-loader no-ignore node_modules/*
  transpileDependencies: []
}
